﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ORS.EntityLayer;
using ORS.ExceptionLayer;
using ORS.BL;


namespace ORS.PL
{
    public partial class LoginForm : System.Web.UI.Page
    {
        Admin adObj = new Admin();
        LoginValidations validationObj=new LoginValidations();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
             try
            {
                adObj.Email = txtEmail.Text;
                adObj.UserPassword = txtPassword.Text;
                adObj.UserType = ddlUserType.Text;
                
                if (adObj.UserType == "Employer")
                {
                    bool EmployerVerified = validationObj.LoginEmployer(adObj);
          
                    if (EmployerVerified)
                    {
                        Session["UserID"] = StaticVariables.UserID;
                        Session["EmpID"] = StaticVariables.employerID;
                        Response.Redirect("Home.aspx",false);               
                    }
                    else
                    {
                        Response.Write("<script>alert('Invalid User')</script>");
                    }
                }
                else
                {
                    if (adObj.UserType == "Jobseeker")
                    {
                        bool JobseekerVerified = validationObj.LoginJobseeker(adObj);
                        if (JobseekerVerified)
                        {
                            //var jsForm = new JobSeekerHomePage();
                            //jsForm.Show();
                            Response.Write("Login Successful");
                        }
                        else
                        {
                            Response.Write("Login Unsuccessful");
                        }
                    }


                }
            }
            catch (LoginException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch(SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("SignUpOptions.aspx");
        }

        }
    }
