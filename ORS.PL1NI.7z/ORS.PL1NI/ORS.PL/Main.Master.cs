﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ORS.PL
{
    public partial class Main : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void lbtnLogout_Click(object sender, EventArgs e)
        {
            Session["UserID"] = null;
            Response.Redirect("LoginForm.aspx", false);
        }

        public bool VisibleLogout
        {
            get { return lbtnLogout.Visible; }
            set
            { lbtnLogout.Visible = value; }
        }

        
    }
}