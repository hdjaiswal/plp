﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.EntityLayer;
using ORS.ExceptionLayer;
using ORS.DAL;
using System.Data.SqlClient;
using System.Data;

namespace ORS.BL
{
    public class EmployerValidations
    {
        EmployerOperations operationObj = new EmployerOperations();
        public bool ValidateUser(Admin adObj, Employer empObj)
        {
            bool validUser = true;
            StringBuilder sb = new StringBuilder();

            try
            {
                if (validUser == false)
                    throw new LoginException(sb.ToString());
                return validUser;
            }
            catch (LoginException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        public bool ValidateVacancy(Employer empObj)
        {
            bool validUser = true;
            StringBuilder sb = new StringBuilder();

            try
            {
                if (validUser == false)
                    throw new LoginException(sb.ToString());
                return validUser;
            }
            catch (LoginException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }


        public bool LoginEmployer(Admin adObj, Employer empObj)
        {
            bool empAdded = false;

            try
            {
                if (ValidateUser(adObj, empObj))
                    empAdded = operationObj.AddEmployerInformation(adObj, empObj);
                return empAdded;
            }
            catch (LoginException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        public bool AddEmployerInformation(Admin adObj, Employer empObj)
        {
            bool employerAdded = false;
            try
            {
                if (ValidateUser(adObj, empObj))
                    employerAdded = operationObj.AddEmployerInformation(adObj, empObj);

                return employerAdded;
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        public bool AddVacancyInformation(Employer empObj)
        {
            bool vacancyAdded = false;
            try
            {
                if (ValidateVacancy(empObj))
                    vacancyAdded = operationObj.AddVacancyInformation(empObj);
                return vacancyAdded;
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        public DataTable DisplayEmployer(int userID)
        {
            try
            {
            DataTable dt = new DataTable();
            dt = operationObj.DisplayEmployeer(userID);
            return dt;
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        public bool UpdateEmployer(Admin adObj,Employer empObj)
        {
             try
            {
            bool employeerUpdated = false;
           
            if (ValidateVacancy(empObj))
                employeerUpdated = operationObj.UpdateEmployer(adObj, empObj);
      
            return employeerUpdated;
            }
             catch (EmployerException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }
        }

        public DataTable SearchJobseeker(string skills)
        {
             try
            {
            DataTable searchTable = operationObj.SearchJobseeker(skills);
            return searchTable;
            }
             catch (EmployerException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }
        }

        public DataTable DisplayVacancy(int empID)
        {
            try
            {
                DataTable searchTable = operationObj.DisplayVacancy(empID);
                return searchTable;
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }
    }
}