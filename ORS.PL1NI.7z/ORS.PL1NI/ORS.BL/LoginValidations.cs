﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.EntityLayer;
using ORS.ExceptionLayer;
using ORS.DAL;
using System.Data.SqlClient;

namespace ORS.BL
{
    public class LoginValidations
    {
        LoginOperations operationObj = new LoginOperations();
        public bool ValidateUser(Admin adObj)
        {
            bool validUser = true;
            StringBuilder sb = new StringBuilder();

            try
            {
                if (validUser == false)
                    throw new LoginException(sb.ToString());
                return validUser;
            }
            catch (LoginException ex)
            {
                throw ex;
            }
            catch(SqlException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
        }
        public bool LoginEmployer(Admin adObj)
        {
            bool employerVerified = false;

            try
            {
            if (ValidateUser(adObj))
                employerVerified = operationObj.LoginEmployer(adObj);
            return employerVerified;
            } 
            catch (LoginException ex)
            {
                throw ex;
            }
            catch(SqlException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
        }

        public bool LoginJobseeker(Admin adObj)
        {
            bool jobseekerVerified = false;

            try
            {
                if (ValidateUser(adObj))
                    jobseekerVerified = operationObj.LoginJobseeker(adObj);
                return jobseekerVerified;
            }
            catch (LoginException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }
    }
}
