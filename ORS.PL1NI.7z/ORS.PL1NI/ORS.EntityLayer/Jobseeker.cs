﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.EntityLayer
{
    public class Jobseeker
    {    //Entity class for Jobseeker Information
        //Jobseeker
        public int JobseekerID { get; set; } //Primary Key
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DOB { get; set; }
        public string Gender { get; set; }
        public string LangKnown { get; set; }
        public string Skills { get; set; }
        public string UserType { get; set; }



        //JobHistory
        public string Experience { get; set; }
        public string CompanyName1 { get; set; }
        public string TechWorkedOn { get; set; }
        public string ProjWorkedOn { get; set; }


        //Qualification
        public double SSCMarks { get; set; }
        public DateTime SpYear { get; set; }
        public double HSCMarks { get; set; }
        public DateTime HpYear { get; set; }
        public double DipMarks { get; set; }
        public DateTime DipYear { get; set; }
        public double GradMarks { get; set; }
        public DateTime GpYear { get; set; }
        public double PostGMarks { get; set; }
        public DateTime PostGYear { get; set; }

    }
}