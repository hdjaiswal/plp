﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.EntityLayer
{
   public class Employer
   {    //Entity class for Employer Information
       //Employer
        public int EmployerID { get; set; }  //Primary Key
        public string CompanyID { get; set; }
        public string CompanyName { get; set; }
        public string CompanyType { get; set; }
        public string CompanyWebsite { get; set; }
        public string CompanyDesc { get; set; }
        public string UserType{ get; set; }



        //Entity class for Vacancy Information
        public int VacancyID { get; set; } //Primary Key
        public string ReqExp { get; set; }
        public string Location { get; set; }
        public string Salary { get; set; }
        public string Position { get; set; }
        public string JobDescription { get; set; }
        public string CompanyName2 { get; set; }
        public string Domain { get; set; }
        public string Category { get; set; }

    }
}
