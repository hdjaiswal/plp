﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.EntityLayer
{
    public static class StaticVariables
    {
        public static int employerID;

        public static int jobseekerID;

        public static int UserID;
    }
}
