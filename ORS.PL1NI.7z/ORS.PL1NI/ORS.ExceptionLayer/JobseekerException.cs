﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.ExceptionLayer
{//Class to throw Jobseeker Exceptions
    class JobseekerException :ApplicationException
    { 
         //Default Constructor
        public  JobseekerException ()
            : base()
        { }

        //Parameterized Constructor
        public JobseekerException(string message)
            : base(message)
        { }
    }
}
