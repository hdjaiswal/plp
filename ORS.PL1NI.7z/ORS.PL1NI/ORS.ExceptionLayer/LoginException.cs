﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.ExceptionLayer
{
    //Class to throw Employer exceptions
    public class LoginException : ApplicationException
    {
        //Default Constructor
        public LoginException()
            : base()
        { }

        //Parameterized Constructor
        public LoginException(string message)
            : base(message)
        { }
    }
}
