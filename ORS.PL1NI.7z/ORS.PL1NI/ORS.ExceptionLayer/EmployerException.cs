﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.ExceptionLayer
{//Class to throw Employer exceptions
    public class EmployerException : ApplicationException
    {
          //Default Constructor
        public EmployerException()
            : base()
        { }

        //Parameterized Constructor
        public EmployerException(string message)
            : base(message)
        { }
    }
}
