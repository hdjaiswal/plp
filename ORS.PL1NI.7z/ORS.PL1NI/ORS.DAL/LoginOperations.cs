﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.EntityLayer;
using ORS.ExceptionLayer;

namespace ORS.DAL
{
    public class LoginOperations
    {
        public bool LoginEmployer(Admin adObj)
        {
            //SqlConnection con=new SqlConnection();
            try
            {
                bool employerVerified = false;

                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "LoginEmployer";
                cmd.Parameters.AddWithValue("@Email", adObj.Email); //for @username we will compare value TextBox1.Text
                cmd.Parameters.AddWithValue("@UserPassword", adObj.UserPassword); //this is for password
                cmd.Parameters.AddWithValue("@UserType", adObj.UserType);
                cmd.Connection.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                StaticVariables.employerID=Convert.ToInt32(dt.Rows[0]["EmployerID"]);
                StaticVariables.UserID = Convert.ToInt32(dt.Rows[0]["UserID"]);
                //reader.Read();
                //if there are ROWS return

                if (dt.IsInitialized)
                {
                    employerVerified = true;  
                }
                else
                {
                    throw new LoginException("User Name/Password is invalid");
                }

                cmd.Connection.Close();
                return employerVerified;
            }
            catch (LoginException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }


        }
        public bool LoginJobseeker(Admin adObj)
        {
            //SqlConnection con=new SqlConnection();
            try
            {
                bool jobseekerVerified = false;

                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "LoginJobseeker";
                cmd.Parameters.AddWithValue("@Email", adObj.Email); //for @username we will compare value TextBox1.Text
                cmd.Parameters.AddWithValue("@UserPassword", adObj.UserPassword); //this is for password
                cmd.Parameters.AddWithValue("@UserType", adObj.UserType);
                cmd.Connection.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                //reader.Read();
                //if there are ROWS return

                if (reader.HasRows)
                {
                    reader.Read();
                    jobseekerVerified = true;
                    //ORS.EntityLayer.StaticVariables.empUserID = (int)reader["UserID"];
                }
                else
                {
                    throw new LoginException("User Name/Password is invalid");
                }
                cmd.Connection.Close();

                return jobseekerVerified;
            }
            catch (LoginException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }

        }
    }
}