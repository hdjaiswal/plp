﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.EntityLayer;
using ORS.ExceptionLayer;

namespace ORS.DAL
{
    public class EmployerOperations
    {
        /// <summary>
        /// Author: Group 3
        /// Date Modified: 02/04/2017
        /// Description : Recruitment operations class to deal with the Recruitment data
        /// Date of Creation :25/03/2017
        /// </summary>
        /// <param name="adObj"></param>
        /// <returns>bool</returns>
        public bool AddEmployerInformation(Admin adObj, Employer empObj)
        {

            try
            {
                bool employerAdded = false;
                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "InsertIntoEmployers";
                cmd.Parameters.AddWithValue("@Email", adObj.Email);
                cmd.Parameters.AddWithValue("@UserPassword", adObj.UserPassword);
                cmd.Parameters.AddWithValue("@UserPassword1", adObj.UserPassword1);
                cmd.Parameters.AddWithValue("@P_Phone", adObj.P_Phone);
                cmd.Parameters.AddWithValue("@S_Phone", adObj.S_Phone);
                cmd.Parameters.AddWithValue("@Address1", adObj.Address1);
                cmd.Parameters.AddWithValue("@Address2", adObj.Address2);
                cmd.Parameters.AddWithValue("@Postalcode", adObj.Postalcode);
                cmd.Parameters.AddWithValue("@City", adObj.City);
                cmd.Parameters.AddWithValue("@Country", adObj.Country);
                cmd.Parameters.AddWithValue("@State", adObj.State);
                cmd.Parameters.AddWithValue("@CompanyID", empObj.CompanyID);
                cmd.Parameters.AddWithValue("@CompanyName", empObj.CompanyName);
                cmd.Parameters.AddWithValue("@CompanyType", empObj.CompanyType);
                cmd.Parameters.AddWithValue("@CompanyWebsite", empObj.CompanyWebsite);
                cmd.Parameters.AddWithValue("@CompanyDesc", empObj.CompanyDesc);
                cmd.Parameters.AddWithValue("@UserType", empObj.UserType);

                if (cmd.Connection.State == ConnectionState.Closed)
                {
                    cmd.Connection.Open();
                }
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                    employerAdded = true;

                cmd.Connection.Close();
                return employerAdded;


            }
            catch (EmployerException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public bool AddVacancyInformation(Employer empObj)
        {

            try
            {
                bool vacancyAdded = false;

                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "InsertIntoVacancy";
                cmd.Parameters.AddWithValue("@ReqExp", empObj.ReqExp);
                cmd.Parameters.AddWithValue("@Location", empObj.Location);
                cmd.Parameters.AddWithValue("@Salary", empObj.Salary);
                cmd.Parameters.AddWithValue("@Position", empObj.Position);
                cmd.Parameters.AddWithValue("@JobDescription", empObj.JobDescription);
                cmd.Parameters.AddWithValue("@CompanyName", empObj.CompanyName);
                cmd.Parameters.AddWithValue("@Domain", empObj.Domain);
                cmd.Parameters.AddWithValue("@EmployerID", empObj.EmployerID);


                if (cmd.Connection.State == ConnectionState.Closed)
                    cmd.Connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                    vacancyAdded = true;

                cmd.Connection.Close();
                return vacancyAdded;
            }
            catch (EmployerException)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException)
            {
                throw;
            }

        }


        public DataTable DisplayEmployeer(int userID)
        {
            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "DisplayEmployer";
                cmd.Parameters.AddWithValue("@UserID", userID); //for @username we will compare value TextBox1.Text
                cmd.Connection.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);

                cmd.Connection.Close();
                return dt;
            }
            catch (EmployerException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public bool UpdateEmployer(Admin adObj,Employer empObj)
        {

            bool employeerUpdated = false;
            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "UpdateEmployers";
                cmd.Parameters.AddWithValue("@UserID", adObj.UserID);
                cmd.Parameters.AddWithValue("@P_Phone", adObj.P_Phone);
                cmd.Parameters.AddWithValue("@S_Phone", adObj.S_Phone);
                cmd.Parameters.AddWithValue("@Address1", adObj.Address1);
                cmd.Parameters.AddWithValue("@Address2", adObj.Address2);
                cmd.Parameters.AddWithValue("@Postalcode", adObj.Postalcode);
                cmd.Parameters.AddWithValue("@City", adObj.City);
                cmd.Parameters.AddWithValue("@State", adObj.State);
                cmd.Parameters.AddWithValue("@Country", adObj.Country);
                cmd.Parameters.AddWithValue("@CompanyID", empObj.CompanyID);
                cmd.Parameters.AddWithValue("@CompanyName", empObj.CompanyName);
                cmd.Parameters.AddWithValue("@CompanyType", empObj.CompanyType);
                cmd.Parameters.AddWithValue("@CompanyWebsite", empObj.CompanyWebsite);
                cmd.Parameters.AddWithValue("@CompanyDesc", empObj.CompanyDesc);



                if (cmd.Connection.State == ConnectionState.Closed)
                    cmd.Connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                    employeerUpdated = true;

                cmd.Connection.Close();
                return employeerUpdated;
            }
            catch (EmployerException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public DataTable SearchJobseeker(string skills)
        {
             try
            {
            SqlCommand cmd = DataConfiguration.CreateCommand();
            cmd.CommandText = "SearchJobseeker";
            cmd.Parameters.AddWithValue("@Skills", skills);
            if (cmd.Connection.State == ConnectionState.Closed)
                cmd.Connection.Open();
            SqlDataReader reader = cmd.ExecuteReader();     //Using reader we are fetching data from database
            DataTable searchTable = new DataTable();   //creating data table into data set
            searchTable.Load(reader);                 //Loading data into data set

            cmd.Connection.Close();      
            return searchTable;
            }
             catch (EmployerException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (SystemException)
             {
                 throw;
             }

        }

        public DataTable DisplayVacancy(int empID)
        {
            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "DisplayVacancy";
                cmd.Parameters.AddWithValue("@EmployerID", empID);
                if (cmd.Connection.State == ConnectionState.Closed)
                    cmd.Connection.Open();
                SqlDataReader reader = cmd.ExecuteReader();     //Using reader we are fetching data from database
                DataTable searchTable = new DataTable();   //creating data table into data set
                searchTable.Load(reader);                 //Loading data into data set

                cmd.Connection.Close();
                return searchTable;
            }
            catch (EmployerException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }
    }

}