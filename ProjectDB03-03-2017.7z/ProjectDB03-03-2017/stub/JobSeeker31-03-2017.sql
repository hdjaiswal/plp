
create table ORSGroup6.JobseekersLogin
(
LoginID int identity(1,1) PRIMARY KEY,
EmailAddress varchar(50)UNIQUE,
Password varchar(20),
jobseekerID int 
)
 create table  ORSGroup6.JobseekersPersonalDetails
 (
JobSeekerID int identity(1,1) PRIMARY KEY,
FirstName Varchar(20),
LastName Varchar(20),
MiddleName varchar(20),
ContactNo bigint,
EmailAddress varchar(50)UNIQUE,
Gender varchar(10),
MarraigeStatus varchar(10),
JobSeekersAddress varchar(50),
DOB DateTime
 ) 

  Create Table ORSGroup6.JobSeekerProfessionalDetails
 (
JobSeekerID int Foreign key references ORSGroup6.JobseekersPersonalDetails(jobseekerID) Unique,
CurrentDesignation varchar(20),
PrimarySkills varchar(50),
SecondarySkills varchar(50),
TrainingAttended varchar(30),
Designation varchar(20),
Location varchar(30),
Experience varchar(20),
 )

  Create Table  ORSGroup6.MEQulaification
 (
 QualificationID int identity(1,1) Primary key,
 MEDegree Varchar(20),
 MEBranch Varchar(20),
 MEPassingyear int,
 MEPercentage Decimal,
 MEUniversityName varchar(20),
 JobseekersID int Foreign key references ORSGroup6.JobseekersPersonalDetails(jobseekerID)
 )
   Create Table  ORSGroup6.BEQulaification
 (
 BEQualificationID int identity(1,1) Primary key,
 BEDegree Varchar(20),
BEBranch Varchar(20),
 BEPassingyear int,
 BEPercentage Decimal,
 BEUniversityName varchar(20),
 JobseekersID int Foreign key references ORSGroup6.JobseekersPersonalDetails(jobseekerID)
 )
   Create Table  ORSGroup6.SSCQulaification
 (
 SSCQualificationID int identity(1,1) Primary key,
 SSCPassingyear int,
 SSCPercentage Decimal,
 SSCUniversityName varchar(20),
 JobseekersID int Foreign key references ORSGroup6.JobseekersPersonalDetails(jobseekerID)
 )
   Create Table  ORSGroup6.HSCQulaification
 (
 HSCQualificationID int identity(1,1) Primary key,
 HSCPassingyear int,
 HSCPercentage Decimal,
 HSCUniversityName varchar(20),
 JobseekersID int Foreign key references ORSGroup6.JobseekersPersonalDetails(jobseekerID)
 )
 Select * from ORSGroup6.HSCQulaification
 select * from  ORSGroup6.SSCQulaification
 Select * from  ORSGroup6.BEQulaification
 Select * from ORSGroup6.MEQulaification
 Drop table ORSGroup6.HSCQulaification
 Drop table ORSGroup6.SSCQulaification
 Drop table ORSGroup6.BEQulaification
 Drop table  ORSGroup6.MEQulaification
 
 Create Procedure ORSGroup6.InsertBasicQualification
 (
 @BEDegree Varchar(20),
 @BEBranch Varchar(20),
 @BEPassingyear int,
 @BEPercentage Decimal,
 @BEUniversityName varchar(20),
 @SSCPassingyear int,
 @SSCPercentage Decimal,
 @SSCUniversityName varchar(20),
 @HSCPassingyear int,
 @HSCPercentage Decimal,
 @HSCUniversityName varchar(20),
 @JobseekersID int
 )
 AS
 BEGIN
INSERT INTO  ORSGroup6.BEQulaification Values(@BEDegree,@BEBranch,@BEPassingyear,@BEPercentage,@BEUniversityName,@JobseekersID)
Insert Into ORSGroup6.SSCQulaification Values(@SSCPassingyear,@SSCPercentage,@SSCUniversityName,@JobseekersID)
INSERT Into ORSGroup6.HSCQulaification Values( @HSCPassingyear,@HSCPercentage,@HSCUniversityName,@JobseekersID)
 END

 EXEC ORSGroup6.InsertBasicQualification 'BE','Computer',2017,96.36,'Mumbai',2010,96.36,'Maharashtra',2012,78.69,'Mahatrashtra',1

Create Procedure ORSGroup6.AddMEQualification
 (
  @MEDegree Varchar(20),
 @MEBranch Varchar(20),
 @MEPassingyear int,
 @MEPercentage Decimal,
 @MEUniversityName varchar(20),
 @JobseekersID int
 )
 AS
 BEGIN
 Insert Into  ORSGroup6.MEQulaification Values (@MEDegree,@MEBranch,@MEPassingyear,@MEPercentage,@MEUniversityName,@JobseekersID)
 END

 EXEC ORSGroup6.AddMEQualification 'ME','Computer',2013,64.96,'Mumbai','1'

 Select * from ORSGroup6.MEQulaification

 alter Procedure ORSGroup6.AddJobseekers
(
@EmailAddress varchar(20),
@Password varchar(20),
@FirstName Varchar(20),
@LastName Varchar(20),
@MiddleName varchar(20),
@ContactNo bigint,
@Gender varchar(10),
@MarraigeStatus varchar(10),
@JobSeekersAddress varchar(50),
@DOB DateTime,
@CurrentDesignation varchar(20),
@PrimarySkills varchar(50),
@SecondarySkills varchar(50),
@TrainingAttended varchar(30),
@Designation varchar(20),
@Location varchar(30),
@Experience varchar(20)
)
AS 
Begin 
SET NOCOUNT ON;
DECLARE @JobSeekerID int
if NOT EXISTS (Select * from  ORSGroup6.JobseekersLogin where EmailAddress=@EmailAddress )  
Begin
Insert into ORSGroup6.JobseekersPersonalDetails Values(@FirstName,@LastName,@MiddleName,@ContactNO,@EmailAddress,@Gender,@MarraigeStatus,@JobSeekersAddress,@DOB)
Insert into ORSGroup6.JobseekersLogin Values(@EmailAddress,@Password,scope_identity())
SET @JobSeekerID= (Select  JobSeekerID From ORSGroup6.JobseekersPersonalDetails Where EmailAddress=@EmailAddress)
Insert into ORSGroup6.JobSeekerProfessionalDetails Values(@JobSeekerID,@CurrentDesignation,@PrimarySkills,@SecondarySkills,@TrainingAttended,@Designation,@Location,@Experience)
END
END

EXEC ORSGroup6.AddJobseekers 'kbac@gmail.com','hitna123','Ramesh','Patil','Rao',7896548596,'male','single','Delhi','02/02/1964','Manager','java','ADO.net','SPEAKING','DEVELOPER','Mumbai','2-3'


drop procedure ORSGroup6.AddJobseekers
 
select * from  ORSGroup6.JobseekersPersonalDetails

delete from ORSGroup6.JobseekersPersonalDetails where FirstName='Ramesh';

select * from  ORSGroup6.JobSeekerProfessionalDetails;

truncate table    ORSGroup6.JobSeekerProfessionalDetails;

truncate table ORSGroup6.JobseekersPersonalDetails

select * from ORSGroup6.JobseekersLogin 

delete from ORSGroup6.JobseekersLogin  where LoginID IN (1009,1010,1011,1012,2009,2010,2011,2012,2013)
truncate table ORSGroup6.JobseekersPersonalDetails
Alter procedure   ORSGroup6.VerificationJobseekers
(
@EmailAddress varchar(50),
@Password varchar(20)
)
AS
Begin
 
SET @EmailAddress =(Select EmailAddress from ORSGroup6.JobseekersLogin where EmailAddress=@EmailAddress AND Password=@Password)
Select JobseekerID,FirstName,LastName,MiddleName,ContactNo,Gender,MarraigeStatus,JobSeekersAddress,DOB from  ORSGroup6.JobseekersPersonalDetails  where EmailAddress = @EmailAddress
END

EXEC  ORSGroup6.VerificationJobseekers   'c@gmail.com','hitna123'

Select * from [ORSGroup6].[JobseekersPersonalDetails]
select * from [ORSGroup6].[JobSeekerProfessionalDetails]
select * from [ORSGroup6].[JobseekersLogin]

Alter procedure   ORSGroup6.RetieveJobseekersPersonalDetails
(
@jobseekerID int
)
AS
Begin
Select FirstName,LastName,MiddleName,ContactNo,Gender,MarraigeStatus,JobSeekersAddress,DOB from  ORSGroup6.JobseekersPersonalDetails  where JobSeekerID =  @jobseekerID
END 

exec  ORSGroup6.RetieveJobseekersPersonalDetails 2026

EXEC ORSGroup6.RetieveJobseekersPersonalDetails 1

Alter Procedure ORSGroup6.RetrieveProfessionaldetails
(
@JobSeekerID int
)
AS 
BEGIN
Select CurrentDesignation,PrimarySkills,SecondarySkills,TrainingAttended,Designation,Location,Experience from ORSGroup6.JobSeekerProfessionalDetails Where JobSeekerID=@JobSeekerID
END 

EXEC ORSGroup6.RetrieveProfessionaldetails '1'

Create Procedure ORSGroup6.RetrieveProfessionaldetails
(
@JobSeekerID int
)
AS 
BEGIN
Select * from ORSGroup6.JobSeekerProfessionalDetails Where JobSeekerID=@JobSeekerID
END 









Alter  Procedure ORSGroup6.JSAppliedJobs
(
@EmployeeId int)
AS 
BEGIN 
Declare JobId int,
set JobId = (Select JobId from ORSGroup6.AppliedJobs Where EmployeeID=@EmployeeID)


select * from ORSGroup6.AppliedJobs