Create table ORSGroup6.JobDetails
(
	JobId int identity(1,1) Primary Key,
	CompanyName varchar(20) ,
	Post varchar(20),
	Vacancies int,
	PostedDate datetime,
	LastDate datetime,
	CompanyDescription nvarchar(2000),
	Package Decimal,
	JobLocation varchar(20),
	Experience varchar(20),
	EmployeeID int Foreign key references ORSGroup6.EmployeeDetails(EmployeeID),
	)
select * from ORSGroup6.JobDetails
select * from ORSGroup6.AppliedJobs


Drop table ORSGroup6.JobDetails
Drop table ORSGroup6.AppliedJobs

Create table ORSGroup6.AppliedJobs
(
	JobAppliedId int identity(1,1) Primary key,
	JobId int Foreign key references ORSGroup6.JobDetails(JobId),
	EmployeeId  int ,
	JobSeekerId  int Foreign key references ORSGroup6.JobseekersPersonalDetails(JobSeekerID),
	)

alter Procedure ORSGroup6.AddJobs
(
@CompanyName varchar(20) ,
@Post varchar(20),
@Vacancies int,
@PostedDate datetime,
@LastDate datetime,
@CompanyDescription nvarchar(2000),
@Package Decimal,
@JobLocation varchar(20),
@Experience varchar(20),
@EmployeeID int
)
AS
BEGIN
Insert into ORSGroup6.JobDetails Values(@CompanyName,@Post,@Vacancies,@PostedDate,@LastDate,@CompanyDescription,@Package,@JobLocation,@Experience,@EmployeeID);
END

select * from ORSGroup6.JobDetails;

EXEC ORSGroup6.AddJobs 'syntel','manager',3,'02/02/2010','03/03/2016','greatcomapnny',20.02,'mumbai','2-3',1

EXEC ORSGroup6.AddJobs 'Capgemini','Software Engg',3,'02/23/2015','12/12/2015','Good Company',2.6,'Delhi','0-2',2 

Select * from ORSGroup6.JobDetails 

select * from ORSGroup6.AppliedJobs

DROP table ORSGroup6.JobDetails 

Drop table ORSGroup6.AppliedJobs

Drop Procedure ORSGroup6.ApplyJOBS

alter Procedure ORSGroup6.ApplyJobs
(
@JobId int,
@JobSeekerId int
)
AS 
BEGIN
Declare @EmployeeId int
SET @EmployeeID =(Select EmployeeID From ORSGroup6.JobDetails  where JobId=@JobId )
Insert into ORSGroup6.AppliedJobs values(@JobId,@EmployeeId,@JobSeekerId)
END

EXEC ORSGroup6.ApplyJobs 1,1


Create Procedure ORSGroup6.ViewjobsByEmployee
(
@EmployeeID int
)
AS 
BEGIN 
SELECT  * FROM  ORSGroup6.JobDetails where(EmployeeID=@EmployeeID)
END 

EXEC ORSGroup6.ViewjobsByEmployee 1




CREATE PROCEDURE ORSGroup6.viewsJobseekersDetailsTOEmployees
(
   @EmployeeId int,
   @JobId int
)
AS
BEGIN
select ORSGroup6.JobseekersPersonalDetails.FirstName,
ORSGroup6.JobseekersPersonalDetails.LastName,
ORSGroup6.JobseekersPersonalDetails.ContactNo,
ORSGroup6.JobseekersPersonalDetails.EmailAddress,
ORSGroup6.JobSeekerProfessionalDetails.CurrentDesignation,
ORSGroup6.JobSeekerProfessionalDetails.PrimarySkills,
ORSGroup6.JobSeekerProfessionalDetails.SecondarySkills,
ORSGroup6.JobSeekerProfessionalDetails.TrainingAttended,
ORSGroup6.JobSeekerProfessionalDetails.Designation,
ORSGroup6.JobSeekerProfessionalDetails.Location,
ORSGroup6.JobSeekerProfessionalDetails.Experience
From ORSGroup6.AppliedJobs LEFT OUTER JOIN ORSGroup6.JobDetails on ORSGroup6.JobDetails.JobId=ORSGroup6.AppliedJobs.JobId
LEFT OUTER JOIN ORSGroup6.JobSeekerProfessionalDetails On ORSGroup6.JobSeekerProfessionalDetails.JobSeekerID=ORSGroup6.AppliedJobs.JobSeekerID
LEFT OUTER JOIN ORSGroup6.JobseekersPersonalDetails on ORSGroup6.JobseekersPersonalDetails.JobSeekerID=ORSGroup6.AppliedJobs.JobSeekerID
Where ORSGroup6.AppliedJobs.JobId=@JobId AND ORSGroup6.AppliedJobs.EmployeeId=@EmployeeId
END

select * from ORSGroup6.AppliedJobs;
select * from ORSGroup6.JobDetails;

insert into ORSGroup6.AppliedJobs values (3,1,2);

exec ORSGroup6.viewsJobseekersDetailsTOEmployees 1,1

exec ORSGroup6.ViewsJobAppliedDetails 1,1

Alter PROCEDURE ORSGroup6.SearchbyLocation
( @JobLocation varchar(30) )
AS 
BEGIN
 SELECT * from ORSGroup6.JobDetails where JobDetails.JobLocation=@JobLocation
END

exec  ORSGroup6.SearchbyLocation 'Pune';

Alter PROCEDURE ORSGroup6.SearchbyDesignation
( @Designation varchar(20) )
AS 
BEGIN
 SELECT * from  ORSGroup6.JobDetails where  ORSGroup6.JobDetails.Post=@Designation;
END

exec ORSGroup6.SearchbyDesignation 'Software Analyst'

Alter PROCEDURE ORSGroup6.SearchbyExperience
( @Experience varchar(20) )
AS 
BEGIN
 SELECT * from  ORSGroup6.JobDetails where  ORSGroup6.JobDetails.Experience=@Experience;
END

select * from  ORSGroup6.JobDetails 

Create Procedure ORSGroup6.JSUpdateBEHSCSSCDetails 
(
@JobSeekerID int,
@BEDegree Varchar(20),
 @BEBranch Varchar(20),
 @BEPassingyear int,
 @BEPercentage Decimal,
 @BEUniversityName varchar(20),
 @SSCPassingyear int,
 @SSCPercentage Decimal,
 @SSCUniversityName varchar(20),
 @HSCPassingyear int,
 @HSCPercentage Decimal,
 @HSCUniversityName varchar(20),
 @JobseekersID int
 )
 AS
BEGIN
Update  ORSGroup6.BEQulaification 
SET(BEDegree=@BEDegree,BEBranch=@BEBranch,BEPassingyear=@BEPassingyear,BEPercentage=@BEPercentage,BEUniversityName=@BEUniversityName)where JobseekersID=@JobseekersID
UPDATE ORSGroup6.SSCQulaification SET (SSCPassingyear=@SSCPassingyear,SSCPercentage=@SSCPercentage,SSCUniversityName=@SSCUniversityName)where JobseekersID=@JobseekersID
UPDATE ORSGroup6.HSCQulaification SET (HSCPassingyear=@HSCPassingyear,HSCPercentage=@HSCPercentage,HSCUniversityName=@HSCUniversityName)where JobseekersID=@JobseekersID
END


Create Procedure ORSGroup6.JSUpdateMEDetails 
(
@JobSeekerID int,
@MEDegree Varchar(20),
@MEBranch Varchar(20),
@MEPassingyear int,
@MEPercentage Decimal,
@MEUniversityName varchar(20),
)
AS 
BEGIN
update ORSGroup6.MEQulaification set 
 MEDegree=@MEDegree,
 MEBranch=@MEBranch,
 MEPassingyear=@MEPassingyear,
 MEPercentage=@MEPercentage,
 MEUniversityName=@MEUniversityName)
where
JobseekersID=@JobseekersID
END


CREATE PROCEDURE ORSGroup6.viewsJobseekersDetailsToEmployees
(
   @EmployeeId int,
   @JobId int
)
AS
BEGIN
select ORSGroup6.JobseekersPersonalDetails.FirstName,
ORSGroup6.JobseekersPersonalDetails.LastName,
ORSGroup6.JobseekersPersonalDetails.ContactNo,
ORSGroup6.JobseekersPersonalDetails.EmailAddress,
ORSGroup6.JobSeekerProfessionalDetails.CurrentDesignation,
ORSGroup6.JobSeekerProfessionalDetails.PrimarySkills,
ORSGroup6.JobSeekerProfessionalDetails.SecondarySkills,
ORSGroup6.JobSeekerProfessionalDetails.TrainingAttended,
ORSGroup6.JobSeekerProfessionalDetails.Designation,
ORSGroup6.JobSeekerProfessionalDetails.Location,
ORSGroup6.JobSeekerProfessionalDetails.Experience
From ORSGroup6.AppliedJobs LEFT OUTER JOIN ORSGroup6.JobDetails on ORSGroup6.JobDetails.JobId=ORSGroup6.AppliedJobs.JobId
LEFT OUTER JOIN ORSGroup6.JobSeekerProfessionalDetails On ORSGroup6.JobSeekerProfessionalDetails.JobSeekerID=ORSGroup6.AppliedJobs.JobSeekerID
LEFT OUTER JOIN ORSGroup6.JobseekersPersonalDetails on ORSGroup6.JobseekersPersonalDetails.JobSeekerID=ORSGroup6.AppliedJobs.JobSeekerID
Where ORSGroup6.AppliedJobs.JobId=@JobId AND ORSGroup6.AppliedJobs.EmployeeId=@EmployeeId
END


