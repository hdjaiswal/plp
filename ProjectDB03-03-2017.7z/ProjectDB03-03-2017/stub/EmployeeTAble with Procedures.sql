create Schema ORSGroup6 
-- Employee Login Table 
select * from ORSGroup6.EmployeersLogin
select * from ORSGroup6.EmployeeDetails


Create Table ORSGroup6.EmployeersLogin
(
LoginID int identity(1,1),
EmailAddress varchar(20) UNIQUE,
Password varchar(20),
EmployeeID int 
)
Truncate table ORSGroup6.EmployeeDetails
Drop table ORSGroup6.EmployeersLogin
Drop table ORSGroup6.EmployeeDetails

--Employee Details Table 

create Table ORSGroup6.EmployeeDetails
(
EmployeeID int identity(1,1) Primary key,
FirstName varchar(20),
LastName varchar(20),
CompanyNAme varchar(20),
Designation varchar(20),
Location varchar(20),
ContactNO bigint,
EmailAddress varchar(20)Unique
)

Truncate table  ORSGroup6.EmployeeDetails
-- Procedure to Add new Employee IN BOTH THE TABLES 
Create Procedure ORSGroup6.AddEmployee
(
@FirstName varchar(20),
@LastName varchar(20),
@Companyname varchar(20),
@Designation varchar(20),
@Location varchar(20),
@ContactNO bigint,
@EmailAddress varchar(20),
@Password varchar(20))
AS
BEGIN
insert into ORSGroup6.EmployeeDetails Values(@FirstName,@LastName,@CompanyName,@Designation,@Location,@ContactNO,@EmailAddress)
Insert into ORSGroup6.EmployeersLogin Values(@EmailAddress,@Password,scope_identity())
END

select * from  ORSGroup6.EmployeersLogin



EXEC ORSGroup6AddEmployee 'Riya','sharma','SYntel','ER','Mumbai',78965458957,'riya@gmail.com','raj@123'
EXEC ORSGroup6AddEmployee 'Hitesh','Jaiswal','Microsoft','ER','Banglore',78965458957,'Hitesh@gmail.com','raj@123'
EXEC ORSGroup6AddEmployee 'rajesh','Rao','capgemini','HR','chennai',78965458957,'rajesh@gmail.com','rajesh@123'
EXEC ORSGroup6AddEmployee 'sheeta','khare','bitwise','HR','pune',78965458957,'sheetak@gmail.com','sheeta@123'

Select * from  ORSGroup6.EmployeersLogin where EmailAddress='sheeta@gmail.com'

select * from ORSGroup6.EmployeeDetails

select * from ORSGroup6.EmployeersLogin


Drop Procedure ORSGroup6AddEmployee

Create Procedure ORSGroup6.EmployeeVerification
 (     @EmailAddress NVARCHAR(20),
      @Password NVARCHAR(20)
)
AS
BEGIN
Select EmployeeID from ORSGroup6.EmployeersLogin where EmailAddress=@EmailAddress AND Password=@Password
END

EXEC EmployeeVerification 'riya@gmail.com','raj@123'

select * from  ORSGroup6.EmployeersLogin;

Drop procedure EmployeeVerification


Exec EmployeeVerification 'hiteshjaiswal@gmail.com','123' 
Exec EmployeeVerification 'asdf@gmail.com','raj@123' 
--Procedure to  update EmployeeDetails 
alter Procedure ORSGroup6UpdateEmployee
(
@EmployeeID int,
@FirstName varchar(20),
@LastName varchar(20),
@Companyname varchar(20),
@Designation varchar(20),
@Location varchar(20),
@ContactNO bigint
)
AS
Begin 
Update  ORSGroup6.EmployeeDetails
SET 
FirstName =@FirstName,
LastName =@LastName,
CompanyNAme =@Companyname,
Designation =@Designation,
Location =@Location,
ContactNO=@ContactNO
where 
EmployeeID=@EmployeeID
END

EXEC ORSGroup6UpdateEmployee 1,'Ram','segal','Igate','HR','Delhi',8521479587 
