﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExceptionFile
{
    public class Class1
    {
    }
}
