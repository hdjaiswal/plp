﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;
using System.Data;

namespace WebApplication2
{
    public partial class SearchJobs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"].ToString();
                Master.LogoutVisible = true;
              //  Master.MenuVisible = true;
            }
        }
        JobseekersValidation validationObj = new JobseekersValidation();
        protected void btnExpSearch_Click(object sender, EventArgs e)
        {
            DataTable jsTable = new DataTable();
            string jexp = ddlexp.Text;
            jsTable = validationObj.SearchByExperience(jexp);
            if (jsTable != null)
            {
                gvsrchjob.DataSource = jsTable;
                gvsrchjob.DataBind();
            }
            else
            {
                Response.Write("<script>alert('Search not found')</script>");
            }
        }

        protected void btnDesigSearch_Click(object sender, EventArgs e)
        {
            DataTable jsTable = new DataTable();

            string post = txtdesig.Text;
            jsTable = validationObj.SearchByDesignation(post);
            if (jsTable != null)
            {
                gvsrchjob.DataSource = jsTable;
                gvsrchjob.DataBind();
            }
            else
            {
                Response.Write("<script>alert('Search not found')</script>");
            }
        }

        protected void btnLoctnSearch_Click(object sender, EventArgs e)
        {
            DataTable jsTable = new DataTable();

            string loc = txtloc.Text;
            jsTable = validationObj.SearchByLocation(loc);
            if (jsTable != null)
            {
                gvsrchjob.DataSource = jsTable;
                gvsrchjob.DataBind();
            }
            else
            {
                Response.Write("<script>alert('Search not found')</script>");
            }
        }

        Jobseeker jsObj = new Jobseeker();
        protected void btnApply_Click(object sender, EventArgs e)
        {
            try
            {
                jsObj.JobSeekerID = Convert.ToInt32(txtSrchJSId.Text);
                jsObj.JobID = Convert.ToInt32(txtSrchJId.Text);


                validationObj.ApplyJobs(jsObj);
                Response.Write("<script>alert('Job Applied Successfully')</script>");

            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
           
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}