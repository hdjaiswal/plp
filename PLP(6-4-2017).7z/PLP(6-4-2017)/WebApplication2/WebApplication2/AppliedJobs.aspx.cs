﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;

namespace WebApplication2
{
    public partial class AppliedJobs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["user"] == null || Session["user"] == String.Empty)
            //{
            //    Response.Redirect("LoginPage.aspx");
            //}
            //else
            //{
            // lblUser.Text = "Welcome " + Session["user"];
            Master.LogoutVisible = true;
            // }
        }

        JobseekersValidation validationObj = new JobseekersValidation();
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DataTable jobTable = new DataTable();
            int empid = Convert.ToInt32(txtempid.Text);
            int jobid = Convert.ToInt32(txtJobID.Text);

            jobTable = validationObj.GetAppliedDetails(empid, jobid);

            grdappliedjobs.DataSource = jobTable;

            grdappliedjobs.DataBind();
        }
    }
}