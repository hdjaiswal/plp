﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;


namespace WebApplication2
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
               Jobseeker user = new Jobseeker();
                user.JEmailAddress = txtUser.Text;
                user.JPassword = txtPassword.Text;
                


                string userName = JobseekersValidation.ValidateUser(user);


                if (ddlUserType.Text == "Job Seeker")
                {
                    Session["user"] = userName;
                  //  Session["jsid"] = StaticVariable.JobSeekerID;
                    
                    Response.Redirect("PersonalDetails.aspx");
                }
                else
                {
                    Response.Write("<script>alert('Select Type');</script>");
                }
             
            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
                //lblError.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
                //lblError.Text = ex.Message;
            }
        }

       
    }
}