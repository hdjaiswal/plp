﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;

namespace WebApplication2
{
    public partial class RegistrationEmployer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        EmployersValidation validationObj = new EmployersValidation();
        protected void btnERSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Employer empObj = new Employer();

                empObj.EFirstName = txtEFName.Text;
                empObj.ELastName = txtELName.Text;
                empObj.ECompanyName = txtECName.Text;
                empObj.EDesignation = txtDesignation.Text;
                empObj.ELocation = txtLocation.Text;
                empObj.EPhoneNo = Convert.ToInt64(txtCno.Text);
                empObj.EEmailAddress = txtEAdd.Text;
                empObj.EPassword = txtEpass.Text;

                validationObj.AddEmployeeDetails(empObj);
                Response.Write("<script>alert('Registered Successfully, Please Login')</script>");
               

            }
            catch (EmployersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
          
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
           

        }

    }
}