﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;

namespace WebApplication2
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["user"] == null || Session["user"] == String.Empty)
            //{
            //    Response.Redirect("LoginPage.aspx");
            //}
            //else
            //{
            // lblUser.Text = "Welcome " + Session["user"];
            Master.LogoutVisible = true;
            // }
        }

        JobseekersValidation validationObj = new JobseekersValidation();
        protected void btnPDSubmit_Click(object sender, EventArgs e)
        {
            Jobseeker jsObj=new Jobseeker();
            try
            {


                jsObj.JobSeekerID = Convert.ToInt32(txtJSId.Text);
                jsObj.JCurrentDesig = txtCDesig.Text;
                jsObj.JPrimarySkills = txtPrimerySkills.Text; 
                jsObj.JSecondarySkills = txtSecondarySkills.Text;
                jsObj.JTrainingAttd = txtCertification.Text;
                jsObj.JDesignation = txtDesLocation.Text;
                jsObj.DJobLocation = txtDesLocation.Text;
                jsObj.JExperience = dllExp.Text;


                validationObj.AddJobSeekerPrDetails(jsObj);
                Response.Write("<script>alert('Professional Details are saved successfully')</script>");

            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
           
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}