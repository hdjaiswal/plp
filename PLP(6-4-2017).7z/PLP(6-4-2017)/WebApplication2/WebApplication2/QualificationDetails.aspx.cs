﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;

namespace WebApplication2
{
    public partial class QualificationDetails1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["user"] == null || Session["user"] == String.Empty)
            //{
            //    Response.Redirect("LoginPage.aspx");
            //}
            //else
            //{
            // lblUser.Text = "Welcome " + Session["user"];
            Master.LogoutVisible = true;
            // }
        }
        JobseekersValidation validationObj = new JobseekersValidation();
        protected void btnSave_Click(object sender, EventArgs e)
        {
            Jobseeker jsObj = new Jobseeker();
            try
            {
                jsObj.JobSeekerID = Convert.ToInt32(txtJobSeekerId.Text);
                jsObj.PassingYr = Convert.ToInt32(txtPassingYr.Text);
                jsObj.Percentage = Convert.ToDouble(txtPercentage.Text);
                jsObj.UniversityName = txtUName.Text;

                jsObj.Degree = dllDegree.Text;
                jsObj.Branch = txtBranch.Text;


                validationObj.AddJobSeekerQDetails(jsObj);
                Response.Write("<script>alert('Qualification Details are saved successfully')</script>");

            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
          
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }
    }
}