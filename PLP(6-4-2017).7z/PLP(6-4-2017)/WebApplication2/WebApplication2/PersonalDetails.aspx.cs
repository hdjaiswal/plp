﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;
using System.Data;


namespace WebApplication2
{
    public partial class PersonalDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["user"] == null || Session["user"] == String.Empty)
            //{
            //    Response.Redirect("LoginPage.aspx");
            //}
            //else
            //{
            lblUser.Text = "Welcome " + Session["user"];
         //  lbljsid.Text = "Your ID" + Session["jsid"];

            Master.LogoutVisible = true;
            // }
            JobseekersValidation validationObj=new JobseekersValidation();
            //try
            //{
            string emailaddress = lblUser.Text;
            DataTable dt = new DataTable();
            dt = validationObj.GetPDetails(emailaddress);
            lbljsid.Text = dt.Rows[0]["EmailAddress"].ToString();
            //    if (emp != null)
            //    {
            //        txtJSFName.Text = emp.EmployeeName;
            //        txtJSMName.Text = emp.Phone;
            //        txtJSLName.Text = emp.Email;
            //        txtJSContact.Text = emp.Location;
            //        txtAddress.Text=;
            //        txtDOB.Text=;
            //        ddlistgender.Text=;
            //        ddlmarital.Text=;
            //    }
            //    else
            //    {
            //        string message = "Employee not found with id : " + empID;
            //        throw new EmployeeException(message);
            //    }
            //}
            //catch (EmployeeException ex)
            //{
            //    Response.Write("<script>alert('" + ex.Message + "');</script>");
            //}
            //catch (SystemException ex)
            //{
            //    Response.Write("<script>alert('" + ex.Message + "');</script>");
            //}
        }

        JobseekersValidation validationObj = new JobseekersValidation();

        protected void btnUpdatePd_Click(object sender, EventArgs e)
        {
            Jobseeker updateObj = new Jobseeker();
            try
            {

                updateObj.JFirstName = txtJSFName.Text;
                updateObj.JMiddleName = txtJSMName.Text;
                updateObj.JLastName = txtJSLName.Text;
                updateObj.JDOB = Convert.ToDateTime(txtDOB.Text);
                updateObj.JGender = ddlistgender.Text;
                updateObj.JMaritalStatus = ddlmarital.Text;
                updateObj.JPhoneNo = Convert.ToInt64(txtJSContact.Text);
                updateObj.JAddress = txtAddress.Text;

                bool pupdated=validationObj.UpdatePersonalDetails(updateObj);
                if (pupdated)
                    Response.Write("<script>alert('Personal Details updated Successfully')</script>");
                else
                    Response.Write("<script>alert('Failed to updates Personal Details')</script>");
            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }
    }
}