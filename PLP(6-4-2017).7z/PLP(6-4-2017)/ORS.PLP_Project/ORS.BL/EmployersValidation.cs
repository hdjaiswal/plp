﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace ORS.BL
{
    public class EmployersValidation
    {
        EmployerOperations empOp = new EmployerOperations();

        public bool AddEmployeeDetails(Employer jobj)
        {
            bool jsAdded = false;

            jsAdded = empOp.AddEmployeeDetails(jobj);
            return jsAdded;
        }
        public bool AddJobs(Employer jobj)
        {
            bool jobsAdded = false;

            jobsAdded = empOp.AddJobs(jobj);
            return jobsAdded;
        }
        public DataTable GetEmpID(string email, string password)
        {

            DataTable empTable = empOp.GetEmpID(email, password);
            return empTable;
        }

        public DataTable GetPostedJobs(int empid)
        {

            DataTable jobTable = empOp.GetPostedJobs(empid);
            return jobTable;
        }



    }
}
