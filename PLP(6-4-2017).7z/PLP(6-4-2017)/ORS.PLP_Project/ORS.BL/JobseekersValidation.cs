﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace ORS.BL
{
   public class JobseekersValidation
    {
    JobseekersOperations jsOp = new JobseekersOperations();

        public bool AddJobSeekerPDetails(Jobseeker js)
        {
            bool jsAdded = false;

            jsAdded = jsOp.AddJobSeekerPDetails(js);
            return jsAdded;
        }

        public bool AddJobSeekerQDetails(Jobseeker js)
        {
            bool jsAdded = false;

            jsAdded = jsOp.AddJobSeekerQDetails(js);
            return jsAdded;
        }

        public bool AddJobSeekerPrDetails(Jobseeker js)
        {
            bool jsAdded = false;

            jsAdded = jsOp.AddJobSeekerPrDetails(js);
            return jsAdded;
        }
        public bool ApplyJobs(Jobseeker jobj)
        {
            bool jsApplied = false;
            jsApplied = jsOp.ApplyJobs(jobj);

            return jsApplied;
        }

        public DataTable GetPDetails(string emailaddress)
        {
            DataTable jsdetailsTable = jsOp.GetPDetails(emailaddress);
            return jsdetailsTable;
        }

        public DataTable GetAppliedDetails(int empid, int jsid)
        {
            DataTable jappTable = jsOp.GetAppliedDetails(empid,jsid);
            return jappTable;
        }

        public DataTable GetQualificationDetails()
        {
            DataTable jsTable = jsOp.GetQualificationDetails();
            return jsTable;
        }

        public DataTable GetProfDetails(int jsid)
        {
            DataTable jsdetailsTable = jsOp.GetProfDetails(jsid);
            return jsdetailsTable;
        }

        public DataTable GetJSID(string email, string password)
        {

            DataTable jsTable = jsOp.GetJSID(email, password);
            return jsTable;
        }


        public bool UpdatePersonalDetails(Jobseeker jsObj)
        {
            bool pedUpdated = false;

            pedUpdated = jsOp.UpdatePersonalDetails(jsObj);
            return pedUpdated;
        }

        public bool UpdateProfessionalDetails(Jobseeker jsObj)
        {
            bool profUpdated = false;

            profUpdated = jsOp.UpdateProfessionalDetails(jsObj);
            return profUpdated;
        }

        public DataTable SearchByLocation(string jobloc)
        {
            DataTable jsTable = jsOp.SearchByLocation(jobloc);
            return jsTable;
        }

        public DataTable SearchByDesignation(string jobdesig)
        {
            DataTable jsTable = jsOp.SearchByDesignation(jobdesig);
            return jsTable;
        }

        public DataTable SearchByExperience(string jexp)
        {
            DataTable jsTable = jsOp.SearchByExperience(jexp);
            return jsTable;
        }

        public static string ValidateUser(Jobseeker user)
        {
            string userName = null;

            try
            {
                userName = JobseekersOperations.ValidateLogin(user);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userName;
        }

    }
}
