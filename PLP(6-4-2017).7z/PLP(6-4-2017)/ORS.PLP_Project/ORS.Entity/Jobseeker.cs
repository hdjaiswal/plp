﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.Entity
{
    /// <summary>
    /// Entity to store Jobseeker's Information
    /// Author: Gayatri Yadkikar
    /// Date Modified: 5th April 2017
    /// Version No:
    /// Change Description:
    /// </summary>
     public class Jobseeker
    {
         /// <summary>
        ///  Property to store and retrieve first name
         /// </summary>
        public string JFirstName { get; set; }
         /// <summary>
        ///  Property to store and retrieve Middle name
         /// </summary>
        public string JMiddleName { get; set; }

         /// <summary>
        ///  Property to store and retrieve last name
         /// </summary>
        public string JLastName { get; set; }
         /// <summary>
        ///  Property to store and retrieve email addresss
         /// </summary>
        public string JEmailAddress { get; set; }
         /// <summary>
        ///  Property to store and retrieve password
         /// </summary>
        public string JPassword { get; set; }
         /// <summary>
        ///  Property to store and retrieve Phone no
         /// </summary>
        public Int64 JPhoneNo { get; set; }
         /// <summary>
        ///  Property to store and retrieve Address
         /// </summary>
        public string JAddress { get; set; }
         /// <summary>
        ///  Property to store and retrieve DOB
         /// </summary>
        public DateTime JDOB { get; set; }
         /// <summary>
        /// Property to store and retrieve Gender
         /// </summary>
        public string JGender { get; set; }
         /// <summary>
        ///  Property to store and retrieve MaritalStatus
         /// </summary>
        public string JMaritalStatus { get; set; }

        //Personal Details Jobseeker(used for validation)
       
         /// <summary>
        ///  Property to store and retrieve Confirm Password
         /// </summary>
        public string JCnfPassword { get; set; }
         /// <summary>
        /// Property to store and retrieve Pincode
         /// </summary>
        public Int32 JPincode { get; set; }

        //JobSeeker Qualification
         /// <summary>
        ///  Property to store and retrieve jobseekers Id 
         /// </summary>
        public int JobSeekerID { get; set; }
         /// <summary>
        /// Property to store and retrieve Current Designation
         /// </summary>
        public string JCurrentDesig { get; set; }
         /// <summary>
        ///  Property to store and retrieve Primary Skills
         /// </summary>
        public string JPrimarySkills { get; set; }
         /// <summary>
        ///  Property to store and retrieve Secondary skills
         /// </summary>
        public string JSecondarySkills { get; set; }
         /// <summary>
        /// Property to store and retrieve Training attended
         /// </summary>
        public string JTrainingAttd { get; set; }
         /// <summary>
        /// Property to store and retrieve jobseeker's designation
         /// </summary>
        public string JDesignation { get; set; }
         /// <summary>
        /// Property to store and retrieve jobseeker's Experience
         /// </summary>
        public string JExperience { get; set; }

        public int QualificationID { get; set; }
         /// <summary>
        /// Property to store and retrieve degree
         /// </summary>
        public string Degree { get; set; }
         /// <summary>
        /// Property to store and retrieve Branch
         /// </summary>
        public string Branch { get; set; }
         /// <summary>
        /// Property to store and retrieve Passing year
         /// </summary>
        public int PassingYr { get; set; }
         /// <summary>
        ///Property to store and retrieve Percentage
         /// </summary>
        public double Percentage { get; set; }
         /// <summary>
        /// Property to store and retrieve university name
         /// </summary>
        public string UniversityName { get; set; }
         /// <summary>
         /// Property to store and retrieve desired job location
         /// </summary>
        public string DJobLocation { get; set; }


        public int JobID { get; set; }
       
    }

}
