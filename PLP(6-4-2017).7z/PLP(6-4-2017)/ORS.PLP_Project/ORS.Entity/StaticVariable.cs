﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.Entity
{
   public static class StaticVariable
    {
       public static int JobSeekerID;
    }
}
