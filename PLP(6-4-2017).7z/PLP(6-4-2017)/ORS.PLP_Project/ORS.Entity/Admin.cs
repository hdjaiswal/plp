﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.Entity
{
    /// <summary>
    /// Entity to store Admin Information
    /// Author: Gayatri Yadkikar
    /// Date Modified: 5th April 2017
    /// Version No:
    /// Change Description:
    /// </summary>
    public class Admin
    {
        /// <summary>
        /// Property to store and retrieve username
        /// </summary>
        public string Username { get; set; }
        /// <summary>
        /// Property to store and retrieve password
        /// </summary>
        public string Password { get; set; }
    }
}
