﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.Exception
{
    /// <summary>
    /// Author: Vinay Gupta
    /// Date Modified: 02/04/2017
    /// Description : Class to throw exception
    /// Date of Creation :25/03/2017
    /// </summary>
    public class RecruitmentException : ApplicationException
    {
        //Default Constructor
        public RecruitmentException()
            : base()
        { }

        //Parameterized Constructor
        public RecruitmentException(string message)
            : base(message)
        { }
    }
}
