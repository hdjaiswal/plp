﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminEntity
{
    public static class StaticUserID
    {
        public static int empUserID ;

        public static string empEmail;

        public static string jsEmail;

        public static int jsUserID;
    }
}
