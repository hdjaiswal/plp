﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.Entity
{
    /// <summary>
    /// Author: Vinay Gupta
    /// Date Modified: 02/04/2017
    /// Description : Entity to store Recruitment Information
    /// Date of Creation :25/03/2017
    /// </summary>
    public class Recruitment
    {
        //Users
        public int UserID { get; set; }  //Primary Key
        public string Email { get; set; }
        public string UserPassword { get; set; }   //for password
        public string UserPassword1 { get; set; }  //for confirm password
        public string UserType { get; set; }
        public string P_Phone { get; set; }
        public string S_Phone { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Postalcode { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }

        //Employer
        public int EmployerID { get; set; }  //Primary Key
        public string CompanyID { get; set; }
        public string CompanyName { get; set; }
        public string CompanyType { get; set; }
        public string CompanyWebsite { get; set; }
        public string CompanyDesc { get; set; }
               

        //Jobseeker
        public int JobseekerID { get; set; } //Primary Key
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DOB { get; set; }
        public string Gender { get; set; }
        public string LangKnown { get; set; }
        public string Skills { get; set; }

        //Qualification
        public double SSCMarks { get; set; }
        public DateTime SpYear { get; set; }
        public double HSCMarks { get; set; }
        public DateTime HpYear { get; set; }
        public double DipMarks { get; set; }
        public DateTime DipYear { get; set; }
        public double GradMarks { get; set; }
        public DateTime GpYear { get; set; }
        public double PostGMarks { get; set; }
        public DateTime PostGYear { get; set; }

        //JobHistory
        public string Experience { get; set; }
        public string CompanyName1 { get; set; }
        public string TechWorkedOn { get; set; }
        public string ProjWorkedOn { get; set; }

        //Vacancy
        public int VacancyID { get; set; } //Primary Key
        public string ReqExp { get; set; }
        public string Location { get; set; }
        public string Salary { get; set; }
        public string Position { get; set; }
        public string JobDescription { get; set; }
        public string CompanyName2 { get; set; }
        public string Domain { get; set; }
        public string Category { get; set; }

        public static int empUserID;
    }


}
