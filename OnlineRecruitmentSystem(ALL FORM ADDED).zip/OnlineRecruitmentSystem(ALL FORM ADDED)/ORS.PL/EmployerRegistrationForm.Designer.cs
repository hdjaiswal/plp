﻿namespace ORS.PL
{
    partial class EmployerRegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpbComapnyDetails = new System.Windows.Forms.GroupBox();
            this.txtCompanyType = new System.Windows.Forms.TextBox();
            this.txtusertype = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.txtConfirmPassword = new System.Windows.Forms.TextBox();
            this.txtComapanyWebsite = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtComapanyName = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtCompanyID = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grpbContactDetails = new System.Windows.Forms.GroupBox();
            this.txtPostalCode = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtContactNo2 = new System.Windows.Forms.TextBox();
            this.txtContactNo1 = new System.Windows.Forms.TextBox();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.txtAddress1 = new System.Windows.Forms.TextBox();
            this.cmbCity = new System.Windows.Forms.ComboBox();
            this.cmbState = new System.Windows.Forms.ComboBox();
            this.cmbCountry = new System.Windows.Forms.ComboBox();
            this.labelCity = new System.Windows.Forms.Label();
            this.labelState = new System.Windows.Forms.Label();
            this.lblContactNo2 = new System.Windows.Forms.Label();
            this.lblContactNo1 = new System.Windows.Forms.Label();
            this.labelCountry = new System.Windows.Forms.Label();
            this.lblAddress2 = new System.Windows.Forms.Label();
            this.lblAddress1 = new System.Windows.Forms.Label();
            this.btnRegEmployer = new System.Windows.Forms.Button();
            this.grpbComapnyDetails.SuspendLayout();
            this.grpbContactDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpbComapnyDetails
            // 
            this.grpbComapnyDetails.BackColor = System.Drawing.Color.Transparent;
            this.grpbComapnyDetails.Controls.Add(this.txtCompanyType);
            this.grpbComapnyDetails.Controls.Add(this.txtusertype);
            this.grpbComapnyDetails.Controls.Add(this.label10);
            this.grpbComapnyDetails.Controls.Add(this.txtDescription);
            this.grpbComapnyDetails.Controls.Add(this.txtConfirmPassword);
            this.grpbComapnyDetails.Controls.Add(this.txtComapanyWebsite);
            this.grpbComapnyDetails.Controls.Add(this.txtPassword);
            this.grpbComapnyDetails.Controls.Add(this.txtComapanyName);
            this.grpbComapnyDetails.Controls.Add(this.txtEmail);
            this.grpbComapnyDetails.Controls.Add(this.txtCompanyID);
            this.grpbComapnyDetails.Controls.Add(this.label8);
            this.grpbComapnyDetails.Controls.Add(this.label7);
            this.grpbComapnyDetails.Controls.Add(this.label6);
            this.grpbComapnyDetails.Controls.Add(this.label5);
            this.grpbComapnyDetails.Controls.Add(this.label4);
            this.grpbComapnyDetails.Controls.Add(this.label3);
            this.grpbComapnyDetails.Controls.Add(this.label2);
            this.grpbComapnyDetails.Controls.Add(this.label1);
            this.grpbComapnyDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbComapnyDetails.Location = new System.Drawing.Point(23, 35);
            this.grpbComapnyDetails.Name = "grpbComapnyDetails";
            this.grpbComapnyDetails.Size = new System.Drawing.Size(553, 256);
            this.grpbComapnyDetails.TabIndex = 1;
            this.grpbComapnyDetails.TabStop = false;
            this.grpbComapnyDetails.Text = "Company Details";
            // 
            // txtCompanyType
            // 
            this.txtCompanyType.Location = new System.Drawing.Point(154, 143);
            this.txtCompanyType.Name = "txtCompanyType";
            this.txtCompanyType.Size = new System.Drawing.Size(109, 21);
            this.txtCompanyType.TabIndex = 18;
            // 
            // txtusertype
            // 
            this.txtusertype.Location = new System.Drawing.Point(420, 143);
            this.txtusertype.Name = "txtusertype";
            this.txtusertype.Size = new System.Drawing.Size(110, 21);
            this.txtusertype.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(309, 143);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 15);
            this.label10.TabIndex = 16;
            this.label10.Text = "User Type:";
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(154, 179);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(294, 44);
            this.txtDescription.TabIndex = 14;
            // 
            // txtConfirmPassword
            // 
            this.txtConfirmPassword.Location = new System.Drawing.Point(420, 101);
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.PasswordChar = '*';
            this.txtConfirmPassword.Size = new System.Drawing.Size(110, 21);
            this.txtConfirmPassword.TabIndex = 13;
            // 
            // txtComapanyWebsite
            // 
            this.txtComapanyWebsite.Location = new System.Drawing.Point(154, 100);
            this.txtComapanyWebsite.Name = "txtComapanyWebsite";
            this.txtComapanyWebsite.Size = new System.Drawing.Size(123, 21);
            this.txtComapanyWebsite.TabIndex = 12;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(420, 61);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(110, 21);
            this.txtPassword.TabIndex = 11;
            // 
            // txtComapanyName
            // 
            this.txtComapanyName.Location = new System.Drawing.Point(154, 67);
            this.txtComapanyName.Name = "txtComapanyName";
            this.txtComapanyName.Size = new System.Drawing.Size(123, 21);
            this.txtComapanyName.TabIndex = 10;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(420, 24);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(110, 21);
            this.txtEmail.TabIndex = 9;
            // 
            // txtCompanyID
            // 
            this.txtCompanyID.Location = new System.Drawing.Point(154, 27);
            this.txtCompanyID.Name = "txtCompanyID";
            this.txtCompanyID.Size = new System.Drawing.Size(123, 21);
            this.txtCompanyID.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(20, 179);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 15);
            this.label8.TabIndex = 7;
            this.label8.Text = "Description       :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(20, 143);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "Company Type      :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(283, 103);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(131, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "Confirm Password :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(293, 67);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Password          :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(293, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Email ID           :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Comapny Name     :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Company Website  :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Company ID          :";
            // 
            // grpbContactDetails
            // 
            this.grpbContactDetails.BackColor = System.Drawing.Color.Transparent;
            this.grpbContactDetails.Controls.Add(this.txtPostalCode);
            this.grpbContactDetails.Controls.Add(this.label9);
            this.grpbContactDetails.Controls.Add(this.txtContactNo2);
            this.grpbContactDetails.Controls.Add(this.txtContactNo1);
            this.grpbContactDetails.Controls.Add(this.txtAddress2);
            this.grpbContactDetails.Controls.Add(this.txtAddress1);
            this.grpbContactDetails.Controls.Add(this.cmbCity);
            this.grpbContactDetails.Controls.Add(this.cmbState);
            this.grpbContactDetails.Controls.Add(this.cmbCountry);
            this.grpbContactDetails.Controls.Add(this.labelCity);
            this.grpbContactDetails.Controls.Add(this.labelState);
            this.grpbContactDetails.Controls.Add(this.lblContactNo2);
            this.grpbContactDetails.Controls.Add(this.lblContactNo1);
            this.grpbContactDetails.Controls.Add(this.labelCountry);
            this.grpbContactDetails.Controls.Add(this.lblAddress2);
            this.grpbContactDetails.Controls.Add(this.lblAddress1);
            this.grpbContactDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbContactDetails.Location = new System.Drawing.Point(23, 308);
            this.grpbContactDetails.Name = "grpbContactDetails";
            this.grpbContactDetails.Size = new System.Drawing.Size(566, 308);
            this.grpbContactDetails.TabIndex = 4;
            this.grpbContactDetails.TabStop = false;
            this.grpbContactDetails.Text = "Contact Details";
            // 
            // txtPostalCode
            // 
            this.txtPostalCode.Location = new System.Drawing.Point(350, 200);
            this.txtPostalCode.Name = "txtPostalCode";
            this.txtPostalCode.Size = new System.Drawing.Size(100, 21);
            this.txtPostalCode.TabIndex = 15;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(255, 201);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 15);
            this.label9.TabIndex = 14;
            this.label9.Text = "Postal Code:";
            // 
            // txtContactNo2
            // 
            this.txtContactNo2.Location = new System.Drawing.Point(350, 242);
            this.txtContactNo2.Name = "txtContactNo2";
            this.txtContactNo2.Size = new System.Drawing.Size(100, 21);
            this.txtContactNo2.TabIndex = 13;
            // 
            // txtContactNo1
            // 
            this.txtContactNo1.Location = new System.Drawing.Point(124, 245);
            this.txtContactNo1.Name = "txtContactNo1";
            this.txtContactNo1.Size = new System.Drawing.Size(100, 21);
            this.txtContactNo1.TabIndex = 12;
            // 
            // txtAddress2
            // 
            this.txtAddress2.Location = new System.Drawing.Point(175, 93);
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(299, 21);
            this.txtAddress2.TabIndex = 11;
            // 
            // txtAddress1
            // 
            this.txtAddress1.Location = new System.Drawing.Point(175, 47);
            this.txtAddress1.Name = "txtAddress1";
            this.txtAddress1.Size = new System.Drawing.Size(301, 21);
            this.txtAddress1.TabIndex = 10;
            // 
            // cmbCity
            // 
            this.cmbCity.FormattingEnabled = true;
            this.cmbCity.Items.AddRange(new object[] {
            "Mumbai",
            "Pune",
            "Ahmedabad",
            "Gandhinagar",
            "Panaji",
            "Chennai",
            "Hyderabad",
            "Kolkata",
            "Jaipur"});
            this.cmbCity.Location = new System.Drawing.Point(121, 198);
            this.cmbCity.Name = "cmbCity";
            this.cmbCity.Size = new System.Drawing.Size(103, 23);
            this.cmbCity.TabIndex = 9;
            // 
            // cmbState
            // 
            this.cmbState.FormattingEnabled = true;
            this.cmbState.Items.AddRange(new object[] {
            "Maharashtra",
            "Gujarat",
            "Goa",
            "Karnataka",
            "Tamil Nadu",
            "Telangana",
            "Rajasthan"});
            this.cmbState.Location = new System.Drawing.Point(350, 143);
            this.cmbState.Name = "cmbState";
            this.cmbState.Size = new System.Drawing.Size(98, 23);
            this.cmbState.TabIndex = 8;
            // 
            // cmbCountry
            // 
            this.cmbCountry.FormattingEnabled = true;
            this.cmbCountry.Items.AddRange(new object[] {
            "India"});
            this.cmbCountry.Location = new System.Drawing.Point(124, 143);
            this.cmbCountry.Name = "cmbCountry";
            this.cmbCountry.Size = new System.Drawing.Size(100, 23);
            this.cmbCountry.TabIndex = 7;
            // 
            // labelCity
            // 
            this.labelCity.AutoSize = true;
            this.labelCity.Location = new System.Drawing.Point(55, 201);
            this.labelCity.Name = "labelCity";
            this.labelCity.Size = new System.Drawing.Size(38, 15);
            this.labelCity.TabIndex = 6;
            this.labelCity.Text = "City :";
            // 
            // labelState
            // 
            this.labelState.AutoSize = true;
            this.labelState.Location = new System.Drawing.Point(283, 146);
            this.labelState.Name = "labelState";
            this.labelState.Size = new System.Drawing.Size(48, 15);
            this.labelState.TabIndex = 5;
            this.labelState.Text = "State :";
            // 
            // lblContactNo2
            // 
            this.lblContactNo2.AutoSize = true;
            this.lblContactNo2.Location = new System.Drawing.Point(242, 242);
            this.lblContactNo2.Name = "lblContactNo2";
            this.lblContactNo2.Size = new System.Drawing.Size(101, 15);
            this.lblContactNo2.TabIndex = 4;
            this.lblContactNo2.Text = "Contact No. 2 :";
            // 
            // lblContactNo1
            // 
            this.lblContactNo1.AutoSize = true;
            this.lblContactNo1.Location = new System.Drawing.Point(20, 248);
            this.lblContactNo1.Name = "lblContactNo1";
            this.lblContactNo1.Size = new System.Drawing.Size(97, 15);
            this.lblContactNo1.TabIndex = 3;
            this.lblContactNo1.Text = "Contact No 1 :";
            // 
            // labelCountry
            // 
            this.labelCountry.AutoSize = true;
            this.labelCountry.Location = new System.Drawing.Point(55, 146);
            this.labelCountry.Name = "labelCountry";
            this.labelCountry.Size = new System.Drawing.Size(63, 15);
            this.labelCountry.TabIndex = 2;
            this.labelCountry.Text = "Country :";
            // 
            // lblAddress2
            // 
            this.lblAddress2.AutoSize = true;
            this.lblAddress2.Location = new System.Drawing.Point(55, 99);
            this.lblAddress2.Name = "lblAddress2";
            this.lblAddress2.Size = new System.Drawing.Size(114, 15);
            this.lblAddress2.TabIndex = 1;
            this.lblAddress2.Text = "Address Line 2  :";
            // 
            // lblAddress1
            // 
            this.lblAddress1.AutoSize = true;
            this.lblAddress1.Location = new System.Drawing.Point(55, 53);
            this.lblAddress1.Name = "lblAddress1";
            this.lblAddress1.Size = new System.Drawing.Size(114, 15);
            this.lblAddress1.TabIndex = 0;
            this.lblAddress1.Text = "Address Line 1  :";
            // 
            // btnRegEmployer
            // 
            this.btnRegEmployer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegEmployer.Location = new System.Drawing.Point(245, 633);
            this.btnRegEmployer.Name = "btnRegEmployer";
            this.btnRegEmployer.Size = new System.Drawing.Size(121, 39);
            this.btnRegEmployer.TabIndex = 5;
            this.btnRegEmployer.Text = "Register";
            this.btnRegEmployer.UseVisualStyleBackColor = true;
            this.btnRegEmployer.Click += new System.EventHandler(this.btnRegEmployer_Click);
            // 
            // EmployerRegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ORS.PL.Properties.Resources.Employee_Provident_Fund1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(611, 705);
            this.Controls.Add(this.btnRegEmployer);
            this.Controls.Add(this.grpbContactDetails);
            this.Controls.Add(this.grpbComapnyDetails);
            this.MaximizeBox = false;
            this.Name = "EmployerRegistrationForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpbComapnyDetails.ResumeLayout(false);
            this.grpbComapnyDetails.PerformLayout();
            this.grpbContactDetails.ResumeLayout(false);
            this.grpbContactDetails.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpbComapnyDetails;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.TextBox txtConfirmPassword;
        private System.Windows.Forms.TextBox txtComapanyWebsite;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtComapanyName;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtCompanyID;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpbContactDetails;
        private System.Windows.Forms.TextBox txtContactNo2;
        private System.Windows.Forms.TextBox txtContactNo1;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.TextBox txtAddress1;
        private System.Windows.Forms.ComboBox cmbCity;
        private System.Windows.Forms.ComboBox cmbState;
        private System.Windows.Forms.ComboBox cmbCountry;
        private System.Windows.Forms.Label labelCity;
        private System.Windows.Forms.Label labelState;
        private System.Windows.Forms.Label lblContactNo2;
        private System.Windows.Forms.Label lblContactNo1;
        private System.Windows.Forms.Label labelCountry;
        private System.Windows.Forms.Label lblAddress2;
        private System.Windows.Forms.Label lblAddress1;
        private System.Windows.Forms.Button btnRegEmployer;
        private System.Windows.Forms.TextBox txtPostalCode;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtusertype;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtCompanyType;

    }
}