﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ORS.Entity;
using ORS.Exception;
using ORS.BL;
using AdminEntity;

namespace ORS.PL
{
    public partial class EmployerHomePage : Form
    {
        RecruitmentValidation validationsObj = new RecruitmentValidation();

        public EmployerHomePage()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            LoginForm log = new LoginForm();
            this.Close();
            log.Show();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtVacancyID_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnvacancy_Click(object sender, EventArgs e)
        {
            try
            {
                Recruitment RecObj = new Recruitment();
                RecObj.CompanyName2 = txtCompanyName2.Text;
                RecObj.Position = txtPosition.Text;
                RecObj.ReqExp = txtreqexp.Text;
                RecObj.Salary = txtsalary.Text;
                RecObj.Location = txtLocation.Text;
                RecObj.JobDescription = txtJobDesc.Text;
                RecObj.Domain = txtdomain.Text;
                RecObj.Category = txtcategory.Text;


                bool vacancyAdded = validationsObj.AddVacancyInformation(RecObj);
                if (vacancyAdded)
                {
                    MessageBox.Show("Vacancy Added Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    tabControl1.SelectedIndex = 1;
                }
                else
                    MessageBox.Show("Failed to Add Vacancy", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (RecruitmentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void txtContactNo2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btndisplay_Click(object sender, EventArgs e)
        {

            //txtUserID.Text = AdminEntity.StaticUserID.empEmail.ToString();
            //string email = txtUserID.Text;
            //DataTable dt = new DataTable();
            //dt = validationsObj.DisplayEmployeer(email);
            //lblUserID.Text = dt.Rows[0]["UserID"].ToString();
            //txtCompanyID.Text = dt.Rows[0]["CompanyID"].ToString();
            //txtComapanyWebsite.Text = dt.Rows[0]["CompanyWebsite"].ToString();
            //txtComapanyName.Text = dt.Rows[0]["CompanyName"].ToString();
            //txtcompanytype.Text = dt.Rows[0]["CompanyType"].ToString();
            //txtDescription.Text = dt.Rows[0]["CompanyDesc"].ToString();
            //txtAddress1.Text = dt.Rows[0]["Address1"].ToString();
            //txtAddress2.Text = dt.Rows[0]["Address2"].ToString();
            //txtcountry.Text = dt.Rows[0]["Country"].ToString();
            //txtstate.Text = dt.Rows[0]["State"].ToString();
            //txtcity.Text = dt.Rows[0]["City"].ToString();
            //txtPostalCode.Text = dt.Rows[0]["Postalcode"].ToString();
            //txtContactNo1.Text = dt.Rows[0]["P_Phone"].ToString();
            //txtContactNo2.Text = dt.Rows[0]["S_Phone"].ToString();
            
            
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                Recruitment RecObj = new Recruitment();
                RecObj.UserID = Convert.ToInt32(lblUserID.Text);
                //RecObj.Email = txtEmail.Text;
                RecObj.P_Phone = txtContactNo1.Text;
                RecObj.S_Phone = txtContactNo2.Text;
                RecObj.Address1 = txtAddress1.Text;
                RecObj.Address2 = txtAddress2.Text;
                RecObj.Postalcode = txtPostalCode.Text;
                RecObj.City = txtcity.Text;
                RecObj.State = txtstate.Text;
                RecObj.Country = txtcountry.Text;

                RecObj.CompanyID = txtCompanyID.Text;
                RecObj.CompanyName = txtComapanyName.Text;
                RecObj.CompanyWebsite = txtComapanyWebsite.Text;
                RecObj.CompanyDesc = txtDescription.Text;
                RecObj.CompanyType = txtcompanytype.Text;



                bool employeerUpdated = validationsObj.UpdateEmployeer(RecObj);
                if (employeerUpdated)
                    MessageBox.Show("Employeer Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to Update Employeer record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (RecruitmentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearchByVacancy_Click(object sender, EventArgs e)
        {

            Recruitment RecObj = new Recruitment();
            DataTable searchTable = new DataTable();

            RecObj.Skills = txtSearchBySkills.Text;


            searchTable = validationsObj.SearchJobseeker(RecObj.Skills);

            dgvJobseekerDetails.DataSource = searchTable;
        }

        private void lblUserID_Click(object sender, EventArgs e)
        {

        }

        private void EmployerHomePage_Load(object sender, EventArgs e)
        {
            lblUserID.Text = AdminEntity.StaticUserID.empUserID.ToString();
            int userID = Convert.ToInt32(lblUserID.Text);
            DataTable dt = new DataTable();
            dt = validationsObj.DisplayEmployeer(userID);
            lblUserID.Text = dt.Rows[0]["UserID"].ToString();
            txtCompanyID.Text = dt.Rows[0]["CompanyID"].ToString();
            txtEmail.Text = dt.Rows[0]["Email"].ToString();
            txtComapanyWebsite.Text = dt.Rows[0]["CompanyWebsite"].ToString();
            txtComapanyName.Text = dt.Rows[0]["CompanyName"].ToString();
            txtcompanytype.Text = dt.Rows[0]["CompanyType"].ToString();
            txtDescription.Text = dt.Rows[0]["CompanyDesc"].ToString();
            txtAddress1.Text = dt.Rows[0]["Address1"].ToString();
            txtAddress2.Text = dt.Rows[0]["Address2"].ToString();
            txtcountry.Text = dt.Rows[0]["Country"].ToString();
            txtstate.Text = dt.Rows[0]["State"].ToString();
            txtcity.Text = dt.Rows[0]["City"].ToString();
            txtPostalCode.Text = dt.Rows[0]["Postalcode"].ToString();
            txtContactNo1.Text = dt.Rows[0]["P_Phone"].ToString();
            txtContactNo2.Text = dt.Rows[0]["S_Phone"].ToString();
        }

        private void txtUserID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
