﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ORS.PL
{
    public partial class SignUpForm : Form
    {
        public SignUpForm()
        {
            InitializeComponent();
        }

        private void btnJobSeeker_Click(object sender, EventArgs e)
        {
            this.Hide();
            var myForm1 = new JobSeekerRegistrationForm();
            myForm1.Show();
        }

        private void btnEmployee_Click(object sender, EventArgs e)
        {
            this.Hide();
            var myForm1 = new EmployerRegistrationForm();
            myForm1.Show();
        }
    }
}
