﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ORS.Entity;
using ORS.Exception;
using ORS.BL;
using System.Data.SqlClient;
using AdminEntity;

namespace ORS.PL
{
    public partial class LoginForm : Form
    {
        RecruitmentValidation validationsObj = new RecruitmentValidation();
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                Recruitment RecObj = new Recruitment();
                RecObj.Email = txtEmailId.Text;
                RecObj.UserPassword = txtPassword.Text;
                RecObj.UserType = cmbUserType.Text;

                if (RecObj.UserType == "JOBSEEKER")
                {
                    bool JobseekerVerified = validationsObj.LoginJobseeker(RecObj);
                    if (JobseekerVerified)
                    {
                        var jsForm = new JobSeekerHomePage();
                        jsForm.Show();
                    }
                    else
                    {
                        MessageBox.Show("Failed to Login record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    bool EmployerVerified = validationsObj.LoginEmployer(RecObj);

                    if (EmployerVerified)
                    {
                        var jsForm = new EmployerHomePage();
                        jsForm.Show();
                        MessageBox.Show("User ID is "+AdminEntity.StaticUserID.empUserID+
                            "Email is " + AdminEntity.StaticUserID.empEmail);

                    }
                    else
                    {
                        MessageBox.Show("Failed to Login record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }



            }
            catch (RecruitmentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    
        private void InitializeMyControl()
        {
            // Set to no text.
            txtPassword.Text = "";
            // The password character is an asterisk.
            txtPassword.PasswordChar = '*';
        }

        private void lnkSignUp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            SignUpForm signup = new SignUpForm();
            signup.Show();
            
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }
    }
}
