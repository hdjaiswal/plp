﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ORS.Entity;
using ORS.Exception;
using ORS.BL;
namespace ORS.PL
{
    public partial class EmployerRegistrationForm : Form
    {
        RecruitmentValidation validationsObj = new RecruitmentValidation();
        public EmployerRegistrationForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnRegEmployer_Click(object sender, EventArgs e)
        {
            try
            {
                Recruitment RecObj = new Recruitment();
                RecObj.Email = txtEmail.Text;
                RecObj.UserPassword = txtPassword.Text;
                RecObj.UserPassword1 = txtConfirmPassword.Text;
                RecObj.CompanyID = txtCompanyID.Text;
                RecObj.CompanyName = txtComapanyName.Text;
                RecObj.CompanyWebsite = txtComapanyWebsite.Text;
                RecObj.CompanyType = txtCompanyType.Text;
                RecObj.CompanyDesc = txtDescription.Text;
                RecObj.Address1 = txtAddress1.Text;
                RecObj.Address2 = txtAddress2.Text;
                RecObj.Country = cmbCountry.Text;
                RecObj.State = cmbState.Text;
                RecObj.City = cmbCity.Text;
                RecObj.P_Phone = txtContactNo1.Text;
                RecObj.S_Phone = txtContactNo2.Text;
                RecObj.Postalcode = txtPostalCode.Text;
                RecObj.UserType = txtusertype.Text;  //added new    RecObj.UserType = "";
 

                bool employerAdded = validationsObj.AddEmployerInformation(RecObj);
                if (employerAdded)
                {
                    MessageBox.Show("Employer Registered Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    var loginform = new LoginForm();
                    loginform.Show();
                }
                else
                    MessageBox.Show("Failed to Register", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (RecruitmentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    
        }
    }
