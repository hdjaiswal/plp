﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ORS.Entity;
using ORS.Exception;
using ORS.BL;
using System.Data.SqlClient;

namespace ORS.PL
{
    public partial class JobSeekerHomePage : Form
    {
        RecruitmentValidation validationsObj = new RecruitmentValidation();
        public JobSeekerHomePage()
        {
            InitializeComponent();
        }

        private void label44_Click(object sender, EventArgs e)
        {

        }

        private void label42_Click(object sender, EventArgs e)
        {

        }

        private void label41_Click(object sender, EventArgs e)
        {

        }

        private void label40_Click(object sender, EventArgs e)
        {

        }

        private void label50_Click(object sender, EventArgs e)
        {

        }

        private void label48_Click(object sender, EventArgs e)
        {

        }


        private void JobSeekerHomePage_Load(object sender, EventArgs e)
        {
            lblUserID.Text = AdminEntity.StaticUserID.jsUserID.ToString();
            int userID = Convert.ToInt32(lblUserID.Text);
            DataTable dt = new DataTable();
            dt = validationsObj.DisplayJobseeker(userID);
            lblUserID.Text = dt.Rows[0]["UserID"].ToString();
            txtEmail.Text=dt.Rows[0]["Email"].ToString();
            txtFirstName.Text = dt.Rows[0]["FirstName"].ToString();
            txtLastName.Text = dt.Rows[0]["LastName"].ToString();
            txtDOB.Text = dt.Rows[0]["DOB"].ToString();
            txtGender.Text = dt.Rows[0]["Gender"].ToString();
            txtLang.Text = dt.Rows[0]["LangKnown"].ToString();
            txtAdd1.Text = dt.Rows[0]["Address1"].ToString();
            txtAdd2.Text = dt.Rows[0]["Address2"].ToString();
            txtCountry.Text = dt.Rows[0]["Country"].ToString();
            txtState.Text = dt.Rows[0]["State"].ToString();
            txtCity.Text = dt.Rows[0]["City"].ToString();
            txtPostalCode.Text = dt.Rows[0]["Postalcode"].ToString();
            txtContact1.Text = dt.Rows[0]["P_Phone"].ToString();
            txtContact2.Text = dt.Rows[0]["S_Phone"].ToString();
            txtSSP.Text = dt.Rows[0]["SSCMarks"].ToString();
            txtSSCPY.Text = dt.Rows[0]["SpYear"].ToString();
            txtHSCP.Text = dt.Rows[0]["HSCMarks"].ToString();
            txtHSCPY.Text = dt.Rows[0]["HpYear"].ToString();
            txtDIPP.Text = dt.Rows[0]["DipMarks"].ToString();
            txtDPY.Text = dt.Rows[0]["DipYear"].ToString();
            txtGP.Text = dt.Rows[0]["GradMarks"].ToString();
            txtGPY.Text = dt.Rows[0]["GpYear"].ToString();
            txtPGP.Text = dt.Rows[0]["PostGMarks"].ToString();
            txtPGPY.Text = dt.Rows[0]["PostGYear"].ToString();

            txtExp.Text = dt.Rows[0]["Experience"].ToString();
            txtCompName.Text = dt.Rows[0]["CompanyName"].ToString();
            txtTechWO.Text = dt.Rows[0]["TechWorkedOn"].ToString();
            txtPWO.Text = dt.Rows[0]["ProjWorkedOn"].ToString();
            txtPS.Text = dt.Rows[0]["Skills"].ToString();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void btnLogout_click(object sender, EventArgs e)
        {
            LoginForm log = new LoginForm();
            this.Close();
            log.Show();
        }

        //private void btnEditProfile_Click(object sender, EventArgs e)
        //{
        //    UpdateInfo update = new UpdateInfo();
        //    update.Show();
        //}

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            int userID = Convert.ToInt32(lblUserID.Text);
            DataTable dt = new DataTable();
            dt = validationsObj.DisplayJobseeker(userID);
            lblUserID.Text = dt.Rows[0]["UserID"].ToString();
            txtEmail.Text=dt.Rows[0]["Email"].ToString();
            txtFirstName.Text = dt.Rows[0]["FirstName"].ToString();
            txtLastName.Text = dt.Rows[0]["LastName"].ToString();
            txtDOB.Text = dt.Rows[0]["DOB"].ToString();
            txtGender.Text=dt.Rows[0]["Gender"].ToString();
            txtLang.Text = dt.Rows[0]["LangKnown"].ToString();
            txtAdd1.Text = dt.Rows[0]["Address1"].ToString();
            txtAdd2.Text = dt.Rows[0]["Address2"].ToString();
            txtCountry.Text=dt.Rows[0]["Country"].ToString();
            txtState.Text = dt.Rows[0]["State"].ToString();
            txtCity.Text = dt.Rows[0]["City"].ToString();
            txtPostalCode.Text = dt.Rows[0]["Postalcode"].ToString();
            txtContact1.Text = dt.Rows[0]["P_Phone"].ToString();
            txtContact2.Text = dt.Rows[0]["S_Phone"].ToString();

            txtSSP.Text = dt.Rows[0]["SSCMarks"].ToString();
            txtSSCPY.Text = dt.Rows[0]["SpYear"].ToString();
            txtHSCP.Text = dt.Rows[0]["HSCMarks"].ToString();
            txtHSCPY.Text = dt.Rows[0]["HpYear"].ToString();
            txtDIPP.Text = dt.Rows[0]["DipMarks"].ToString();
            txtDPY.Text = dt.Rows[0]["DipYear"].ToString();
            txtGP.Text = dt.Rows[0]["GradMarks"].ToString();
            txtGPY.Text = dt.Rows[0]["GpYear"].ToString();
            txtPGP.Text = dt.Rows[0]["PostGMarks"].ToString();
            txtPGPY.Text = dt.Rows[0]["PostGYear"].ToString();

            txtExp.Text = dt.Rows[0]["Experience"].ToString();
            txtCompName.Text = dt.Rows[0]["CompanyName"].ToString();
            txtTechWO.Text = dt.Rows[0]["TechWorkedOn"].ToString();
            txtPWO.Text = dt.Rows[0]["ProjWorkedOn"].ToString();
            txtPS.Text = dt.Rows[0]["Skills"].ToString();
            
        }

        //private void btnGo_Click_1(object sender, EventArgs e)
        //{

        //}

        private void btnsearch_Click(object sender, EventArgs e)
        {
            Recruitment RecObj = new Recruitment();
            DataTable searchTable = new DataTable();

            RecObj.ReqExp = txtreqexp.Text;
            RecObj.Location = txtloc.Text;
            RecObj.Salary = txtepsal.Text;
            RecObj.Position = txtJobSeekerPosition.Text;


            searchTable = validationsObj.SearchJob(RecObj.ReqExp, RecObj.Location, RecObj.Salary, RecObj.Position);

            dgvShowVacancies.DataSource = searchTable;
        }

        private void btnEditProfile_Click_1(object sender, EventArgs e)
        {
            try
            {
                Recruitment RecObj = new Recruitment();
                RecObj.UserID = Convert.ToInt32(lblUserID.Text);
                //RecObj.Email = txtEmail.Text;
                RecObj.P_Phone = txtContact1.Text;
                RecObj.S_Phone = txtContact2.Text;
                RecObj.Address1 = txtAdd1.Text;
                RecObj.Address2 = txtAdd2.Text;
                RecObj.Postalcode = txtPostalCode.Text;
                RecObj.City = txtCity.Text;
                RecObj.State = txtState.Text;
                RecObj.Country = txtCountry.Text;
                

                RecObj.FirstName = txtFirstName.Text;
                RecObj.LastName = txtLastName.Text;
                RecObj.DOB = Convert.ToDateTime(txtDOB.Text);
                RecObj.Gender = txtGender.Text;
                RecObj.LangKnown = txtLang.Text;
                RecObj.Skills = txtPS.Text;

                RecObj.SSCMarks = Convert.ToDouble(txtSSP.Text);
                RecObj.SpYear = Convert.ToDateTime(txtSSCPY.Text);
                RecObj.HSCMarks = Convert.ToDouble(txtHSCP.Text); ;
                RecObj.HpYear = Convert.ToDateTime(txtHSCPY.Text);
                RecObj.DipMarks = Convert.ToDouble(txtDIPP.Text);
                RecObj.DipYear = Convert.ToDateTime(txtDPY.Text);
                RecObj.GradMarks = Convert.ToDouble(txtGP.Text);
                RecObj.GpYear = Convert.ToDateTime(txtGPY.Text);
                RecObj.PostGMarks = Convert.ToDouble(txtPGP.Text);
                RecObj.PostGYear = Convert.ToDateTime(txtPGPY.Text);

                RecObj.Experience = txtExp.Text;
                RecObj.CompanyName1 = txtCompName.Text;
                RecObj.TechWorkedOn = txtTechWO.Text;
                RecObj.ProjWorkedOn = txtPWO.Text;


                bool jobseekerUpdated = validationsObj.UpdateJobseeker(RecObj);
                if (jobseekerUpdated)
                    MessageBox.Show("JobSeeker Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to Update Jobseeker record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (RecruitmentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void tabPage1_Click_1(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }
    }
}