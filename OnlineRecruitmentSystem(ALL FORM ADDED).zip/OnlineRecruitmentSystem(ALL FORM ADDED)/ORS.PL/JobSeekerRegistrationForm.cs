﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ORS.Entity;
using ORS.Exception;
using ORS.BL;
using System.Data.SqlClient;

namespace ORS.PL
{
    public partial class JobSeekerRegistrationForm : Form
    {
        RecruitmentValidation validationsObj = new RecruitmentValidation();
        public JobSeekerRegistrationForm()
        {
            InitializeComponent();
        }

        private void btnNext1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }

        private void btnNext2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 2;
        }

        private void btnPrev2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRegisterJ_Click(object sender, EventArgs e)
        {
            try
            {
                Recruitment RecObj = new Recruitment();
                RecObj.Email = txtEmail.Text;
                RecObj.UserPassword = txtPassword.Text;
                RecObj.UserPassword1 = txtConfirmPassword.Text;
                RecObj.P_Phone = txtContactNo1.Text;
                RecObj.S_Phone = txtContactNo2.Text;
                RecObj.Address1 = txtAddress1.Text;
                RecObj.Address2 = txtAddress2.Text;
                RecObj.Postalcode = txtPostalCode.Text;
                RecObj.City = cmbCity.Text;
                RecObj.State = cmbState.Text;
                RecObj.Country = cmbCountry.Text;
                RecObj.UserType = txtusertype.Text;  //added new RecObj.UserType = "";

                RecObj.FirstName = txtFirstName.Text;
                RecObj.LastName = txtLastName.Text;
                RecObj.DOB = dateTimePicker2.Value;
                RecObj.Gender = cmbGender.Text;
                RecObj.LangKnown = txtLanguages.Text;
                RecObj.Skills = txtSkills.Text;

                RecObj.SSCMarks = Convert.ToDouble(txtSSCPercent.Text);
                RecObj.SpYear = Convert.ToDateTime(txtSSCPY.Text);
                RecObj.HSCMarks = Convert.ToDouble(txtHSCPercent.Text); ;
                RecObj.HpYear = Convert.ToDateTime(txtHSCPY.Text);
                RecObj.DipMarks = Convert.ToDouble(txtDiplomaPercent.Text);
                RecObj.DipYear = Convert.ToDateTime(txtDiplomaPY.Text);
                RecObj.GradMarks = Convert.ToDouble(txtGradPercent.Text);
                RecObj.GpYear = Convert.ToDateTime(txtGradPY.Text);
                RecObj.PostGMarks = Convert.ToDouble(txtPostGradPercent.Text);
                RecObj.PostGYear = Convert.ToDateTime(txtPostGradPY.Text);

                RecObj.Experience = txtExperience.Text;
                RecObj.CompanyName1 = txtCompanyName1.Text;
                RecObj.TechWorkedOn = txtTechnologies.Text;
                RecObj.ProjWorkedOn = txtProjWorkedOn.Text;


                bool jobseekerAdded = validationsObj.AddJobseekerInformation(RecObj);
                if (jobseekerAdded)
                {
                    MessageBox.Show("JobSeeker Registered Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    var loginform = new LoginForm();
                    loginform.Show();
                }
                else
                {
                    MessageBox.Show("Failed to add jobseeker record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (RecruitmentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }
    }
}
