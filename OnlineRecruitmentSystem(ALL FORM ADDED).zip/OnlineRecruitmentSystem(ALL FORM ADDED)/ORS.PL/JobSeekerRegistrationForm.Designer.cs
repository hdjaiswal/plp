﻿namespace ORS.PL
{
    partial class JobSeekerRegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.grpbLogin = new System.Windows.Forms.GroupBox();
            this.txtusertype = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.lblConfirmPassword = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtConfirmPassword = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.btnNext1 = new System.Windows.Forms.Button();
            this.grpbContactDetails = new System.Windows.Forms.GroupBox();
            this.txtPostalCode = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtContactNo2 = new System.Windows.Forms.TextBox();
            this.txtContactNo1 = new System.Windows.Forms.TextBox();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.txtAddress1 = new System.Windows.Forms.TextBox();
            this.cmbCity = new System.Windows.Forms.ComboBox();
            this.cmbState = new System.Windows.Forms.ComboBox();
            this.cmbCountry = new System.Windows.Forms.ComboBox();
            this.labelCity = new System.Windows.Forms.Label();
            this.labelState = new System.Windows.Forms.Label();
            this.lblContactNo2 = new System.Windows.Forms.Label();
            this.lblContactNo1 = new System.Windows.Forms.Label();
            this.labelCountry = new System.Windows.Forms.Label();
            this.lblAddress2 = new System.Windows.Forms.Label();
            this.lblAddress1 = new System.Windows.Forms.Label();
            this.grpbPersonalDetails = new System.Windows.Forms.GroupBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.cmbGender = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLanguages = new System.Windows.Forms.TextBox();
            this.lblLanguages = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnNext2 = new System.Windows.Forms.Button();
            this.grpbSkillSet = new System.Windows.Forms.GroupBox();
            this.txtSkills = new System.Windows.Forms.TextBox();
            this.lblSkills = new System.Windows.Forms.Label();
            this.grpbQualification = new System.Windows.Forms.GroupBox();
            this.txtPostGradPY = new System.Windows.Forms.TextBox();
            this.txtGradPY = new System.Windows.Forms.TextBox();
            this.txtDiplomaPY = new System.Windows.Forms.TextBox();
            this.txtHSCPY = new System.Windows.Forms.TextBox();
            this.txtSSCPY = new System.Windows.Forms.TextBox();
            this.txtPostGradPercent = new System.Windows.Forms.TextBox();
            this.txtGradPercent = new System.Windows.Forms.TextBox();
            this.txtDiplomaPercent = new System.Windows.Forms.TextBox();
            this.txtHSCPercent = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtSSCPercent = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnRegisterJ = new System.Windows.Forms.Button();
            this.btnPrev2 = new System.Windows.Forms.Button();
            this.grpbJobHistory = new System.Windows.Forms.GroupBox();
            this.txtExperience = new System.Windows.Forms.TextBox();
            this.txtProjWorkedOn = new System.Windows.Forms.TextBox();
            this.lblProjWorkedOn = new System.Windows.Forms.Label();
            this.txtTechnologies = new System.Windows.Forms.TextBox();
            this.txtCompanyName1 = new System.Windows.Forms.TextBox();
            this.lblTechnology = new System.Windows.Forms.Label();
            this.lblCompanyName = new System.Windows.Forms.Label();
            this.lblExp = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.grpbLogin.SuspendLayout();
            this.grpbContactDetails.SuspendLayout();
            this.grpbPersonalDetails.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.grpbSkillSet.SuspendLayout();
            this.grpbQualification.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.grpbJobHistory.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(35, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(664, 748);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackgroundImage = global::ORS.PL.Properties.Resources.images__2_;
            this.tabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage1.Controls.Add(this.grpbLogin);
            this.tabPage1.Controls.Add(this.btnNext1);
            this.tabPage1.Controls.Add(this.grpbContactDetails);
            this.tabPage1.Controls.Add(this.grpbPersonalDetails);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(656, 722);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Personal Information";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // grpbLogin
            // 
            this.grpbLogin.Controls.Add(this.txtusertype);
            this.grpbLogin.Controls.Add(this.label22);
            this.grpbLogin.Controls.Add(this.lblConfirmPassword);
            this.grpbLogin.Controls.Add(this.lblPassword);
            this.grpbLogin.Controls.Add(this.txtConfirmPassword);
            this.grpbLogin.Controls.Add(this.txtPassword);
            this.grpbLogin.Controls.Add(this.txtEmail);
            this.grpbLogin.Controls.Add(this.lblEmail);
            this.grpbLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbLogin.Location = new System.Drawing.Point(34, 30);
            this.grpbLogin.Name = "grpbLogin";
            this.grpbLogin.Size = new System.Drawing.Size(559, 112);
            this.grpbLogin.TabIndex = 8;
            this.grpbLogin.TabStop = false;
            this.grpbLogin.Text = "Login Details";
            // 
            // txtusertype
            // 
            this.txtusertype.Location = new System.Drawing.Point(425, 26);
            this.txtusertype.Name = "txtusertype";
            this.txtusertype.Size = new System.Drawing.Size(111, 21);
            this.txtusertype.TabIndex = 19;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(340, 26);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(79, 15);
            this.label22.TabIndex = 18;
            this.label22.Text = "User Type :";
            // 
            // lblConfirmPassword
            // 
            this.lblConfirmPassword.AutoSize = true;
            this.lblConfirmPassword.Location = new System.Drawing.Point(12, 81);
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            this.lblConfirmPassword.Size = new System.Drawing.Size(135, 15);
            this.lblConfirmPassword.TabIndex = 17;
            this.lblConfirmPassword.Text = "Confirm Password  :";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(12, 52);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(133, 15);
            this.lblPassword.TabIndex = 16;
            this.lblPassword.Text = "Password               :";
            // 
            // txtConfirmPassword
            // 
            this.txtConfirmPassword.Location = new System.Drawing.Point(177, 71);
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.PasswordChar = '*';
            this.txtConfirmPassword.Size = new System.Drawing.Size(138, 21);
            this.txtConfirmPassword.TabIndex = 15;
            this.txtConfirmPassword.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(177, 45);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(138, 21);
            this.txtPassword.TabIndex = 14;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(177, 23);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(138, 21);
            this.txtEmail.TabIndex = 12;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(12, 26);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(134, 15);
            this.lblEmail.TabIndex = 9;
            this.lblEmail.Text = "Email ID                 :";
            // 
            // btnNext1
            // 
            this.btnNext1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext1.Location = new System.Drawing.Point(503, 689);
            this.btnNext1.Name = "btnNext1";
            this.btnNext1.Size = new System.Drawing.Size(90, 24);
            this.btnNext1.TabIndex = 3;
            this.btnNext1.Text = "Next >>";
            this.btnNext1.UseVisualStyleBackColor = true;
            this.btnNext1.Click += new System.EventHandler(this.btnNext1_Click);
            // 
            // grpbContactDetails
            // 
            this.grpbContactDetails.Controls.Add(this.txtPostalCode);
            this.grpbContactDetails.Controls.Add(this.label21);
            this.grpbContactDetails.Controls.Add(this.txtContactNo2);
            this.grpbContactDetails.Controls.Add(this.txtContactNo1);
            this.grpbContactDetails.Controls.Add(this.txtAddress2);
            this.grpbContactDetails.Controls.Add(this.txtAddress1);
            this.grpbContactDetails.Controls.Add(this.cmbCity);
            this.grpbContactDetails.Controls.Add(this.cmbState);
            this.grpbContactDetails.Controls.Add(this.cmbCountry);
            this.grpbContactDetails.Controls.Add(this.labelCity);
            this.grpbContactDetails.Controls.Add(this.labelState);
            this.grpbContactDetails.Controls.Add(this.lblContactNo2);
            this.grpbContactDetails.Controls.Add(this.lblContactNo1);
            this.grpbContactDetails.Controls.Add(this.labelCountry);
            this.grpbContactDetails.Controls.Add(this.lblAddress2);
            this.grpbContactDetails.Controls.Add(this.lblAddress1);
            this.grpbContactDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbContactDetails.Location = new System.Drawing.Point(36, 392);
            this.grpbContactDetails.Name = "grpbContactDetails";
            this.grpbContactDetails.Size = new System.Drawing.Size(557, 291);
            this.grpbContactDetails.TabIndex = 2;
            this.grpbContactDetails.TabStop = false;
            this.grpbContactDetails.Text = "Contact Details";
            // 
            // txtPostalCode
            // 
            this.txtPostalCode.Location = new System.Drawing.Point(140, 178);
            this.txtPostalCode.Name = "txtPostalCode";
            this.txtPostalCode.Size = new System.Drawing.Size(100, 21);
            this.txtPostalCode.TabIndex = 15;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(10, 181);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(96, 15);
            this.label21.TabIndex = 14;
            this.label21.Text = "Postal Code  :";
            // 
            // txtContactNo2
            // 
            this.txtContactNo2.Location = new System.Drawing.Point(138, 248);
            this.txtContactNo2.Name = "txtContactNo2";
            this.txtContactNo2.Size = new System.Drawing.Size(132, 21);
            this.txtContactNo2.TabIndex = 13;
            // 
            // txtContactNo1
            // 
            this.txtContactNo1.Location = new System.Drawing.Point(138, 212);
            this.txtContactNo1.Name = "txtContactNo1";
            this.txtContactNo1.Size = new System.Drawing.Size(132, 21);
            this.txtContactNo1.TabIndex = 12;
            // 
            // txtAddress2
            // 
            this.txtAddress2.Location = new System.Drawing.Point(138, 94);
            this.txtAddress2.Multiline = true;
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(323, 20);
            this.txtAddress2.TabIndex = 11;
            // 
            // txtAddress1
            // 
            this.txtAddress1.Location = new System.Drawing.Point(138, 46);
            this.txtAddress1.Multiline = true;
            this.txtAddress1.Name = "txtAddress1";
            this.txtAddress1.Size = new System.Drawing.Size(326, 20);
            this.txtAddress1.TabIndex = 10;
            // 
            // cmbCity
            // 
            this.cmbCity.FormattingEnabled = true;
            this.cmbCity.Items.AddRange(new object[] {
            "Mumbai",
            "Pune",
            "Ahmedabad",
            "Gandhinagar",
            "Panaji",
            "Chennai",
            "Hyderabad",
            "Kolkata",
            "Jaipur"});
            this.cmbCity.Location = new System.Drawing.Point(439, 135);
            this.cmbCity.Name = "cmbCity";
            this.cmbCity.Size = new System.Drawing.Size(103, 23);
            this.cmbCity.TabIndex = 9;
            // 
            // cmbState
            // 
            this.cmbState.FormattingEnabled = true;
            this.cmbState.Items.AddRange(new object[] {
            "Maharashtra",
            "Gujarat",
            "Goa",
            "Karnataka",
            "Tamil Nadu",
            "Telangana",
            "Rajasthan"});
            this.cmbState.Location = new System.Drawing.Point(261, 135);
            this.cmbState.Name = "cmbState";
            this.cmbState.Size = new System.Drawing.Size(105, 23);
            this.cmbState.TabIndex = 8;
            // 
            // cmbCountry
            // 
            this.cmbCountry.FormattingEnabled = true;
            this.cmbCountry.Items.AddRange(new object[] {
            "India"});
            this.cmbCountry.Location = new System.Drawing.Point(80, 135);
            this.cmbCountry.Name = "cmbCountry";
            this.cmbCountry.Size = new System.Drawing.Size(100, 23);
            this.cmbCountry.TabIndex = 7;
            // 
            // labelCity
            // 
            this.labelCity.AutoSize = true;
            this.labelCity.Location = new System.Drawing.Point(395, 138);
            this.labelCity.Name = "labelCity";
            this.labelCity.Size = new System.Drawing.Size(38, 15);
            this.labelCity.TabIndex = 6;
            this.labelCity.Text = "City :";
            // 
            // labelState
            // 
            this.labelState.AutoSize = true;
            this.labelState.Location = new System.Drawing.Point(207, 138);
            this.labelState.Name = "labelState";
            this.labelState.Size = new System.Drawing.Size(48, 15);
            this.labelState.TabIndex = 5;
            this.labelState.Text = "State :";
            // 
            // lblContactNo2
            // 
            this.lblContactNo2.AutoSize = true;
            this.lblContactNo2.Location = new System.Drawing.Point(11, 254);
            this.lblContactNo2.Name = "lblContactNo2";
            this.lblContactNo2.Size = new System.Drawing.Size(101, 15);
            this.lblContactNo2.TabIndex = 4;
            this.lblContactNo2.Text = "Contact No. 2 :";
            // 
            // lblContactNo1
            // 
            this.lblContactNo1.AutoSize = true;
            this.lblContactNo1.Location = new System.Drawing.Point(11, 218);
            this.lblContactNo1.Name = "lblContactNo1";
            this.lblContactNo1.Size = new System.Drawing.Size(101, 15);
            this.lblContactNo1.TabIndex = 3;
            this.lblContactNo1.Text = "Contact No 1  :";
            // 
            // labelCountry
            // 
            this.labelCountry.AutoSize = true;
            this.labelCountry.Location = new System.Drawing.Point(11, 138);
            this.labelCountry.Name = "labelCountry";
            this.labelCountry.Size = new System.Drawing.Size(63, 15);
            this.labelCountry.TabIndex = 2;
            this.labelCountry.Text = "Country :";
            // 
            // lblAddress2
            // 
            this.lblAddress2.AutoSize = true;
            this.lblAddress2.Location = new System.Drawing.Point(11, 97);
            this.lblAddress2.Name = "lblAddress2";
            this.lblAddress2.Size = new System.Drawing.Size(114, 15);
            this.lblAddress2.TabIndex = 1;
            this.lblAddress2.Text = "Address Line 2  :";
            // 
            // lblAddress1
            // 
            this.lblAddress1.AutoSize = true;
            this.lblAddress1.Location = new System.Drawing.Point(10, 49);
            this.lblAddress1.Name = "lblAddress1";
            this.lblAddress1.Size = new System.Drawing.Size(114, 15);
            this.lblAddress1.TabIndex = 0;
            this.lblAddress1.Text = "Address Line 1  :";
            // 
            // grpbPersonalDetails
            // 
            this.grpbPersonalDetails.Controls.Add(this.dateTimePicker2);
            this.grpbPersonalDetails.Controls.Add(this.cmbGender);
            this.grpbPersonalDetails.Controls.Add(this.label3);
            this.grpbPersonalDetails.Controls.Add(this.txtLanguages);
            this.grpbPersonalDetails.Controls.Add(this.lblLanguages);
            this.grpbPersonalDetails.Controls.Add(this.label1);
            this.grpbPersonalDetails.Controls.Add(this.label2);
            this.grpbPersonalDetails.Controls.Add(this.txtLastName);
            this.grpbPersonalDetails.Controls.Add(this.txtFirstName);
            this.grpbPersonalDetails.Controls.Add(this.label4);
            this.grpbPersonalDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbPersonalDetails.Location = new System.Drawing.Point(36, 151);
            this.grpbPersonalDetails.Name = "grpbPersonalDetails";
            this.grpbPersonalDetails.Size = new System.Drawing.Size(557, 235);
            this.grpbPersonalDetails.TabIndex = 1;
            this.grpbPersonalDetails.TabStop = false;
            this.grpbPersonalDetails.Text = "Personal Details";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "dd.MM.yyyy";
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(138, 128);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 21);
            this.dateTimePicker2.TabIndex = 11;
            // 
            // cmbGender
            // 
            this.cmbGender.FormattingEnabled = true;
            this.cmbGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cmbGender.Location = new System.Drawing.Point(138, 85);
            this.cmbGender.Name = "cmbGender";
            this.cmbGender.Size = new System.Drawing.Size(90, 23);
            this.cmbGender.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 15);
            this.label3.TabIndex = 8;
            this.label3.Text = "Gender       :";
            // 
            // txtLanguages
            // 
            this.txtLanguages.Location = new System.Drawing.Point(138, 171);
            this.txtLanguages.Name = "txtLanguages";
            this.txtLanguages.Size = new System.Drawing.Size(359, 21);
            this.txtLanguages.TabIndex = 1;
            // 
            // lblLanguages
            // 
            this.lblLanguages.AutoSize = true;
            this.lblLanguages.Location = new System.Drawing.Point(10, 174);
            this.lblLanguages.Name = "lblLanguages";
            this.lblLanguages.Size = new System.Drawing.Size(90, 15);
            this.lblLanguages.TabIndex = 0;
            this.lblLanguages.Text = "Languages  :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name  :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(304, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last Name  :";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(400, 44);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(134, 21);
            this.txtLastName.TabIndex = 5;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(138, 49);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(134, 21);
            this.txtFirstName.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "DOB           :";
            // 
            // tabPage2
            // 
            this.tabPage2.BackgroundImage = global::ORS.PL.Properties.Resources.images__2_;
            this.tabPage2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage2.Controls.Add(this.btnPrevious);
            this.tabPage2.Controls.Add(this.btnNext2);
            this.tabPage2.Controls.Add(this.grpbSkillSet);
            this.tabPage2.Controls.Add(this.grpbQualification);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(656, 722);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Educational Details";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnPrevious
            // 
            this.btnPrevious.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrevious.Location = new System.Drawing.Point(39, 670);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(93, 24);
            this.btnPrevious.TabIndex = 5;
            this.btnPrevious.Text = "<< Prev";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnNext2
            // 
            this.btnNext2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext2.Location = new System.Drawing.Point(502, 670);
            this.btnNext2.Name = "btnNext2";
            this.btnNext2.Size = new System.Drawing.Size(94, 24);
            this.btnNext2.TabIndex = 4;
            this.btnNext2.Text = "Next >>";
            this.btnNext2.UseVisualStyleBackColor = true;
            this.btnNext2.Click += new System.EventHandler(this.btnNext2_Click);
            // 
            // grpbSkillSet
            // 
            this.grpbSkillSet.Controls.Add(this.txtSkills);
            this.grpbSkillSet.Controls.Add(this.lblSkills);
            this.grpbSkillSet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbSkillSet.Location = new System.Drawing.Point(40, 447);
            this.grpbSkillSet.Name = "grpbSkillSet";
            this.grpbSkillSet.Size = new System.Drawing.Size(556, 114);
            this.grpbSkillSet.TabIndex = 1;
            this.grpbSkillSet.TabStop = false;
            this.grpbSkillSet.Text = "Skill Set";
            // 
            // txtSkills
            // 
            this.txtSkills.Location = new System.Drawing.Point(164, 43);
            this.txtSkills.Multiline = true;
            this.txtSkills.Name = "txtSkills";
            this.txtSkills.Size = new System.Drawing.Size(323, 50);
            this.txtSkills.TabIndex = 1;
            // 
            // lblSkills
            // 
            this.lblSkills.AutoSize = true;
            this.lblSkills.Location = new System.Drawing.Point(20, 46);
            this.lblSkills.Name = "lblSkills";
            this.lblSkills.Size = new System.Drawing.Size(138, 15);
            this.lblSkills.TabIndex = 0;
            this.lblSkills.Text = "Professional Skills  :";
            // 
            // grpbQualification
            // 
            this.grpbQualification.Controls.Add(this.txtPostGradPY);
            this.grpbQualification.Controls.Add(this.txtGradPY);
            this.grpbQualification.Controls.Add(this.txtDiplomaPY);
            this.grpbQualification.Controls.Add(this.txtHSCPY);
            this.grpbQualification.Controls.Add(this.txtSSCPY);
            this.grpbQualification.Controls.Add(this.txtPostGradPercent);
            this.grpbQualification.Controls.Add(this.txtGradPercent);
            this.grpbQualification.Controls.Add(this.txtDiplomaPercent);
            this.grpbQualification.Controls.Add(this.txtHSCPercent);
            this.grpbQualification.Controls.Add(this.label19);
            this.grpbQualification.Controls.Add(this.label18);
            this.grpbQualification.Controls.Add(this.label17);
            this.grpbQualification.Controls.Add(this.label16);
            this.grpbQualification.Controls.Add(this.label15);
            this.grpbQualification.Controls.Add(this.txtSSCPercent);
            this.grpbQualification.Controls.Add(this.label14);
            this.grpbQualification.Controls.Add(this.label13);
            this.grpbQualification.Controls.Add(this.label12);
            this.grpbQualification.Controls.Add(this.label11);
            this.grpbQualification.Controls.Add(this.label10);
            this.grpbQualification.Controls.Add(this.label9);
            this.grpbQualification.Controls.Add(this.label8);
            this.grpbQualification.Controls.Add(this.label7);
            this.grpbQualification.Controls.Add(this.label6);
            this.grpbQualification.Controls.Add(this.label5);
            this.grpbQualification.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbQualification.Location = new System.Drawing.Point(40, 20);
            this.grpbQualification.Name = "grpbQualification";
            this.grpbQualification.Size = new System.Drawing.Size(556, 403);
            this.grpbQualification.TabIndex = 0;
            this.grpbQualification.TabStop = false;
            this.grpbQualification.Text = "Qualification";
            // 
            // txtPostGradPY
            // 
            this.txtPostGradPY.Location = new System.Drawing.Point(377, 337);
            this.txtPostGradPY.Name = "txtPostGradPY";
            this.txtPostGradPY.Size = new System.Drawing.Size(100, 21);
            this.txtPostGradPY.TabIndex = 28;
            // 
            // txtGradPY
            // 
            this.txtGradPY.Location = new System.Drawing.Point(377, 267);
            this.txtGradPY.Name = "txtGradPY";
            this.txtGradPY.Size = new System.Drawing.Size(100, 21);
            this.txtGradPY.TabIndex = 27;
            // 
            // txtDiplomaPY
            // 
            this.txtDiplomaPY.Location = new System.Drawing.Point(377, 192);
            this.txtDiplomaPY.Name = "txtDiplomaPY";
            this.txtDiplomaPY.Size = new System.Drawing.Size(100, 21);
            this.txtDiplomaPY.TabIndex = 26;
            // 
            // txtHSCPY
            // 
            this.txtHSCPY.Location = new System.Drawing.Point(377, 118);
            this.txtHSCPY.Name = "txtHSCPY";
            this.txtHSCPY.Size = new System.Drawing.Size(100, 21);
            this.txtHSCPY.TabIndex = 25;
            // 
            // txtSSCPY
            // 
            this.txtSSCPY.Location = new System.Drawing.Point(377, 48);
            this.txtSSCPY.Name = "txtSSCPY";
            this.txtSSCPY.Size = new System.Drawing.Size(100, 21);
            this.txtSSCPY.TabIndex = 24;
            // 
            // txtPostGradPercent
            // 
            this.txtPostGradPercent.Location = new System.Drawing.Point(122, 336);
            this.txtPostGradPercent.Name = "txtPostGradPercent";
            this.txtPostGradPercent.Size = new System.Drawing.Size(100, 21);
            this.txtPostGradPercent.TabIndex = 23;
            // 
            // txtGradPercent
            // 
            this.txtGradPercent.Location = new System.Drawing.Point(122, 267);
            this.txtGradPercent.Name = "txtGradPercent";
            this.txtGradPercent.Size = new System.Drawing.Size(100, 21);
            this.txtGradPercent.TabIndex = 21;
            // 
            // txtDiplomaPercent
            // 
            this.txtDiplomaPercent.Location = new System.Drawing.Point(122, 189);
            this.txtDiplomaPercent.Name = "txtDiplomaPercent";
            this.txtDiplomaPercent.Size = new System.Drawing.Size(100, 21);
            this.txtDiplomaPercent.TabIndex = 19;
            // 
            // txtHSCPercent
            // 
            this.txtHSCPercent.Location = new System.Drawing.Point(122, 115);
            this.txtHSCPercent.Name = "txtHSCPercent";
            this.txtHSCPercent.Size = new System.Drawing.Size(100, 21);
            this.txtHSCPercent.TabIndex = 17;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(6, 316);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(114, 18);
            this.label19.TabIndex = 15;
            this.label19.Text = "Post Graduation  :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(6, 240);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(86, 18);
            this.label18.TabIndex = 14;
            this.label18.Text = "Graduation  :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 162);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 18);
            this.label17.TabIndex = 13;
            this.label17.Text = "Diploma :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(6, 96);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(45, 18);
            this.label16.TabIndex = 12;
            this.label16.Text = "HSC  :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(6, 27);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(42, 18);
            this.label15.TabIndex = 11;
            this.label15.Text = "SSC  :";
            // 
            // txtSSCPercent
            // 
            this.txtSSCPercent.Location = new System.Drawing.Point(122, 48);
            this.txtSSCPercent.Name = "txtSSCPercent";
            this.txtSSCPercent.Size = new System.Drawing.Size(100, 21);
            this.txtSSCPercent.TabIndex = 10;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(268, 343);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(103, 15);
            this.label14.TabIndex = 9;
            this.label14.Text = "Passout Year  :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(27, 343);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 15);
            this.label13.TabIndex = 8;
            this.label13.Text = "Percentage  :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(268, 273);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(103, 15);
            this.label12.TabIndex = 7;
            this.label12.Text = "Passout Year  :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(24, 273);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(92, 15);
            this.label11.TabIndex = 6;
            this.label11.Text = "Percentage  :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(268, 195);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(103, 15);
            this.label10.TabIndex = 5;
            this.label10.Text = "Passout Year  :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(24, 188);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 15);
            this.label9.TabIndex = 4;
            this.label9.Text = "Percentage  :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(268, 121);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 15);
            this.label8.TabIndex = 3;
            this.label8.Text = "Passout Year  :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 121);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 15);
            this.label7.TabIndex = 2;
            this.label7.Text = "Percentage  :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(268, 51);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 15);
            this.label6.TabIndex = 1;
            this.label6.Text = "Passout Year  :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 51);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 15);
            this.label5.TabIndex = 0;
            this.label5.Text = "Percentage  :";
            // 
            // tabPage3
            // 
            this.tabPage3.BackgroundImage = global::ORS.PL.Properties.Resources.images__2_;
            this.tabPage3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage3.Controls.Add(this.btnRegisterJ);
            this.tabPage3.Controls.Add(this.btnPrev2);
            this.tabPage3.Controls.Add(this.grpbJobHistory);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(656, 722);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Job History";
            this.tabPage3.UseVisualStyleBackColor = true;
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // btnRegisterJ
            // 
            this.btnRegisterJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegisterJ.Location = new System.Drawing.Point(240, 461);
            this.btnRegisterJ.Name = "btnRegisterJ";
            this.btnRegisterJ.Size = new System.Drawing.Size(137, 37);
            this.btnRegisterJ.TabIndex = 5;
            this.btnRegisterJ.Text = "Register";
            this.btnRegisterJ.UseVisualStyleBackColor = true;
            this.btnRegisterJ.Click += new System.EventHandler(this.btnRegisterJ_Click);
            // 
            // btnPrev2
            // 
            this.btnPrev2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrev2.Location = new System.Drawing.Point(41, 405);
            this.btnPrev2.Name = "btnPrev2";
            this.btnPrev2.Size = new System.Drawing.Size(91, 23);
            this.btnPrev2.TabIndex = 8;
            this.btnPrev2.Text = "<< Prev";
            this.btnPrev2.UseVisualStyleBackColor = true;
            this.btnPrev2.Click += new System.EventHandler(this.btnPrev2_Click);
            // 
            // grpbJobHistory
            // 
            this.grpbJobHistory.Controls.Add(this.txtExperience);
            this.grpbJobHistory.Controls.Add(this.txtProjWorkedOn);
            this.grpbJobHistory.Controls.Add(this.lblProjWorkedOn);
            this.grpbJobHistory.Controls.Add(this.txtTechnologies);
            this.grpbJobHistory.Controls.Add(this.txtCompanyName1);
            this.grpbJobHistory.Controls.Add(this.lblTechnology);
            this.grpbJobHistory.Controls.Add(this.lblCompanyName);
            this.grpbJobHistory.Controls.Add(this.lblExp);
            this.grpbJobHistory.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbJobHistory.Location = new System.Drawing.Point(41, 21);
            this.grpbJobHistory.Name = "grpbJobHistory";
            this.grpbJobHistory.Size = new System.Drawing.Size(556, 363);
            this.grpbJobHistory.TabIndex = 0;
            this.grpbJobHistory.TabStop = false;
            this.grpbJobHistory.Text = "Job History";
            // 
            // txtExperience
            // 
            this.txtExperience.Location = new System.Drawing.Point(220, 40);
            this.txtExperience.Name = "txtExperience";
            this.txtExperience.Size = new System.Drawing.Size(100, 21);
            this.txtExperience.TabIndex = 8;
            // 
            // txtProjWorkedOn
            // 
            this.txtProjWorkedOn.Location = new System.Drawing.Point(220, 254);
            this.txtProjWorkedOn.Multiline = true;
            this.txtProjWorkedOn.Name = "txtProjWorkedOn";
            this.txtProjWorkedOn.Size = new System.Drawing.Size(213, 66);
            this.txtProjWorkedOn.TabIndex = 7;
            // 
            // lblProjWorkedOn
            // 
            this.lblProjWorkedOn.AutoSize = true;
            this.lblProjWorkedOn.Location = new System.Drawing.Point(31, 257);
            this.lblProjWorkedOn.Name = "lblProjWorkedOn";
            this.lblProjWorkedOn.Size = new System.Drawing.Size(134, 15);
            this.lblProjWorkedOn.TabIndex = 6;
            this.lblProjWorkedOn.Text = "Project Worked On :";
            // 
            // txtTechnologies
            // 
            this.txtTechnologies.Location = new System.Drawing.Point(220, 165);
            this.txtTechnologies.Multiline = true;
            this.txtTechnologies.Name = "txtTechnologies";
            this.txtTechnologies.Size = new System.Drawing.Size(213, 73);
            this.txtTechnologies.TabIndex = 5;
            // 
            // txtCompanyName1
            // 
            this.txtCompanyName1.Location = new System.Drawing.Point(220, 82);
            this.txtCompanyName1.Multiline = true;
            this.txtCompanyName1.Name = "txtCompanyName1";
            this.txtCompanyName1.Size = new System.Drawing.Size(213, 62);
            this.txtCompanyName1.TabIndex = 4;
            // 
            // lblTechnology
            // 
            this.lblTechnology.AutoSize = true;
            this.lblTechnology.Location = new System.Drawing.Point(31, 168);
            this.lblTechnology.Name = "lblTechnology";
            this.lblTechnology.Size = new System.Drawing.Size(179, 15);
            this.lblTechnology.TabIndex = 2;
            this.lblTechnology.Text = "Technologies Worked On  :";
            // 
            // lblCompanyName
            // 
            this.lblCompanyName.AutoSize = true;
            this.lblCompanyName.Location = new System.Drawing.Point(31, 85);
            this.lblCompanyName.Name = "lblCompanyName";
            this.lblCompanyName.Size = new System.Drawing.Size(181, 15);
            this.lblCompanyName.TabIndex = 1;
            this.lblCompanyName.Text = "Company Name / Names   :";
            // 
            // lblExp
            // 
            this.lblExp.AutoSize = true;
            this.lblExp.Location = new System.Drawing.Point(31, 43);
            this.lblExp.Name = "lblExp";
            this.lblExp.Size = new System.Drawing.Size(183, 15);
            this.lblExp.TabIndex = 0;
            this.lblExp.Text = "Experience (in years)         :";
            // 
            // JobSeekerRegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(729, 750);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.Name = "JobSeekerRegistrationForm";
            this.Text = "Job Seeker Registration";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.grpbLogin.ResumeLayout(false);
            this.grpbLogin.PerformLayout();
            this.grpbContactDetails.ResumeLayout(false);
            this.grpbContactDetails.PerformLayout();
            this.grpbPersonalDetails.ResumeLayout(false);
            this.grpbPersonalDetails.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.grpbSkillSet.ResumeLayout(false);
            this.grpbSkillSet.PerformLayout();
            this.grpbQualification.ResumeLayout(false);
            this.grpbQualification.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.grpbJobHistory.ResumeLayout(false);
            this.grpbJobHistory.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtPostGradPercent;
        private System.Windows.Forms.TextBox txtGradPercent;
        private System.Windows.Forms.TextBox txtDiplomaPercent;
        private System.Windows.Forms.TextBox txtHSCPercent;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtSSCPercent;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnNext2;
        private System.Windows.Forms.GroupBox grpbSkillSet;
        private System.Windows.Forms.TextBox txtSkills;
        private System.Windows.Forms.Label lblSkills;
        private System.Windows.Forms.GroupBox grpbQualification;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtProjWorkedOn;
        private System.Windows.Forms.Label lblProjWorkedOn;
        private System.Windows.Forms.TextBox txtTechnologies;
        private System.Windows.Forms.TextBox txtCompanyName1;
        private System.Windows.Forms.Label lblTechnology;
        private System.Windows.Forms.Label lblCompanyName;
        private System.Windows.Forms.Label lblExp;
        private System.Windows.Forms.Button btnRegisterJ;
        private System.Windows.Forms.Button btnPrev2;
        private System.Windows.Forms.GroupBox grpbJobHistory;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAddress1;
        private System.Windows.Forms.GroupBox grpbLogin;
        private System.Windows.Forms.Label lblConfirmPassword;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtConfirmPassword;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtPostalCode;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtContactNo2;
        private System.Windows.Forms.TextBox txtContactNo1;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.ComboBox cmbCity;
        private System.Windows.Forms.Button btnNext1;
        private System.Windows.Forms.GroupBox grpbContactDetails;
        private System.Windows.Forms.ComboBox cmbState;
        private System.Windows.Forms.ComboBox cmbCountry;
        private System.Windows.Forms.Label labelCity;
        private System.Windows.Forms.Label labelState;
        private System.Windows.Forms.Label lblContactNo2;
        private System.Windows.Forms.Label lblContactNo1;
        private System.Windows.Forms.Label labelCountry;
        private System.Windows.Forms.Label lblAddress2;
        private System.Windows.Forms.Label lblAddress1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox grpbPersonalDetails;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtLanguages;
        private System.Windows.Forms.Label lblLanguages;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.ComboBox cmbGender;
        private System.Windows.Forms.TextBox txtPostGradPY;
        private System.Windows.Forms.TextBox txtGradPY;
        private System.Windows.Forms.TextBox txtDiplomaPY;
        private System.Windows.Forms.TextBox txtHSCPY;
        private System.Windows.Forms.TextBox txtSSCPY;
        private System.Windows.Forms.TextBox txtExperience;
        private System.Windows.Forms.TextBox txtusertype;
        private System.Windows.Forms.Label label22;
    }
}