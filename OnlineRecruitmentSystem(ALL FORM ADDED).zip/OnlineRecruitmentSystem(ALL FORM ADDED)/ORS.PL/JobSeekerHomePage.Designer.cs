﻿namespace ORS.PL
{
    partial class JobSeekerHomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonLogout = new System.Windows.Forms.Button();
            this.lblUserID = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.lblaboutus = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnEditProfile = new System.Windows.Forms.Button();
            this.grpbJobHistory = new System.Windows.Forms.GroupBox();
            this.txtPWO = new System.Windows.Forms.TextBox();
            this.txtTechWO = new System.Windows.Forms.TextBox();
            this.txtCompName = new System.Windows.Forms.TextBox();
            this.txtExp = new System.Windows.Forms.TextBox();
            this.lblProjWorkedOn = new System.Windows.Forms.Label();
            this.lblTechnology = new System.Windows.Forms.Label();
            this.lblCompanyName = new System.Windows.Forms.Label();
            this.lblExp = new System.Windows.Forms.Label();
            this.grpbSkillSet = new System.Windows.Forms.GroupBox();
            this.txtPS = new System.Windows.Forms.TextBox();
            this.lblSkills = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.grpbQualification = new System.Windows.Forms.GroupBox();
            this.txtGPY = new System.Windows.Forms.TextBox();
            this.txtPGP = new System.Windows.Forms.TextBox();
            this.txtPGPY = new System.Windows.Forms.TextBox();
            this.txtSSP = new System.Windows.Forms.TextBox();
            this.txtSSCPY = new System.Windows.Forms.TextBox();
            this.txtHSCP = new System.Windows.Forms.TextBox();
            this.txtHSCPY = new System.Windows.Forms.TextBox();
            this.txtDPY = new System.Windows.Forms.TextBox();
            this.txtDIPP = new System.Windows.Forms.TextBox();
            this.txtGP = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.grpbContactDetails = new System.Windows.Forms.GroupBox();
            this.txtContact2 = new System.Windows.Forms.TextBox();
            this.txtContact1 = new System.Windows.Forms.TextBox();
            this.txtPostalCode = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtState = new System.Windows.Forms.TextBox();
            this.txtCountry = new System.Windows.Forms.TextBox();
            this.txtAdd2 = new System.Windows.Forms.TextBox();
            this.txtAdd1 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblState = new System.Windows.Forms.Label();
            this.lblContactNo2 = new System.Windows.Forms.Label();
            this.lblContactNo1 = new System.Windows.Forms.Label();
            this.lblCountry = new System.Windows.Forms.Label();
            this.lblAddress2 = new System.Windows.Forms.Label();
            this.lblAddress1 = new System.Windows.Forms.Label();
            this.grpbPersonalDetails = new System.Windows.Forms.GroupBox();
            this.txtLang = new System.Windows.Forms.TextBox();
            this.txtDOB = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtGender = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblLanguages = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dgvShowVacancies = new System.Windows.Forms.DataGridView();
            this.btnsearch = new System.Windows.Forms.Button();
            this.txtepsal = new System.Windows.Forms.TextBox();
            this.txtreqexp = new System.Windows.Forms.TextBox();
            this.txtloc = new System.Windows.Forms.TextBox();
            this.txtJobSeekerPosition = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.grpbJobHistory.SuspendLayout();
            this.grpbSkillSet.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grpbQualification.SuspendLayout();
            this.grpbContactDetails.SuspendLayout();
            this.grpbPersonalDetails.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvShowVacancies)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::ORS.PL.Properties.Resources.pilot_web_banner_JOB_OPS;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.buttonLogout);
            this.panel1.Controls.Add(this.lblUserID);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.btnLogout);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Location = new System.Drawing.Point(2, 8);
            this.panel1.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(982, 113);
            this.panel1.TabIndex = 6;
            // 
            // buttonLogout
            // 
            this.buttonLogout.BackColor = System.Drawing.Color.LightGray;
            this.buttonLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLogout.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonLogout.Location = new System.Drawing.Point(875, 4);
            this.buttonLogout.Name = "buttonLogout";
            this.buttonLogout.Size = new System.Drawing.Size(75, 25);
            this.buttonLogout.TabIndex = 22;
            this.buttonLogout.Text = "Logout";
            this.buttonLogout.UseVisualStyleBackColor = false;
            this.buttonLogout.Click += new System.EventHandler(this.btnLogout_click);
            // 
            // lblUserID
            // 
            this.lblUserID.AutoSize = true;
            this.lblUserID.BackColor = System.Drawing.Color.Snow;
            this.lblUserID.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserID.Location = new System.Drawing.Point(847, 95);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(73, 18);
            this.lblUserID.TabIndex = 21;
            this.lblUserID.Text = "  lblUserId";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Snow;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(771, 95);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(70, 18);
            this.label23.TabIndex = 20;
            this.label23.Text = "User ID  :";
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Lavender;
            this.btnLogout.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(992, 12);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 27);
            this.btnLogout.TabIndex = 19;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(988, 131);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(61, 16);
            this.label20.TabIndex = 18;
            this.label20.Text = "label20";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(872, 131);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(110, 16);
            this.label19.TabIndex = 0;
            this.label19.Text = "JobSeeker ID  :";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(2, 124);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(982, 742);
            this.tabControl1.TabIndex = 8;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.tabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage1.Controls.Add(this.label53);
            this.tabPage1.Controls.Add(this.label52);
            this.tabPage1.Controls.Add(this.label51);
            this.tabPage1.Controls.Add(this.label50);
            this.tabPage1.Controls.Add(this.label49);
            this.tabPage1.Controls.Add(this.label48);
            this.tabPage1.Controls.Add(this.label47);
            this.tabPage1.Controls.Add(this.label46);
            this.tabPage1.Controls.Add(this.label45);
            this.tabPage1.Controls.Add(this.label44);
            this.tabPage1.Controls.Add(this.label43);
            this.tabPage1.Controls.Add(this.label42);
            this.tabPage1.Controls.Add(this.label41);
            this.tabPage1.Controls.Add(this.label40);
            this.tabPage1.Controls.Add(this.label39);
            this.tabPage1.Controls.Add(this.lblaboutus);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Location = new System.Drawing.Point(4, 27);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(974, 711);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Home";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click_1);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(179, 367);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(71, 16);
            this.label53.TabIndex = 21;
            this.label53.Text = ":  English";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(40, 367);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(90, 16);
            this.label52.TabIndex = 20;
            this.label52.Text = "Available In";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(179, 338);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(151, 16);
            this.label51.TabIndex = 19;
            this.label51.Text = ":  Job Search Engine";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(179, 394);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(127, 16);
            this.label50.TabIndex = 18;
            this.label50.Text = ":  Project Group 3";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(179, 422);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(150, 16);
            this.label49.TabIndex = 17;
            this.label49.Text = ":  Online Recruitment";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(179, 448);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(84, 16);
            this.label48.TabIndex = 16;
            this.label48.Text = ":  Required";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(179, 480);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(63, 16);
            this.label47.TabIndex = 15;
            this.label47.Text = ":  Active";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(179, 308);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(63, 16);
            this.label46.TabIndex = 14;
            this.label46.Text = ":  Public";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(40, 308);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(128, 16);
            this.label45.TabIndex = 13;
            this.label45.Text = "Type of Business";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(40, 338);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(92, 16);
            this.label44.TabIndex = 12;
            this.label44.Text = "Type of Site";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(40, 394);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(73, 16);
            this.label43.TabIndex = 11;
            this.label43.Text = "Founders";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(40, 422);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(69, 16);
            this.label42.TabIndex = 10;
            this.label42.Text = "Services";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(40, 448);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(92, 16);
            this.label41.TabIndex = 9;
            this.label41.Text = "Registration";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(40, 480);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(104, 16);
            this.label40.TabIndex = 8;
            this.label40.Text = "Current Status";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(43, 281);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(596, 18);
            this.label39.TabIndex = 7;
            this.label39.Text = "EasyJOB.com is an Indian Job portal operating in India founded in March 2017";
            // 
            // lblaboutus
            // 
            this.lblaboutus.AutoSize = true;
            this.lblaboutus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblaboutus.Location = new System.Drawing.Point(18, 242);
            this.lblaboutus.Name = "lblaboutus";
            this.lblaboutus.Size = new System.Drawing.Size(115, 25);
            this.lblaboutus.TabIndex = 5;
            this.lblaboutus.Text = "About Us ";
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = global::ORS.PL.Properties.Resources.Capture4;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(975, 208);
            this.panel2.TabIndex = 4;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.LightCyan;
            this.tabPage2.Controls.Add(this.btnEditProfile);
            this.tabPage2.Controls.Add(this.grpbJobHistory);
            this.tabPage2.Controls.Add(this.grpbSkillSet);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.grpbQualification);
            this.tabPage2.Controls.Add(this.grpbContactDetails);
            this.tabPage2.Controls.Add(this.grpbPersonalDetails);
            this.tabPage2.Location = new System.Drawing.Point(4, 27);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(974, 711);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "My Profile";
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // btnEditProfile
            // 
            this.btnEditProfile.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditProfile.Location = new System.Drawing.Point(695, 522);
            this.btnEditProfile.Name = "btnEditProfile";
            this.btnEditProfile.Size = new System.Drawing.Size(122, 38);
            this.btnEditProfile.TabIndex = 15;
            this.btnEditProfile.Text = "Edit Profile";
            this.btnEditProfile.UseVisualStyleBackColor = true;
            this.btnEditProfile.Click += new System.EventHandler(this.btnEditProfile_Click_1);
            // 
            // grpbJobHistory
            // 
            this.grpbJobHistory.Controls.Add(this.txtPWO);
            this.grpbJobHistory.Controls.Add(this.txtTechWO);
            this.grpbJobHistory.Controls.Add(this.txtCompName);
            this.grpbJobHistory.Controls.Add(this.txtExp);
            this.grpbJobHistory.Controls.Add(this.lblProjWorkedOn);
            this.grpbJobHistory.Controls.Add(this.lblTechnology);
            this.grpbJobHistory.Controls.Add(this.lblCompanyName);
            this.grpbJobHistory.Controls.Add(this.lblExp);
            this.grpbJobHistory.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbJobHistory.Location = new System.Drawing.Point(590, 88);
            this.grpbJobHistory.Name = "grpbJobHistory";
            this.grpbJobHistory.Size = new System.Drawing.Size(451, 296);
            this.grpbJobHistory.TabIndex = 14;
            this.grpbJobHistory.TabStop = false;
            this.grpbJobHistory.Text = "Job History";
            // 
            // txtPWO
            // 
            this.txtPWO.Location = new System.Drawing.Point(171, 228);
            this.txtPWO.Multiline = true;
            this.txtPWO.Name = "txtPWO";
            this.txtPWO.Size = new System.Drawing.Size(100, 21);
            this.txtPWO.TabIndex = 18;
            // 
            // txtTechWO
            // 
            this.txtTechWO.Location = new System.Drawing.Point(226, 146);
            this.txtTechWO.Multiline = true;
            this.txtTechWO.Name = "txtTechWO";
            this.txtTechWO.Size = new System.Drawing.Size(100, 21);
            this.txtTechWO.TabIndex = 17;
            // 
            // txtCompName
            // 
            this.txtCompName.Location = new System.Drawing.Point(226, 82);
            this.txtCompName.Name = "txtCompName";
            this.txtCompName.Size = new System.Drawing.Size(100, 21);
            this.txtCompName.TabIndex = 16;
            // 
            // txtExp
            // 
            this.txtExp.Location = new System.Drawing.Point(226, 43);
            this.txtExp.Name = "txtExp";
            this.txtExp.Size = new System.Drawing.Size(100, 21);
            this.txtExp.TabIndex = 15;
            // 
            // lblProjWorkedOn
            // 
            this.lblProjWorkedOn.AutoSize = true;
            this.lblProjWorkedOn.Location = new System.Drawing.Point(31, 228);
            this.lblProjWorkedOn.Name = "lblProjWorkedOn";
            this.lblProjWorkedOn.Size = new System.Drawing.Size(134, 15);
            this.lblProjWorkedOn.TabIndex = 6;
            this.lblProjWorkedOn.Text = "Project Worked On :";
            // 
            // lblTechnology
            // 
            this.lblTechnology.AutoSize = true;
            this.lblTechnology.Location = new System.Drawing.Point(31, 152);
            this.lblTechnology.Name = "lblTechnology";
            this.lblTechnology.Size = new System.Drawing.Size(179, 15);
            this.lblTechnology.TabIndex = 2;
            this.lblTechnology.Text = "Technologies Worked On  :";
            // 
            // lblCompanyName
            // 
            this.lblCompanyName.AutoSize = true;
            this.lblCompanyName.Location = new System.Drawing.Point(31, 85);
            this.lblCompanyName.Name = "lblCompanyName";
            this.lblCompanyName.Size = new System.Drawing.Size(181, 15);
            this.lblCompanyName.TabIndex = 1;
            this.lblCompanyName.Text = "Company Name / Names   :";
            // 
            // lblExp
            // 
            this.lblExp.AutoSize = true;
            this.lblExp.Location = new System.Drawing.Point(31, 43);
            this.lblExp.Name = "lblExp";
            this.lblExp.Size = new System.Drawing.Size(183, 15);
            this.lblExp.TabIndex = 0;
            this.lblExp.Text = "Experience (in years)         :";
            // 
            // grpbSkillSet
            // 
            this.grpbSkillSet.Controls.Add(this.txtPS);
            this.grpbSkillSet.Controls.Add(this.lblSkills);
            this.grpbSkillSet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbSkillSet.Location = new System.Drawing.Point(590, 407);
            this.grpbSkillSet.Name = "grpbSkillSet";
            this.grpbSkillSet.Size = new System.Drawing.Size(451, 75);
            this.grpbSkillSet.TabIndex = 13;
            this.grpbSkillSet.TabStop = false;
            this.grpbSkillSet.Text = "Skill Set";
            // 
            // txtPS
            // 
            this.txtPS.Location = new System.Drawing.Point(175, 27);
            this.txtPS.Multiline = true;
            this.txtPS.Name = "txtPS";
            this.txtPS.Size = new System.Drawing.Size(100, 21);
            this.txtPS.TabIndex = 15;
            // 
            // lblSkills
            // 
            this.lblSkills.AutoSize = true;
            this.lblSkills.Location = new System.Drawing.Point(13, 30);
            this.lblSkills.Name = "lblSkills";
            this.lblSkills.Size = new System.Drawing.Size(138, 15);
            this.lblSkills.TabIndex = 0;
            this.lblSkills.Text = "Professional Skills  :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtEmail);
            this.groupBox1.Controls.Add(this.lblEmail);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(34, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(531, 58);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Login Details";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(165, 26);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(100, 21);
            this.txtEmail.TabIndex = 10;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(12, 26);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(134, 15);
            this.lblEmail.TabIndex = 9;
            this.lblEmail.Text = "Email ID                 :";
            // 
            // grpbQualification
            // 
            this.grpbQualification.Controls.Add(this.txtGPY);
            this.grpbQualification.Controls.Add(this.txtPGP);
            this.grpbQualification.Controls.Add(this.txtPGPY);
            this.grpbQualification.Controls.Add(this.txtSSP);
            this.grpbQualification.Controls.Add(this.txtSSCPY);
            this.grpbQualification.Controls.Add(this.txtHSCP);
            this.grpbQualification.Controls.Add(this.txtHSCPY);
            this.grpbQualification.Controls.Add(this.txtDPY);
            this.grpbQualification.Controls.Add(this.txtDIPP);
            this.grpbQualification.Controls.Add(this.txtGP);
            this.grpbQualification.Controls.Add(this.label5);
            this.grpbQualification.Controls.Add(this.label18);
            this.grpbQualification.Controls.Add(this.label17);
            this.grpbQualification.Controls.Add(this.label16);
            this.grpbQualification.Controls.Add(this.label15);
            this.grpbQualification.Controls.Add(this.label14);
            this.grpbQualification.Controls.Add(this.label13);
            this.grpbQualification.Controls.Add(this.label12);
            this.grpbQualification.Controls.Add(this.label11);
            this.grpbQualification.Controls.Add(this.label10);
            this.grpbQualification.Controls.Add(this.label9);
            this.grpbQualification.Controls.Add(this.label8);
            this.grpbQualification.Controls.Add(this.label7);
            this.grpbQualification.Controls.Add(this.label6);
            this.grpbQualification.Controls.Add(this.label22);
            this.grpbQualification.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbQualification.Location = new System.Drawing.Point(32, 451);
            this.grpbQualification.Name = "grpbQualification";
            this.grpbQualification.Size = new System.Drawing.Size(531, 258);
            this.grpbQualification.TabIndex = 12;
            this.grpbQualification.TabStop = false;
            this.grpbQualification.Text = "Qualification";
            // 
            // txtGPY
            // 
            this.txtGPY.Location = new System.Drawing.Point(371, 185);
            this.txtGPY.Name = "txtGPY";
            this.txtGPY.Size = new System.Drawing.Size(100, 21);
            this.txtGPY.TabIndex = 25;
            // 
            // txtPGP
            // 
            this.txtPGP.Location = new System.Drawing.Point(120, 225);
            this.txtPGP.Name = "txtPGP";
            this.txtPGP.Size = new System.Drawing.Size(100, 21);
            this.txtPGP.TabIndex = 24;
            // 
            // txtPGPY
            // 
            this.txtPGPY.Location = new System.Drawing.Point(371, 225);
            this.txtPGPY.Name = "txtPGPY";
            this.txtPGPY.Size = new System.Drawing.Size(100, 21);
            this.txtPGPY.TabIndex = 23;
            // 
            // txtSSP
            // 
            this.txtSSP.Location = new System.Drawing.Point(122, 51);
            this.txtSSP.Name = "txtSSP";
            this.txtSSP.Size = new System.Drawing.Size(100, 21);
            this.txtSSP.TabIndex = 22;
            // 
            // txtSSCPY
            // 
            this.txtSSCPY.Location = new System.Drawing.Point(371, 51);
            this.txtSSCPY.Name = "txtSSCPY";
            this.txtSSCPY.Size = new System.Drawing.Size(100, 21);
            this.txtSSCPY.TabIndex = 21;
            // 
            // txtHSCP
            // 
            this.txtHSCP.Location = new System.Drawing.Point(120, 91);
            this.txtHSCP.Name = "txtHSCP";
            this.txtHSCP.Size = new System.Drawing.Size(100, 21);
            this.txtHSCP.TabIndex = 20;
            // 
            // txtHSCPY
            // 
            this.txtHSCPY.Location = new System.Drawing.Point(371, 94);
            this.txtHSCPY.Name = "txtHSCPY";
            this.txtHSCPY.Size = new System.Drawing.Size(100, 21);
            this.txtHSCPY.TabIndex = 19;
            // 
            // txtDPY
            // 
            this.txtDPY.Location = new System.Drawing.Point(371, 143);
            this.txtDPY.Name = "txtDPY";
            this.txtDPY.Size = new System.Drawing.Size(100, 21);
            this.txtDPY.TabIndex = 18;
            // 
            // txtDIPP
            // 
            this.txtDIPP.Location = new System.Drawing.Point(120, 140);
            this.txtDIPP.Name = "txtDIPP";
            this.txtDIPP.Size = new System.Drawing.Size(100, 21);
            this.txtDIPP.TabIndex = 17;
            // 
            // txtGP
            // 
            this.txtGP.Location = new System.Drawing.Point(122, 185);
            this.txtGP.Name = "txtGP";
            this.txtGP.Size = new System.Drawing.Size(100, 21);
            this.txtGP.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 213);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 18);
            this.label5.TabIndex = 15;
            this.label5.Text = "Post Graduation  :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(6, 170);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(86, 18);
            this.label18.TabIndex = 14;
            this.label18.Text = "Graduation  :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 125);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 18);
            this.label17.TabIndex = 13;
            this.label17.Text = "Diploma :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(6, 76);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(45, 18);
            this.label16.TabIndex = 12;
            this.label16.Text = "HSC  :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(6, 27);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(42, 18);
            this.label15.TabIndex = 11;
            this.label15.Text = "SSC  :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(268, 231);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(103, 15);
            this.label14.TabIndex = 9;
            this.label14.Text = "Passout Year  :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(28, 231);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 15);
            this.label13.TabIndex = 8;
            this.label13.Text = "Percentage  :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(266, 188);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(103, 15);
            this.label12.TabIndex = 7;
            this.label12.Text = "Passout Year  :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(28, 188);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(92, 15);
            this.label11.TabIndex = 6;
            this.label11.Text = "Percentage  :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(268, 143);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(103, 15);
            this.label10.TabIndex = 5;
            this.label10.Text = "Passout Year  :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(28, 143);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 15);
            this.label9.TabIndex = 4;
            this.label9.Text = "Percentage  :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(268, 94);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 15);
            this.label8.TabIndex = 3;
            this.label8.Text = "Passout Year  :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(28, 94);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 15);
            this.label7.TabIndex = 2;
            this.label7.Text = "Percentage  :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(268, 51);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 15);
            this.label6.TabIndex = 1;
            this.label6.Text = "Passout Year  :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(24, 51);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(92, 15);
            this.label22.TabIndex = 0;
            this.label22.Text = "Percentage  :";
            // 
            // grpbContactDetails
            // 
            this.grpbContactDetails.Controls.Add(this.txtContact2);
            this.grpbContactDetails.Controls.Add(this.txtContact1);
            this.grpbContactDetails.Controls.Add(this.txtPostalCode);
            this.grpbContactDetails.Controls.Add(this.txtCity);
            this.grpbContactDetails.Controls.Add(this.txtState);
            this.grpbContactDetails.Controls.Add(this.txtCountry);
            this.grpbContactDetails.Controls.Add(this.txtAdd2);
            this.grpbContactDetails.Controls.Add(this.txtAdd1);
            this.grpbContactDetails.Controls.Add(this.label21);
            this.grpbContactDetails.Controls.Add(this.lblCity);
            this.grpbContactDetails.Controls.Add(this.lblState);
            this.grpbContactDetails.Controls.Add(this.lblContactNo2);
            this.grpbContactDetails.Controls.Add(this.lblContactNo1);
            this.grpbContactDetails.Controls.Add(this.lblCountry);
            this.grpbContactDetails.Controls.Add(this.lblAddress2);
            this.grpbContactDetails.Controls.Add(this.lblAddress1);
            this.grpbContactDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbContactDetails.Location = new System.Drawing.Point(34, 220);
            this.grpbContactDetails.Name = "grpbContactDetails";
            this.grpbContactDetails.Size = new System.Drawing.Size(529, 225);
            this.grpbContactDetails.TabIndex = 10;
            this.grpbContactDetails.TabStop = false;
            this.grpbContactDetails.Text = "Contact Details";
            // 
            // txtContact2
            // 
            this.txtContact2.Location = new System.Drawing.Point(369, 187);
            this.txtContact2.Name = "txtContact2";
            this.txtContact2.Size = new System.Drawing.Size(100, 21);
            this.txtContact2.TabIndex = 31;
            // 
            // txtContact1
            // 
            this.txtContact1.Location = new System.Drawing.Point(118, 184);
            this.txtContact1.Name = "txtContact1";
            this.txtContact1.Size = new System.Drawing.Size(100, 21);
            this.txtContact1.TabIndex = 30;
            // 
            // txtPostalCode
            // 
            this.txtPostalCode.Location = new System.Drawing.Point(112, 146);
            this.txtPostalCode.Name = "txtPostalCode";
            this.txtPostalCode.Size = new System.Drawing.Size(100, 21);
            this.txtPostalCode.TabIndex = 29;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(423, 116);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(100, 21);
            this.txtCity.TabIndex = 28;
            // 
            // txtState
            // 
            this.txtState.Location = new System.Drawing.Point(265, 116);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(100, 21);
            this.txtState.TabIndex = 27;
            // 
            // txtCountry
            // 
            this.txtCountry.Location = new System.Drawing.Point(80, 116);
            this.txtCountry.Name = "txtCountry";
            this.txtCountry.Size = new System.Drawing.Size(100, 21);
            this.txtCountry.TabIndex = 26;
            // 
            // txtAdd2
            // 
            this.txtAdd2.Location = new System.Drawing.Point(132, 74);
            this.txtAdd2.Name = "txtAdd2";
            this.txtAdd2.Size = new System.Drawing.Size(100, 21);
            this.txtAdd2.TabIndex = 25;
            // 
            // txtAdd1
            // 
            this.txtAdd1.Location = new System.Drawing.Point(133, 38);
            this.txtAdd1.Name = "txtAdd1";
            this.txtAdd1.Size = new System.Drawing.Size(100, 21);
            this.txtAdd1.TabIndex = 24;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(10, 149);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(96, 15);
            this.label21.TabIndex = 14;
            this.label21.Text = "Postal Code  :";
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(381, 116);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(38, 15);
            this.lblCity.TabIndex = 6;
            this.lblCity.Text = "City :";
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Location = new System.Drawing.Point(201, 116);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(48, 15);
            this.lblState.TabIndex = 5;
            this.lblState.Text = "State :";
            // 
            // lblContactNo2
            // 
            this.lblContactNo2.AutoSize = true;
            this.lblContactNo2.Location = new System.Drawing.Point(262, 187);
            this.lblContactNo2.Name = "lblContactNo2";
            this.lblContactNo2.Size = new System.Drawing.Size(101, 15);
            this.lblContactNo2.TabIndex = 4;
            this.lblContactNo2.Text = "Contact No. 2 :";
            // 
            // lblContactNo1
            // 
            this.lblContactNo1.AutoSize = true;
            this.lblContactNo1.Location = new System.Drawing.Point(11, 187);
            this.lblContactNo1.Name = "lblContactNo1";
            this.lblContactNo1.Size = new System.Drawing.Size(101, 15);
            this.lblContactNo1.TabIndex = 3;
            this.lblContactNo1.Text = "Contact No 1  :";
            // 
            // lblCountry
            // 
            this.lblCountry.AutoSize = true;
            this.lblCountry.Location = new System.Drawing.Point(11, 116);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.Size = new System.Drawing.Size(63, 15);
            this.lblCountry.TabIndex = 2;
            this.lblCountry.Text = "Country :";
            // 
            // lblAddress2
            // 
            this.lblAddress2.AutoSize = true;
            this.lblAddress2.Location = new System.Drawing.Point(11, 77);
            this.lblAddress2.Name = "lblAddress2";
            this.lblAddress2.Size = new System.Drawing.Size(114, 15);
            this.lblAddress2.TabIndex = 1;
            this.lblAddress2.Text = "Address Line 2  :";
            // 
            // lblAddress1
            // 
            this.lblAddress1.AutoSize = true;
            this.lblAddress1.Location = new System.Drawing.Point(10, 38);
            this.lblAddress1.Name = "lblAddress1";
            this.lblAddress1.Size = new System.Drawing.Size(114, 15);
            this.lblAddress1.TabIndex = 0;
            this.lblAddress1.Text = "Address Line 1  :";
            // 
            // grpbPersonalDetails
            // 
            this.grpbPersonalDetails.Controls.Add(this.txtLang);
            this.grpbPersonalDetails.Controls.Add(this.txtDOB);
            this.grpbPersonalDetails.Controls.Add(this.txtLastName);
            this.grpbPersonalDetails.Controls.Add(this.txtGender);
            this.grpbPersonalDetails.Controls.Add(this.txtFirstName);
            this.grpbPersonalDetails.Controls.Add(this.label3);
            this.grpbPersonalDetails.Controls.Add(this.lblLanguages);
            this.grpbPersonalDetails.Controls.Add(this.label1);
            this.grpbPersonalDetails.Controls.Add(this.label2);
            this.grpbPersonalDetails.Controls.Add(this.label4);
            this.grpbPersonalDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbPersonalDetails.Location = new System.Drawing.Point(36, 88);
            this.grpbPersonalDetails.Name = "grpbPersonalDetails";
            this.grpbPersonalDetails.Size = new System.Drawing.Size(529, 126);
            this.grpbPersonalDetails.TabIndex = 9;
            this.grpbPersonalDetails.TabStop = false;
            this.grpbPersonalDetails.Text = "Personal Details";
            // 
            // txtLang
            // 
            this.txtLang.Location = new System.Drawing.Point(106, 95);
            this.txtLang.Name = "txtLang";
            this.txtLang.Size = new System.Drawing.Size(100, 21);
            this.txtLang.TabIndex = 18;
            // 
            // txtDOB
            // 
            this.txtDOB.Location = new System.Drawing.Point(389, 62);
            this.txtDOB.Name = "txtDOB";
            this.txtDOB.Size = new System.Drawing.Size(100, 21);
            this.txtDOB.TabIndex = 17;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(389, 26);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(100, 21);
            this.txtLastName.TabIndex = 16;
            // 
            // txtGender
            // 
            this.txtGender.Location = new System.Drawing.Point(106, 56);
            this.txtGender.Name = "txtGender";
            this.txtGender.Size = new System.Drawing.Size(100, 21);
            this.txtGender.TabIndex = 15;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(106, 23);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(100, 21);
            this.txtFirstName.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 15);
            this.label3.TabIndex = 8;
            this.label3.Text = "Gender       :";
            // 
            // lblLanguages
            // 
            this.lblLanguages.AutoSize = true;
            this.lblLanguages.Location = new System.Drawing.Point(11, 98);
            this.lblLanguages.Name = "lblLanguages";
            this.lblLanguages.Size = new System.Drawing.Size(90, 15);
            this.lblLanguages.TabIndex = 0;
            this.lblLanguages.Text = "Languages  :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name  :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(295, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last Name  :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(299, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "DOB           :";
            // 
            // tabPage3
            // 
            this.tabPage3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage3.Controls.Add(this.dgvShowVacancies);
            this.tabPage3.Controls.Add(this.btnsearch);
            this.tabPage3.Controls.Add(this.txtepsal);
            this.tabPage3.Controls.Add(this.txtreqexp);
            this.tabPage3.Controls.Add(this.txtloc);
            this.tabPage3.Controls.Add(this.txtJobSeekerPosition);
            this.tabPage3.Controls.Add(this.pictureBox2);
            this.tabPage3.Controls.Add(this.pictureBox1);
            this.tabPage3.Controls.Add(this.label60);
            this.tabPage3.Controls.Add(this.label58);
            this.tabPage3.Controls.Add(this.label57);
            this.tabPage3.Controls.Add(this.label56);
            this.tabPage3.Controls.Add(this.label54);
            this.tabPage3.Location = new System.Drawing.Point(4, 27);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(974, 711);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Search Jobs";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dgvShowVacancies
            // 
            this.dgvShowVacancies.BackgroundColor = System.Drawing.Color.IndianRed;
            this.dgvShowVacancies.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvShowVacancies.Location = new System.Drawing.Point(255, 238);
            this.dgvShowVacancies.Name = "dgvShowVacancies";
            this.dgvShowVacancies.Size = new System.Drawing.Size(699, 299);
            this.dgvShowVacancies.TabIndex = 21;
            // 
            // btnsearch
            // 
            this.btnsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.Location = new System.Drawing.Point(547, 175);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(108, 37);
            this.btnsearch.TabIndex = 20;
            this.btnsearch.Text = "Search";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // txtepsal
            // 
            this.txtepsal.Location = new System.Drawing.Point(452, 134);
            this.txtepsal.Name = "txtepsal";
            this.txtepsal.Size = new System.Drawing.Size(126, 24);
            this.txtepsal.TabIndex = 19;
            // 
            // txtreqexp
            // 
            this.txtreqexp.Location = new System.Drawing.Point(452, 89);
            this.txtreqexp.Name = "txtreqexp";
            this.txtreqexp.Size = new System.Drawing.Size(126, 24);
            this.txtreqexp.TabIndex = 18;
            // 
            // txtloc
            // 
            this.txtloc.Location = new System.Drawing.Point(816, 89);
            this.txtloc.Name = "txtloc";
            this.txtloc.Size = new System.Drawing.Size(120, 24);
            this.txtloc.TabIndex = 17;
            // 
            // txtJobSeekerPosition
            // 
            this.txtJobSeekerPosition.Location = new System.Drawing.Point(815, 131);
            this.txtJobSeekerPosition.Name = "txtJobSeekerPosition";
            this.txtJobSeekerPosition.Size = new System.Drawing.Size(121, 24);
            this.txtJobSeekerPosition.TabIndex = 16;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ORS.PL.Properties.Resources.images__1_1;
            this.pictureBox2.Location = new System.Drawing.Point(3, 7);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(231, 230);
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ORS.PL.Properties.Resources._1f447;
            this.pictureBox1.Location = new System.Drawing.Point(365, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(79, 61);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.Color.RoyalBlue;
            this.label60.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label60.Location = new System.Drawing.Point(617, 134);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(154, 18);
            this.label60.TabIndex = 6;
            this.label60.Text = "Position                      :";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.Color.RoyalBlue;
            this.label58.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label58.Location = new System.Drawing.Point(268, 95);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(149, 18);
            this.label58.TabIndex = 4;
            this.label58.Text = "Experience                :";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.Color.RoyalBlue;
            this.label57.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label57.Location = new System.Drawing.Point(617, 83);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(149, 18);
            this.label57.TabIndex = 3;
            this.label57.Text = "Location                    :";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.Color.RoyalBlue;
            this.label56.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label56.Location = new System.Drawing.Point(262, 134);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(155, 18);
            this.label56.TabIndex = 2;
            this.label56.Text = "Expected Salary (PA) :";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.Color.Snow;
            this.label54.ForeColor = System.Drawing.Color.Chocolate;
            this.label54.Location = new System.Drawing.Point(240, 7);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(91, 18);
            this.label54.TabIndex = 0;
            this.label54.Text = "Search Here";
            // 
            // JobSeekerHomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(988, 813);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "JobSeekerHomePage";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.JobSeekerHomePage_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.grpbJobHistory.ResumeLayout(false);
            this.grpbJobHistory.PerformLayout();
            this.grpbSkillSet.ResumeLayout(false);
            this.grpbSkillSet.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpbQualification.ResumeLayout(false);
            this.grpbQualification.PerformLayout();
            this.grpbContactDetails.ResumeLayout(false);
            this.grpbContactDetails.PerformLayout();
            this.grpbPersonalDetails.ResumeLayout(false);
            this.grpbPersonalDetails.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvShowVacancies)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button buttonLogout;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label lblaboutus;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnEditProfile;
        private System.Windows.Forms.GroupBox grpbJobHistory;
        private System.Windows.Forms.TextBox txtPWO;
        private System.Windows.Forms.TextBox txtTechWO;
        private System.Windows.Forms.TextBox txtCompName;
        private System.Windows.Forms.TextBox txtExp;
        private System.Windows.Forms.Label lblProjWorkedOn;
        private System.Windows.Forms.Label lblTechnology;
        private System.Windows.Forms.Label lblCompanyName;
        private System.Windows.Forms.Label lblExp;
        private System.Windows.Forms.GroupBox grpbSkillSet;
        private System.Windows.Forms.TextBox txtPS;
        private System.Windows.Forms.Label lblSkills;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.GroupBox grpbQualification;
        private System.Windows.Forms.TextBox txtGPY;
        private System.Windows.Forms.TextBox txtPGP;
        private System.Windows.Forms.TextBox txtPGPY;
        private System.Windows.Forms.TextBox txtSSP;
        private System.Windows.Forms.TextBox txtSSCPY;
        private System.Windows.Forms.TextBox txtHSCP;
        private System.Windows.Forms.TextBox txtHSCPY;
        private System.Windows.Forms.TextBox txtDPY;
        private System.Windows.Forms.TextBox txtDIPP;
        private System.Windows.Forms.TextBox txtGP;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox grpbContactDetails;
        private System.Windows.Forms.TextBox txtContact2;
        private System.Windows.Forms.TextBox txtContact1;
        private System.Windows.Forms.TextBox txtPostalCode;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.TextBox txtCountry;
        private System.Windows.Forms.TextBox txtAdd2;
        private System.Windows.Forms.TextBox txtAdd1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.Label lblContactNo2;
        private System.Windows.Forms.Label lblContactNo1;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.Label lblAddress2;
        private System.Windows.Forms.Label lblAddress1;
        private System.Windows.Forms.GroupBox grpbPersonalDetails;
        private System.Windows.Forms.TextBox txtLang;
        private System.Windows.Forms.TextBox txtDOB;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtGender;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblLanguages;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox txtJobSeekerPosition;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.DataGridView dgvShowVacancies;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.TextBox txtepsal;
        private System.Windows.Forms.TextBox txtreqexp;
        private System.Windows.Forms.TextBox txtloc;
    }
}