﻿namespace ORS.PL
{
    partial class EmployerHomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.lblUserID = new System.Windows.Forms.Label();
            this.buttonLogout = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dgvJobseekerDetails = new System.Windows.Forms.DataGridView();
            this.btnSearchByVacancy = new System.Windows.Forms.Button();
            this.txtSearchBySkills = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.grpbContactDetails = new System.Windows.Forms.GroupBox();
            this.txtstate = new System.Windows.Forms.TextBox();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.txtcountry = new System.Windows.Forms.TextBox();
            this.btnedit = new System.Windows.Forms.Button();
            this.txtPostalCode = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtContactNo2 = new System.Windows.Forms.TextBox();
            this.txtContactNo1 = new System.Windows.Forms.TextBox();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.txtAddress1 = new System.Windows.Forms.TextBox();
            this.labelCity = new System.Windows.Forms.Label();
            this.labelState = new System.Windows.Forms.Label();
            this.lblContactNo2 = new System.Windows.Forms.Label();
            this.lblContactNo1 = new System.Windows.Forms.Label();
            this.labelCountry = new System.Windows.Forms.Label();
            this.lblAddress2 = new System.Windows.Forms.Label();
            this.lblAddress1 = new System.Windows.Forms.Label();
            this.grpbComapnyDetails = new System.Windows.Forms.GroupBox();
            this.txtcompanytype = new System.Windows.Forms.TextBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.txtComapanyWebsite = new System.Windows.Forms.TextBox();
            this.txtComapanyName = new System.Windows.Forms.TextBox();
            this.txtCompanyID = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtsalary = new System.Windows.Forms.TextBox();
            this.txtreqexp = new System.Windows.Forms.TextBox();
            this.txtcategory = new System.Windows.Forms.TextBox();
            this.txtdomain = new System.Windows.Forms.TextBox();
            this.txtJobDesc = new System.Windows.Forms.TextBox();
            this.txtLocation = new System.Windows.Forms.TextBox();
            this.txtPosition = new System.Windows.Forms.TextBox();
            this.txtCompanyName2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btnvacancy = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJobseekerDetails)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.grpbContactDetails.SuspendLayout();
            this.grpbComapnyDetails.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ORS.PL.Properties.Resources.download1;
            this.pictureBox1.Location = new System.Drawing.Point(16, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(595, 122);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(408, 98);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 16);
            this.label9.TabIndex = 2;
            this.label9.Text = "User ID  :";
            // 
            // lblUserID
            // 
            this.lblUserID.AutoSize = true;
            this.lblUserID.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblUserID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserID.Location = new System.Drawing.Point(476, 98);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(64, 16);
            this.lblUserID.TabIndex = 3;
            this.lblUserID.Text = "lblUserID";
            this.lblUserID.Click += new System.EventHandler(this.lblUserID_Click);
            // 
            // buttonLogout
            // 
            this.buttonLogout.BackColor = System.Drawing.Color.LightGray;
            this.buttonLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLogout.Location = new System.Drawing.Point(501, 4);
            this.buttonLogout.Name = "buttonLogout";
            this.buttonLogout.Size = new System.Drawing.Size(75, 25);
            this.buttonLogout.TabIndex = 4;
            this.buttonLogout.Text = "Logout";
            this.buttonLogout.UseVisualStyleBackColor = false;
            this.buttonLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackgroundImage = global::ORS.PL.Properties.Resources.images;
            this.tabPage2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage2.Controls.Add(this.dgvJobseekerDetails);
            this.tabPage2.Controls.Add(this.btnSearchByVacancy);
            this.tabPage2.Controls.Add(this.txtSearchBySkills);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(652, 573);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Search for Employee";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dgvJobseekerDetails
            // 
            this.dgvJobseekerDetails.BackgroundColor = System.Drawing.Color.Aqua;
            this.dgvJobseekerDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvJobseekerDetails.Location = new System.Drawing.Point(15, 155);
            this.dgvJobseekerDetails.Name = "dgvJobseekerDetails";
            this.dgvJobseekerDetails.Size = new System.Drawing.Size(611, 244);
            this.dgvJobseekerDetails.TabIndex = 20;
            // 
            // btnSearchByVacancy
            // 
            this.btnSearchByVacancy.BackColor = System.Drawing.Color.LightGray;
            this.btnSearchByVacancy.Location = new System.Drawing.Point(285, 36);
            this.btnSearchByVacancy.Name = "btnSearchByVacancy";
            this.btnSearchByVacancy.Size = new System.Drawing.Size(91, 36);
            this.btnSearchByVacancy.TabIndex = 19;
            this.btnSearchByVacancy.Text = "Search ";
            this.btnSearchByVacancy.UseVisualStyleBackColor = false;
            this.btnSearchByVacancy.Click += new System.EventHandler(this.btnSearchByVacancy_Click);
            // 
            // txtSearchBySkills
            // 
            this.txtSearchBySkills.Location = new System.Drawing.Point(115, 43);
            this.txtSearchBySkills.Name = "txtSearchBySkills";
            this.txtSearchBySkills.Size = new System.Drawing.Size(121, 22);
            this.txtSearchBySkills.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label8.Location = new System.Drawing.Point(43, 49);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 16);
            this.label8.TabIndex = 17;
            this.label8.Text = "Skills: ";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.PapayaWhip;
            this.tabPage3.Controls.Add(this.grpbContactDetails);
            this.tabPage3.Controls.Add(this.grpbComapnyDetails);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.txtEmail);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(652, 573);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "My Profile";
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // grpbContactDetails
            // 
            this.grpbContactDetails.BackColor = System.Drawing.Color.Transparent;
            this.grpbContactDetails.Controls.Add(this.txtstate);
            this.grpbContactDetails.Controls.Add(this.txtcity);
            this.grpbContactDetails.Controls.Add(this.txtcountry);
            this.grpbContactDetails.Controls.Add(this.btnedit);
            this.grpbContactDetails.Controls.Add(this.txtPostalCode);
            this.grpbContactDetails.Controls.Add(this.label13);
            this.grpbContactDetails.Controls.Add(this.txtContactNo2);
            this.grpbContactDetails.Controls.Add(this.txtContactNo1);
            this.grpbContactDetails.Controls.Add(this.txtAddress2);
            this.grpbContactDetails.Controls.Add(this.txtAddress1);
            this.grpbContactDetails.Controls.Add(this.labelCity);
            this.grpbContactDetails.Controls.Add(this.labelState);
            this.grpbContactDetails.Controls.Add(this.lblContactNo2);
            this.grpbContactDetails.Controls.Add(this.lblContactNo1);
            this.grpbContactDetails.Controls.Add(this.labelCountry);
            this.grpbContactDetails.Controls.Add(this.lblAddress2);
            this.grpbContactDetails.Controls.Add(this.lblAddress1);
            this.grpbContactDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbContactDetails.Location = new System.Drawing.Point(33, 261);
            this.grpbContactDetails.Name = "grpbContactDetails";
            this.grpbContactDetails.Size = new System.Drawing.Size(566, 294);
            this.grpbContactDetails.TabIndex = 7;
            this.grpbContactDetails.TabStop = false;
            this.grpbContactDetails.Text = "Contact Details";
            // 
            // txtstate
            // 
            this.txtstate.Location = new System.Drawing.Point(348, 146);
            this.txtstate.Name = "txtstate";
            this.txtstate.Size = new System.Drawing.Size(100, 21);
            this.txtstate.TabIndex = 19;
            // 
            // txtcity
            // 
            this.txtcity.Location = new System.Drawing.Point(124, 190);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(100, 21);
            this.txtcity.TabIndex = 18;
            // 
            // txtcountry
            // 
            this.txtcountry.Location = new System.Drawing.Point(124, 146);
            this.txtcountry.Name = "txtcountry";
            this.txtcountry.Size = new System.Drawing.Size(100, 21);
            this.txtcountry.TabIndex = 17;
            // 
            // btnedit
            // 
            this.btnedit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnedit.Location = new System.Drawing.Point(226, 265);
            this.btnedit.Name = "btnedit";
            this.btnedit.Size = new System.Drawing.Size(92, 23);
            this.btnedit.TabIndex = 16;
            this.btnedit.Text = "Edit";
            this.btnedit.UseVisualStyleBackColor = true;
            this.btnedit.Click += new System.EventHandler(this.btnedit_Click);
            // 
            // txtPostalCode
            // 
            this.txtPostalCode.Location = new System.Drawing.Point(350, 190);
            this.txtPostalCode.Name = "txtPostalCode";
            this.txtPostalCode.Size = new System.Drawing.Size(100, 21);
            this.txtPostalCode.TabIndex = 15;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(255, 190);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(88, 15);
            this.label13.TabIndex = 14;
            this.label13.Text = "Postal Code:";
            // 
            // txtContactNo2
            // 
            this.txtContactNo2.Location = new System.Drawing.Point(350, 236);
            this.txtContactNo2.Name = "txtContactNo2";
            this.txtContactNo2.Size = new System.Drawing.Size(100, 21);
            this.txtContactNo2.TabIndex = 13;
            this.txtContactNo2.TextChanged += new System.EventHandler(this.txtContactNo2_TextChanged);
            // 
            // txtContactNo1
            // 
            this.txtContactNo1.Location = new System.Drawing.Point(121, 236);
            this.txtContactNo1.Name = "txtContactNo1";
            this.txtContactNo1.Size = new System.Drawing.Size(100, 21);
            this.txtContactNo1.TabIndex = 12;
            // 
            // txtAddress2
            // 
            this.txtAddress2.Location = new System.Drawing.Point(175, 93);
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(299, 21);
            this.txtAddress2.TabIndex = 11;
            // 
            // txtAddress1
            // 
            this.txtAddress1.Location = new System.Drawing.Point(175, 47);
            this.txtAddress1.Name = "txtAddress1";
            this.txtAddress1.Size = new System.Drawing.Size(301, 21);
            this.txtAddress1.TabIndex = 10;
            // 
            // labelCity
            // 
            this.labelCity.AutoSize = true;
            this.labelCity.Location = new System.Drawing.Point(55, 187);
            this.labelCity.Name = "labelCity";
            this.labelCity.Size = new System.Drawing.Size(38, 15);
            this.labelCity.TabIndex = 6;
            this.labelCity.Text = "City :";
            // 
            // labelState
            // 
            this.labelState.AutoSize = true;
            this.labelState.Location = new System.Drawing.Point(283, 146);
            this.labelState.Name = "labelState";
            this.labelState.Size = new System.Drawing.Size(48, 15);
            this.labelState.TabIndex = 5;
            this.labelState.Text = "State :";
            // 
            // lblContactNo2
            // 
            this.lblContactNo2.AutoSize = true;
            this.lblContactNo2.Location = new System.Drawing.Point(242, 236);
            this.lblContactNo2.Name = "lblContactNo2";
            this.lblContactNo2.Size = new System.Drawing.Size(101, 15);
            this.lblContactNo2.TabIndex = 4;
            this.lblContactNo2.Text = "Contact No. 2 :";
            // 
            // lblContactNo1
            // 
            this.lblContactNo1.AutoSize = true;
            this.lblContactNo1.Location = new System.Drawing.Point(18, 236);
            this.lblContactNo1.Name = "lblContactNo1";
            this.lblContactNo1.Size = new System.Drawing.Size(97, 15);
            this.lblContactNo1.TabIndex = 3;
            this.lblContactNo1.Text = "Contact No 1 :";
            // 
            // labelCountry
            // 
            this.labelCountry.AutoSize = true;
            this.labelCountry.Location = new System.Drawing.Point(55, 146);
            this.labelCountry.Name = "labelCountry";
            this.labelCountry.Size = new System.Drawing.Size(63, 15);
            this.labelCountry.TabIndex = 2;
            this.labelCountry.Text = "Country :";
            // 
            // lblAddress2
            // 
            this.lblAddress2.AutoSize = true;
            this.lblAddress2.Location = new System.Drawing.Point(55, 99);
            this.lblAddress2.Name = "lblAddress2";
            this.lblAddress2.Size = new System.Drawing.Size(114, 15);
            this.lblAddress2.TabIndex = 1;
            this.lblAddress2.Text = "Address Line 2  :";
            // 
            // lblAddress1
            // 
            this.lblAddress1.AutoSize = true;
            this.lblAddress1.Location = new System.Drawing.Point(55, 53);
            this.lblAddress1.Name = "lblAddress1";
            this.lblAddress1.Size = new System.Drawing.Size(114, 15);
            this.lblAddress1.TabIndex = 0;
            this.lblAddress1.Text = "Address Line 1  :";
            // 
            // grpbComapnyDetails
            // 
            this.grpbComapnyDetails.BackColor = System.Drawing.Color.Transparent;
            this.grpbComapnyDetails.Controls.Add(this.txtcompanytype);
            this.grpbComapnyDetails.Controls.Add(this.txtDescription);
            this.grpbComapnyDetails.Controls.Add(this.txtComapanyWebsite);
            this.grpbComapnyDetails.Controls.Add(this.txtComapanyName);
            this.grpbComapnyDetails.Controls.Add(this.txtCompanyID);
            this.grpbComapnyDetails.Controls.Add(this.label20);
            this.grpbComapnyDetails.Controls.Add(this.label21);
            this.grpbComapnyDetails.Controls.Add(this.label17);
            this.grpbComapnyDetails.Controls.Add(this.label18);
            this.grpbComapnyDetails.Controls.Add(this.label19);
            this.grpbComapnyDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbComapnyDetails.Location = new System.Drawing.Point(33, 46);
            this.grpbComapnyDetails.Name = "grpbComapnyDetails";
            this.grpbComapnyDetails.Size = new System.Drawing.Size(553, 192);
            this.grpbComapnyDetails.TabIndex = 6;
            this.grpbComapnyDetails.TabStop = false;
            this.grpbComapnyDetails.Text = "Company Details";
            // 
            // txtcompanytype
            // 
            this.txtcompanytype.Location = new System.Drawing.Point(427, 70);
            this.txtcompanytype.Name = "txtcompanytype";
            this.txtcompanytype.Size = new System.Drawing.Size(120, 21);
            this.txtcompanytype.TabIndex = 18;
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(154, 116);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(294, 44);
            this.txtDescription.TabIndex = 14;
            // 
            // txtComapanyWebsite
            // 
            this.txtComapanyWebsite.Location = new System.Drawing.Point(424, 30);
            this.txtComapanyWebsite.Name = "txtComapanyWebsite";
            this.txtComapanyWebsite.Size = new System.Drawing.Size(123, 21);
            this.txtComapanyWebsite.TabIndex = 12;
            // 
            // txtComapanyName
            // 
            this.txtComapanyName.Location = new System.Drawing.Point(154, 67);
            this.txtComapanyName.Name = "txtComapanyName";
            this.txtComapanyName.Size = new System.Drawing.Size(123, 21);
            this.txtComapanyName.TabIndex = 10;
            // 
            // txtCompanyID
            // 
            this.txtCompanyID.Location = new System.Drawing.Point(154, 27);
            this.txtCompanyID.Name = "txtCompanyID";
            this.txtCompanyID.Size = new System.Drawing.Size(123, 21);
            this.txtCompanyID.TabIndex = 8;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(20, 116);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(112, 15);
            this.label20.TabIndex = 7;
            this.label20.Text = "Description       :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(288, 67);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(128, 15);
            this.label21.TabIndex = 6;
            this.label21.Text = "Company Type      :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(20, 70);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(132, 15);
            this.label17.TabIndex = 2;
            this.label17.Text = "Comapny Name     :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(288, 30);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(133, 15);
            this.label18.TabIndex = 1;
            this.label18.Text = "Company Website  :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(20, 33);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(128, 15);
            this.label19.TabIndex = 0;
            this.label19.Text = "Company ID          :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(67, 19);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 16);
            this.label16.TabIndex = 3;
            this.label16.Text = "Email";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(187, 16);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(110, 22);
            this.txtEmail.TabIndex = 9;
            this.txtEmail.TextChanged += new System.EventHandler(this.txtUserID_TextChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackgroundImage = global::ORS.PL.Properties.Resources.images__2_1;
            this.tabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage1.Controls.Add(this.txtsalary);
            this.tabPage1.Controls.Add(this.txtreqexp);
            this.tabPage1.Controls.Add(this.txtcategory);
            this.tabPage1.Controls.Add(this.txtdomain);
            this.tabPage1.Controls.Add(this.txtJobDesc);
            this.tabPage1.Controls.Add(this.txtLocation);
            this.tabPage1.Controls.Add(this.txtPosition);
            this.tabPage1.Controls.Add(this.txtCompanyName2);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.btnvacancy);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(652, 573);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Add Vacancies";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txtsalary
            // 
            this.txtsalary.Location = new System.Drawing.Point(178, 192);
            this.txtsalary.Name = "txtsalary";
            this.txtsalary.Size = new System.Drawing.Size(100, 21);
            this.txtsalary.TabIndex = 22;
            // 
            // txtreqexp
            // 
            this.txtreqexp.Location = new System.Drawing.Point(178, 154);
            this.txtreqexp.Name = "txtreqexp";
            this.txtreqexp.Size = new System.Drawing.Size(100, 21);
            this.txtreqexp.TabIndex = 21;
            // 
            // txtcategory
            // 
            this.txtcategory.Location = new System.Drawing.Point(171, 421);
            this.txtcategory.Name = "txtcategory";
            this.txtcategory.Size = new System.Drawing.Size(100, 21);
            this.txtcategory.TabIndex = 20;
            // 
            // txtdomain
            // 
            this.txtdomain.Location = new System.Drawing.Point(171, 387);
            this.txtdomain.Name = "txtdomain";
            this.txtdomain.Size = new System.Drawing.Size(100, 21);
            this.txtdomain.TabIndex = 19;
            // 
            // txtJobDesc
            // 
            this.txtJobDesc.Location = new System.Drawing.Point(171, 311);
            this.txtJobDesc.Multiline = true;
            this.txtJobDesc.Name = "txtJobDesc";
            this.txtJobDesc.Size = new System.Drawing.Size(276, 47);
            this.txtJobDesc.TabIndex = 13;
            // 
            // txtLocation
            // 
            this.txtLocation.Location = new System.Drawing.Point(171, 238);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Size = new System.Drawing.Size(100, 21);
            this.txtLocation.TabIndex = 12;
            // 
            // txtPosition
            // 
            this.txtPosition.Location = new System.Drawing.Point(171, 113);
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.Size = new System.Drawing.Size(100, 21);
            this.txtPosition.TabIndex = 9;
            // 
            // txtCompanyName2
            // 
            this.txtCompanyName2.Location = new System.Drawing.Point(171, 70);
            this.txtCompanyName2.Name = "txtCompanyName2";
            this.txtCompanyName2.Size = new System.Drawing.Size(100, 21);
            this.txtCompanyName2.TabIndex = 8;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(23, 421);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 15);
            this.label11.TabIndex = 18;
            this.label11.Text = "Category :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(20, 387);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 15);
            this.label10.TabIndex = 17;
            this.label10.Text = "Domain :";
            // 
            // btnvacancy
            // 
            this.btnvacancy.Location = new System.Drawing.Point(171, 469);
            this.btnvacancy.Name = "btnvacancy";
            this.btnvacancy.Size = new System.Drawing.Size(136, 34);
            this.btnvacancy.TabIndex = 16;
            this.btnvacancy.Text = "Add Vacancy";
            this.btnvacancy.UseVisualStyleBackColor = true;
            this.btnvacancy.Click += new System.EventHandler(this.btnvacancy_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 154);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(154, 15);
            this.label7.TabIndex = 7;
            this.label7.Text = "Required Experience  :";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 192);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 15);
            this.label6.TabIndex = 6;
            this.label6.Text = "Salary  :";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 241);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 15);
            this.label5.TabIndex = 5;
            this.label5.Text = "Location  :";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 314);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "Job Description  :";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Position  :";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Company Name  :";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 132);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(660, 602);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // EmployerHomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(702, 724);
            this.Controls.Add(this.buttonLogout);
            this.Controls.Add(this.lblUserID);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.Name = "EmployerHomePage";
            this.Text = "EmployerHomePage";
            this.Load += new System.EventHandler(this.EmployerHomePage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJobseekerDetails)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.grpbContactDetails.ResumeLayout(false);
            this.grpbContactDetails.PerformLayout();
            this.grpbComapnyDetails.ResumeLayout(false);
            this.grpbComapnyDetails.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.Button buttonLogout;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dgvJobseekerDetails;
        private System.Windows.Forms.Button btnSearchByVacancy;
        private System.Windows.Forms.TextBox txtSearchBySkills;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox grpbContactDetails;
        private System.Windows.Forms.TextBox txtstate;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.TextBox txtcountry;
        private System.Windows.Forms.Button btnedit;
        private System.Windows.Forms.TextBox txtPostalCode;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtContactNo2;
        private System.Windows.Forms.TextBox txtContactNo1;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.TextBox txtAddress1;
        private System.Windows.Forms.Label labelCity;
        private System.Windows.Forms.Label labelState;
        private System.Windows.Forms.Label lblContactNo2;
        private System.Windows.Forms.Label lblContactNo1;
        private System.Windows.Forms.Label labelCountry;
        private System.Windows.Forms.Label lblAddress2;
        private System.Windows.Forms.Label lblAddress1;
        private System.Windows.Forms.GroupBox grpbComapnyDetails;
        private System.Windows.Forms.TextBox txtcompanytype;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.TextBox txtComapanyWebsite;
        private System.Windows.Forms.TextBox txtComapanyName;
        private System.Windows.Forms.TextBox txtCompanyID;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtsalary;
        private System.Windows.Forms.TextBox txtreqexp;
        private System.Windows.Forms.TextBox txtcategory;
        private System.Windows.Forms.TextBox txtdomain;
        private System.Windows.Forms.TextBox txtJobDesc;
        private System.Windows.Forms.TextBox txtLocation;
        private System.Windows.Forms.TextBox txtPosition;
        private System.Windows.Forms.TextBox txtCompanyName2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnvacancy;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabControl1;
    }
}