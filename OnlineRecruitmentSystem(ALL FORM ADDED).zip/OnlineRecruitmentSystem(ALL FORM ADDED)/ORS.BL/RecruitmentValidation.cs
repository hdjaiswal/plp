﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.Entity;
using ORS.Exception;
using ORS.DAL;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;

namespace ORS.BL
{
    public class RecruitmentValidation
    {
        RecruitmentOperations operationObj = new RecruitmentOperations();

        public bool ValidateRecruitment(Recruitment RecObj)
        {
            bool validRecruitment = true;
            StringBuilder sb = new StringBuilder();

            ////-----Users-----
            ////Validating EmaIL id

            //string pattern = null;
            //pattern = "@^[a-zA-Z ][0-9]@[a-zA-Z ].com";

            //if (RecObj.Email.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + " Email address  is required.");
            //}
            //if (!Regex.IsMatch(RecObj.Email, pattern))
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Email address should be in feedback@gmail.com pattern");
            //}

            //////Password validations

            //if (RecObj.UserPassword.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + " Password  is required.");
            //}
            //if (RecObj.UserPassword.ToString().Length != 8)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Password should consist of minimum 8 digits");
            //}
            //if (RecObj.UserPassword1.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Re-enter the password");
            //}
            //if (RecObj.UserPassword1.ToString() != RecObj.UserPassword1.ToString())
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Both Passwords should match. Re-enter the Password");
            //}

            ////////Validation for Primary Phone no

            //if (RecObj.P_Phone.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Primary Phone No  is required.");
            //}
            //if (!(Regex.IsMatch(RecObj.P_Phone.ToString(), @"^[0-9]+$")))
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Contact number should contain only numbers.");
            //}
            //if (RecObj.P_Phone.ToString().Length != 10)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Conatct No should consist of 10 digits only.");
            //}

            ////    ////Validation for Secondary Phone no 

            //if (RecObj.S_Phone.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Secondary Phone No  is required.");
            //}
            //if (!(Regex.IsMatch(RecObj.S_Phone.ToString(), @"^[0-9]+$")))
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Contact number should contain only numbers.");
            //}
            //if (RecObj.S_Phone.ToString().Length != 10)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Conatct No should consist of 10 digits only.");
            //}

            ////    ////Validation Of address 1

            //if (RecObj.Address1.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Address is required.");
            //}

            ////    ////Validation Of address 2

            //if (RecObj.Address2.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Address is required.");
            //}

            ////    ////Postal Code validation

            //if (RecObj.Postalcode.ToString().Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Postal Code is required.");
            //}
            //if (RecObj.Postalcode.ToString().Length != 6)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Postal Code No should consist of 6 digits only.");
            //}

            ////    ////city validation

            //if (RecObj.City.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "City Name is required.");
            //}

            ////    ////state validation

            //if (RecObj.State.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "State Name is required.");
            //}

            ////    ////Country validation

            //if (RecObj.Country.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Country Name is required.");
            //}

            ////    ////-----Employeer-----

            ////    ////CompanyId validation


            //if (RecObj.CompanyID.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + " CompanyID  is required.");
            //}

            ////    ////Company Name validation

            //if (RecObj.CompanyName.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Company Name is required.");
            //}


            //if (!(Regex.IsMatch(RecObj.CompanyName, @"^[a-zA-Z ]+$")))
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Company Name should contain only characters.");
            //}

            ////    ////Company Type validation

            //if (RecObj.CompanyType.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Company Type is required.");
            //}

            ////    ////Website validation

            //string pattern1 = null;
            //pattern1 = "@^www.[a-zA-Z ][0-9][a-z ].com";

            //if (Regex.IsMatch(RecObj.CompanyWebsite, pattern1))
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + " Website should be in www.feedback.com pattern");
            //}

            ////    ////Company description validation

            //if (RecObj.CompanyDesc.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Company description is required.");
            //}

            ////    ////-----Jobseeker-----

            ////First Name validation
            //if (RecObj.FirstName.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "First Name is required.");
            //}

            ////Last name validation
            //if (RecObj.LastName.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Last Name is required.");
            //}

            ////    ////-----Qualification-----

            ////SSCMarks Validations
            //if (RecObj.SSCMarks == null)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "SSC Marks are required.");
            //}
            //if (!(Regex.IsMatch(RecObj.SSCMarks.ToString(), @"^[0-9]+$")))
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "SSC marks should contain only numbers.");
            //}
            //if (RecObj.SSCMarks > 100)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "SSC Marks should be less than or equal to 100");
            //}

            ////    ////HSC Marks validation
            //if (!(Regex.IsMatch(RecObj.HSCMarks.ToString(), @"^[0-9]+$")))
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "HSC marks should contain only numbers.");
            //}
            //if (RecObj.HSCMarks > 100)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "HSC Marks should be less than or equal to 100");
            //}

            ////Diploma Marks validation

            //if (!(Regex.IsMatch(RecObj.DipMarks.ToString(), @"^[0-9]+$")))
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Diploma marks should contain only numbers.");
            //}
            //if (RecObj.DipMarks > 100)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Diploma Marks should be less than or equal to 100");
            //}

            ////GradMarks validation
            //if (RecObj.GradMarks == null)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Graduation Marks are required.");
            //}
            //if (!(Regex.IsMatch(RecObj.GradMarks.ToString(), @"^[0-9]+$")))
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Graduation marks should contain only numbers.");
            //}
            //if (RecObj.GradMarks > 100)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Graduation Marks should be less than or equal to 100");
            //}


            ////    ////-----Job History-----

            ////CompanyName
            //if (RecObj.CompanyName.Length == 0)
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Company name  is required.");
            //}

            //if (!(Regex.IsMatch(RecObj.CompanyName1, @"^[a-zA-Z ]+$")))
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Company Name should contain only characters.");
            //}


            ////    ////-----Vacancy-----
            ////Validate Location
            //if (!(Regex.IsMatch(RecObj.Location, @"^[a-zA-Z ]+$")))
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Location should contain only characters.");
            //}

            ////Validate Company Name
            //if (!(Regex.IsMatch(RecObj.CompanyName2, @"^[a-zA-Z ]+$")))
            //{
            //    validRecruitment = false;
            //    sb.Append(Environment.NewLine + "Company Name should contain only characters.");
            //}

            if (validRecruitment == false)
                throw new RecruitmentException(sb.ToString());
            return validRecruitment;
            
        }

        public bool AddEmployerInformation(Recruitment RecObj)
        {
            bool employerAdded = false;
            if (ValidateRecruitment(RecObj))
                employerAdded = operationObj.AddEmployerInformation(RecObj);
            return employerAdded;
        }

        public bool AddJobseekerInformation(Recruitment RecObj)
        {
            bool jobseekerAdded = false;
            if (ValidateRecruitment(RecObj))
                jobseekerAdded = operationObj.AddJobseekerInformation(RecObj);
            return jobseekerAdded;
        }


        public bool AddVacancyInformation(Recruitment RecObj)
        {
            bool vacancyAdded = false;
            if (ValidateRecruitment(RecObj))
                vacancyAdded = operationObj.AddVacancyInformation(RecObj);
            return vacancyAdded;
        }

        public bool LoginJobseeker(Recruitment RecObj)
        {
            bool jobseekerVerified = false;
            if (ValidateRecruitment(RecObj))
                jobseekerVerified = operationObj.LoginJobseeker(RecObj);
            return jobseekerVerified;
        }

        public bool LoginEmployer(Recruitment RecObj)
        {
            bool employerVerified = false;
            if (ValidateRecruitment(RecObj))
                employerVerified = operationObj.LoginEmployer(RecObj);
            return employerVerified;
        }

        public DataTable SearchJob(string ReqExp ,string Location,string Salary,string Position)
        {

            DataTable searchTable = operationObj.SearchJob(ReqExp,Location,Salary,Position);
            return searchTable;
        }
        //public DataTable SearchJob(int ReqExp, string Location, string Salary, string Position)
        //{

        //    DataTable searchTable = operationObj.SearchJob(ReqExp, Location, Salary, Position);
        //    return searchTable;
        //}
        public DataTable DisplayJobseeker(int UserID)
        {
            DataTable dt = new DataTable();
            dt = operationObj.DisplayJobseeker(UserID);
            return dt;
        }

        public bool UpdateJobseeker(Recruitment RecObj)
        {
            bool jobseekerUpdated = false;
            try
            {
                jobseekerUpdated = operationObj.UpdateJobseeker(RecObj);
            }
            catch (RecruitmentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jobseekerUpdated;
        }

        public DataTable DisplayEmployeer(int UserID)
        {
            DataTable dt = new DataTable();
            dt = operationObj.DisplayEmployeer(UserID);
            return dt;
        }

        public bool UpdateEmployeer(Recruitment RecObj)
        {
            bool employeerUpdated = false;
            employeerUpdated = operationObj.UpdateEmployeer(RecObj);
            
            return employeerUpdated;
        }

        public DataTable SearchJobseeker(string Skills)
        {

            DataTable searchTable = operationObj.SearchJobseeker(Skills);
            return searchTable;
        }
     
    }
}
