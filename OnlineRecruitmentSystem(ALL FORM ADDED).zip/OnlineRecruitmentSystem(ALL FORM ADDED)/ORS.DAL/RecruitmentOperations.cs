﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ORS.Entity;
using ORS.Exception;
using AdminEntity;




namespace ORS.DAL
{
    
    public class RecruitmentOperations
    {
        SqlConnection connection;
        SqlDataReader reader;

       
        public RecruitmentOperations()
        {
          
            string connectionString = ConfigurationManager.ConnectionStrings["ORS"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }
        /// <summary>
        /// Author: Group 3
        /// Date Modified: 02/04/2017
        /// Description : Recruitment operations class to deal with the Recruitment data
        /// Date of Creation :25/03/2017
        /// </summary>
        /// <param name="RecObj"></param>
        /// <returns>bool</returns>
        public bool AddEmployerInformation(Recruitment RecObj)
        {

            try
            {
                bool employerAdded = false;
                SqlCommand cmdAdd = new SqlCommand("InsertIntoEmployers", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                //cmdAdd.Parameters.AddWithValue("@UserID", RecObj.UserID);
                cmdAdd.Parameters.AddWithValue("@Email", RecObj.Email);
                cmdAdd.Parameters.AddWithValue("@UserPassword", RecObj.UserPassword);
                cmdAdd.Parameters.AddWithValue("@UserPassword1", RecObj.UserPassword1);
                cmdAdd.Parameters.AddWithValue("@P_Phone", RecObj.P_Phone);
                cmdAdd.Parameters.AddWithValue("@S_Phone", RecObj.S_Phone);
                cmdAdd.Parameters.AddWithValue("@Address1", RecObj.Address1);
                cmdAdd.Parameters.AddWithValue("@Address2", RecObj.Address2);
                cmdAdd.Parameters.AddWithValue("@Postalcode", RecObj.Postalcode);
                cmdAdd.Parameters.AddWithValue("@City", RecObj.City);
                cmdAdd.Parameters.AddWithValue("@State", RecObj.State);
                cmdAdd.Parameters.AddWithValue("@Country", RecObj.Country);
                cmdAdd.Parameters.AddWithValue("@CompanyID", RecObj.CompanyID);
                cmdAdd.Parameters.AddWithValue("@CompanyName", RecObj.CompanyName);
                cmdAdd.Parameters.AddWithValue("@CompanyType", RecObj.CompanyType);
                cmdAdd.Parameters.AddWithValue("@CompanyWebsite", RecObj.CompanyWebsite);
                cmdAdd.Parameters.AddWithValue("@CompanyDesc", RecObj.CompanyDesc);
                cmdAdd.Parameters.AddWithValue("@UserType", RecObj.UserType);
                
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    employerAdded = true;
                return employerAdded;
            }
            catch (RecruitmentException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }


        public bool AddJobseekerInformation(Recruitment RecObj)
        {
          

            try
            {
                bool jobseekerAdded = false;
                SqlCommand cmdAdd = new SqlCommand("InsertIntoJobseekers", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@Email", RecObj.Email);
                cmdAdd.Parameters.AddWithValue("@UserPassword", RecObj.UserPassword);
                cmdAdd.Parameters.AddWithValue("@UserPassword1", RecObj.UserPassword1);
                cmdAdd.Parameters.AddWithValue("@P_Phone", RecObj.P_Phone);
                cmdAdd.Parameters.AddWithValue("@S_Phone", RecObj.S_Phone);
                cmdAdd.Parameters.AddWithValue("@Address1", RecObj.Address1);
                cmdAdd.Parameters.AddWithValue("@Address2", RecObj.Address2);
                cmdAdd.Parameters.AddWithValue("@Postalcode", RecObj.Postalcode);
                cmdAdd.Parameters.AddWithValue("@City", RecObj.City);
                cmdAdd.Parameters.AddWithValue("@Country", RecObj.Country);
                cmdAdd.Parameters.AddWithValue("@State", RecObj.State);
                cmdAdd.Parameters.AddWithValue("@UserType", RecObj.UserType);


                //cmdAdd.Parameters.AddWithValue("@JobseekerID", RecObj.JobseekerID);
                cmdAdd.Parameters.AddWithValue("@FirstName", RecObj.FirstName);
                cmdAdd.Parameters.AddWithValue("@LastName", RecObj.LastName);
                cmdAdd.Parameters.AddWithValue("@DOB", RecObj.DOB);
                cmdAdd.Parameters.AddWithValue("@Gender", RecObj.Gender);
                cmdAdd.Parameters.AddWithValue("@LangKnown", RecObj.LangKnown);
                cmdAdd.Parameters.AddWithValue("@Skills", RecObj.Skills);
                //cmdAdd.Parameters.AddWithValue("@UserID", RecObj.UserID);


                cmdAdd.Parameters.AddWithValue("@SSCMarks", RecObj.SSCMarks);
                cmdAdd.Parameters.AddWithValue("@SpYear", RecObj.SpYear);
                cmdAdd.Parameters.AddWithValue("@HSCMarks", RecObj.HSCMarks);
                cmdAdd.Parameters.AddWithValue("@HpYear", RecObj.HpYear);
                cmdAdd.Parameters.AddWithValue("@DipMarks", RecObj.DipMarks);
                cmdAdd.Parameters.AddWithValue("@DipYear", RecObj.DipYear);
                cmdAdd.Parameters.AddWithValue("@GradMarks", RecObj.GradMarks);
                cmdAdd.Parameters.AddWithValue("@GpYear", RecObj.GpYear);
                cmdAdd.Parameters.AddWithValue("@PostGMarks", RecObj.PostGMarks);
                cmdAdd.Parameters.AddWithValue("@PostGYear", RecObj.PostGYear);

                cmdAdd.Parameters.AddWithValue("@Experience", RecObj.Experience);
                cmdAdd.Parameters.AddWithValue("@CompanyName", RecObj.CompanyName1);
                cmdAdd.Parameters.AddWithValue("@TechWorkedOn", RecObj.TechWorkedOn);
                cmdAdd.Parameters.AddWithValue("@ProjWorkedOn", RecObj.ProjWorkedOn);



                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    jobseekerAdded = true;
                return jobseekerAdded;
            }
            catch (RecruitmentException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }



        public bool AddVacancyInformation(Recruitment RecObj)
        {

            try
            {
                bool vacancyAdded = false;
                SqlCommand cmdAdd = new SqlCommand("InsertIntoVacancy", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;

                cmdAdd.Parameters.AddWithValue("@ReqExp", RecObj.ReqExp);
                cmdAdd.Parameters.AddWithValue("@Location", RecObj.Location);
                cmdAdd.Parameters.AddWithValue("@Salary", RecObj.Salary);
                cmdAdd.Parameters.AddWithValue("@Position", RecObj.Position);
                cmdAdd.Parameters.AddWithValue("@JobDescription", RecObj.JobDescription);
                cmdAdd.Parameters.AddWithValue("@CompanyName", RecObj.CompanyName2);
                cmdAdd.Parameters.AddWithValue("@Domain", RecObj.Domain);
                cmdAdd.Parameters.AddWithValue("@Category", RecObj.Category);


                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    vacancyAdded = true;
                return vacancyAdded;
            }
            catch (RecruitmentException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        public bool LoginJobseeker(Recruitment RecObj)
        {

            try
            {
                bool JobseekerVerified = false;
                SqlCommand cmdAddJobseeker = new SqlCommand("LoginJobseeker", connection);
                cmdAddJobseeker.CommandType = CommandType.StoredProcedure;
                cmdAddJobseeker.Parameters.AddWithValue("@Email", RecObj.Email); //for @username we will compare value TextBox1.Text
                cmdAddJobseeker.Parameters.AddWithValue("@UserPassword", RecObj.UserPassword); //this is for password
                cmdAddJobseeker.Parameters.AddWithValue("@UserType", RecObj.UserType);
                connection.Open();
                SqlDataReader reader = cmdAddJobseeker.ExecuteReader();
                reader.Read();

                //if there are ROWS return

                if (reader.HasRows)
                {
                    JobseekerVerified = true;
                    AdminEntity.StaticUserID.jsEmail = (string)reader["Email"];
                    AdminEntity.StaticUserID.jsUserID=(int)reader["UserID"];
                }
                reader.Close();

                return JobseekerVerified;

            }
            catch (RecruitmentException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        public bool LoginEmployer(Recruitment RecObj)
        {
            try
            {
                bool employerVerified = false;
                SqlCommand cmdAddEmployer = new SqlCommand("LoginEmployer", connection);
                cmdAddEmployer.CommandType = CommandType.StoredProcedure;
                cmdAddEmployer.Parameters.AddWithValue("@Email", RecObj.Email); //for @username we will compare value TextBox1.Text
                cmdAddEmployer.Parameters.AddWithValue("@UserPassword", RecObj.UserPassword); //this is for password
                cmdAddEmployer.Parameters.AddWithValue("@UserType", RecObj.UserType);
                connection.Open();
                SqlDataReader reader = cmdAddEmployer.ExecuteReader();
                reader.Read();
                //if there are ROWS return

                if (reader.HasRows)
                {
                    employerVerified = true;
                    AdminEntity.StaticUserID.empEmail =(string)reader["Email"];
                    AdminEntity.StaticUserID.empUserID=(int)reader["UserID"];
                }
                return employerVerified;

            }
            catch (RecruitmentException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        public DataTable SearchJob(string ReqExp,string Location,string Salary,string Position)
        {
            SqlCommand cmdsearch = new SqlCommand("searchVacancyPara", connection);
            cmdsearch.CommandType = CommandType.StoredProcedure;
            cmdsearch.Parameters.AddWithValue("@ReqExp", ReqExp);
            cmdsearch.Parameters.AddWithValue("@Location", Location);
            cmdsearch.Parameters.AddWithValue("@Salary", Salary);
            cmdsearch.Parameters.AddWithValue("@Position", Position);
            ;
            if (connection.State == ConnectionState.Closed)
                connection.Open();
            reader = cmdsearch.ExecuteReader();     //Using reader we are fetching data from database
            DataTable searchTable = new DataTable();   //creating data table into data set
            searchTable.Load(reader);                 //Loading data into data set
            return searchTable;
        }
    

        public DataTable DisplayJobseeker(int UserID)
        {
            try
            {
                SqlCommand cmdDisplayJobSeeker = new SqlCommand("DisplayJobseeker", connection);
                cmdDisplayJobSeeker.CommandType = CommandType.StoredProcedure;
                cmdDisplayJobSeeker.Parameters.AddWithValue("@UserID", UserID); //for @username we will compare value TextBox1.Text
                connection.Open();
                SqlDataReader reader1 = cmdDisplayJobSeeker.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader1);
                return dt;
            }
            catch (RecruitmentException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }

        }


        public bool UpdateJobseeker(Recruitment RecObj)
        {

            bool jobseekerUpdated = false;

            SqlCommand cmdUpdate = new SqlCommand("UpdateJobseekers", connection);
            cmdUpdate.CommandType = CommandType.StoredProcedure;
            cmdUpdate.Parameters.AddWithValue("@UserID",RecObj.UserID);
            //cmdUpdate.Parameters.AddWithValue("@Email", RecObj.Email);
            cmdUpdate.Parameters.AddWithValue("@P_Phone", RecObj.P_Phone);
            cmdUpdate.Parameters.AddWithValue("@S_Phone", RecObj.S_Phone);
            cmdUpdate.Parameters.AddWithValue("@Address1", RecObj.Address1);
            cmdUpdate.Parameters.AddWithValue("@Address2", RecObj.Address2);
            cmdUpdate.Parameters.AddWithValue("@Postalcode", RecObj.Postalcode);
            cmdUpdate.Parameters.AddWithValue("@City", RecObj.City);
            cmdUpdate.Parameters.AddWithValue("@Country", RecObj.Country);
            cmdUpdate.Parameters.AddWithValue("@State", RecObj.State);
            

            cmdUpdate.Parameters.AddWithValue("@FirstName", RecObj.FirstName);
            cmdUpdate.Parameters.AddWithValue("@LastName", RecObj.LastName);
            cmdUpdate.Parameters.AddWithValue("@DOB", RecObj.DOB);
            cmdUpdate.Parameters.AddWithValue("@Gender", RecObj.Gender);
            cmdUpdate.Parameters.AddWithValue("@LangKnown", RecObj.LangKnown);
            cmdUpdate.Parameters.AddWithValue("@Skills", RecObj.Skills);



            cmdUpdate.Parameters.AddWithValue("@SSCMarks", RecObj.SSCMarks);
            cmdUpdate.Parameters.AddWithValue("@SpYear", RecObj.SpYear);
            cmdUpdate.Parameters.AddWithValue("@HSCMarks", RecObj.HSCMarks);
            cmdUpdate.Parameters.AddWithValue("@HpYear", RecObj.HpYear);
            cmdUpdate.Parameters.AddWithValue("@DipMarks", RecObj.DipMarks);
            cmdUpdate.Parameters.AddWithValue("@DipYear", RecObj.DipYear);
            cmdUpdate.Parameters.AddWithValue("@GradMarks", RecObj.GradMarks);
            cmdUpdate.Parameters.AddWithValue("@GpYear", RecObj.GpYear);
            cmdUpdate.Parameters.AddWithValue("@PostGMarks", RecObj.PostGMarks);
            cmdUpdate.Parameters.AddWithValue("@PostGYear", RecObj.PostGYear);
              

            cmdUpdate.Parameters.AddWithValue("@Experience", RecObj.Experience);
            cmdUpdate.Parameters.AddWithValue("@CompanyName", RecObj.CompanyName1);
            cmdUpdate.Parameters.AddWithValue("@TechWorkedOn", RecObj.TechWorkedOn);
            cmdUpdate.Parameters.AddWithValue("@ProjWorkedOn", RecObj.ProjWorkedOn);


            if (connection.State == ConnectionState.Closed)
                connection.Open();
            int result = cmdUpdate.ExecuteNonQuery();
            if (result > 0)
                jobseekerUpdated = true;
            return jobseekerUpdated;
        }

        public DataTable DisplayEmployeer(int UserID)
        {
            try
            {
                SqlCommand cmdDisplayEmployeer = new SqlCommand("DisplayEmployer", connection);
                cmdDisplayEmployeer.CommandType = CommandType.StoredProcedure;
                cmdDisplayEmployeer.Parameters.AddWithValue("@UserID", UserID); //for @username we will compare value TextBox1.Text
                connection.Open();
                SqlDataReader reader2 = cmdDisplayEmployeer.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader2);
                return dt;
            }
            catch (RecruitmentException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }

        }

        public bool UpdateEmployeer(Recruitment RecObj)
        {

            bool employeerUpdated = false;

            SqlCommand cmdUpdate = new SqlCommand("UpdateEmployers", connection);
            cmdUpdate.CommandType = CommandType.StoredProcedure;
            //cmdUpdate.Parameters.AddWithValue("@JobseekerID", RecObj.JobseekerID);//we have to provide jobseeker id here
            cmdUpdate.Parameters.AddWithValue("@UserID",RecObj.UserID);
            //cmdUpdate.Parameters.AddWithValue("@Email", RecObj.Email);
            cmdUpdate.Parameters.AddWithValue("@P_Phone", RecObj.P_Phone);
            cmdUpdate.Parameters.AddWithValue("@S_Phone", RecObj.S_Phone);
            cmdUpdate.Parameters.AddWithValue("@Address1", RecObj.Address1);
            cmdUpdate.Parameters.AddWithValue("@Address2", RecObj.Address2);
            cmdUpdate.Parameters.AddWithValue("@Postalcode", RecObj.Postalcode);
            cmdUpdate.Parameters.AddWithValue("@City", RecObj.City);
            cmdUpdate.Parameters.AddWithValue("@State", RecObj.State);
            cmdUpdate.Parameters.AddWithValue("@Country", RecObj.Country);

            cmdUpdate.Parameters.AddWithValue("@CompanyID", RecObj.CompanyID);
            cmdUpdate.Parameters.AddWithValue("@CompanyName", RecObj.CompanyName);
            cmdUpdate.Parameters.AddWithValue("@CompanyType", RecObj.CompanyType);
            cmdUpdate.Parameters.AddWithValue("@CompanyWebsite", RecObj.CompanyWebsite);
            cmdUpdate.Parameters.AddWithValue("@CompanyDesc", RecObj.CompanyDesc);
            


            if (connection.State == ConnectionState.Closed)
                connection.Open();
            int result = cmdUpdate.ExecuteNonQuery();
            if (result > 0)
                employeerUpdated = true;
            return employeerUpdated;
        }

        public DataTable SearchJobseeker(string Skills)
        {
            SqlCommand cmdsearch = new SqlCommand("SearchJobseeker", connection);
            cmdsearch.CommandType = CommandType.StoredProcedure;
            cmdsearch.Parameters.AddWithValue("@Skills", Skills);
            if (connection.State == ConnectionState.Closed)
                connection.Open();
            reader = cmdsearch.ExecuteReader();     //Using reader we are fetching data from database
            DataTable searchTable = new DataTable();   //creating data table into data set
            searchTable.Load(reader);                 //Loading data into data set
            return searchTable;
        }


    }
}
