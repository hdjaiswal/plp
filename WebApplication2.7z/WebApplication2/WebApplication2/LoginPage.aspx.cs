﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string uname = txtUser.Text;
            string pass = txtPassword.Text;
            string UserType = ddlUserType.SelectedItem.Text;
            if (uname == "admin" && pass == "123" && UserType == "Admin")
            {
                Response.Redirect("Admin.aspx");
            }
            //else
            //{
            //    Response.Write("<script LANGUAGE='JavaScript' >alert('Please enter correct Login Credentials And User Tyype')</script>");
            //    txtUser.Text = "";
            //    txtPassword.Text = "";
            //    ddlUserType.SelectedItem.Text = "";
            //    txtUser.Focus();
            //}
            else if (uname == "job" && pass == "123" && UserType == "Job Seeker")
            {
                Response.Redirect("JobSeeker.aspx");
            }
            //else
            //{
            //    Response.Write("<script LANGUAGE='JavaScript' >alert('Please enter correct Login Credentials And User Tyype')</script>");
            //    txtUser.Text = "";
            //    txtPassword.Text = "";
            //    ddlUserType.SelectedItem.Text = "";
            //    txtUser.Focus();
            //}
            else if (uname == "emp" && pass == "123" && UserType == "Employer")
            {
                Response.Redirect("Employer.Home");
            }
            else
            {
                Response.Write("<script LANGUAGE='JavaScript' >alert('Please enter correct Login Credentials And User Tyype')</script>");
                txtUser.Text = "";
                txtPassword.Text = "";
               // ddlUserType.SelectedItem.Text = "";
                txtUser.Focus();
            } 
        }
    }
}