﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLP.Entity
{
   public class Employer
    {
       

        public int EmployeeID { get; set; }
        public string EFirstName { get; set; }
        public string EMiddleName { get; set; }
        public string ELastName { get; set; }
        public string ECompanyName { get; set; }
        public string EEmailAddress { get; set; }
        public string EDesignation { get; set; }
        public string ELocation { get; set; }
        public Int64 EPhoneNo { get; set; }
        public string EPassword { get; set; }

       //Job details

        public int JobID { get; set; }
        public string DCompanyName { get; set; }
        public string DPost { get; set; }
        public int DVacancies { get; set; }
        public DateTime DPostedDate { get; set; }
        public DateTime DLastDate { get; set; }
        public string DDescription { get; set; }
        public Double DPackage { get; set; }
        public string DJobLocation { get; set; }
        public string DExperience { get; set; }

    }
}
