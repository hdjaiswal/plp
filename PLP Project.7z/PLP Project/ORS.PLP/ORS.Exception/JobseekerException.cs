﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLP.Exception
{
   public class JobseekerException :ApplicationException
    {
       public JobseekerException()
           :base()
       {}
       public JobseekerException(string message) 
           : base(message) 
       { }


    }
}
