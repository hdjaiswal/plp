﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace ORS.BL
{
    public class AdminValidations
    {

        AdminOperations adOp = new AdminOperations();

        public bool AdminLogin(Admin ad)
        {
            bool val = false;
            val = adOp.AdminLogin(ad);
            return val;
        }

    }
}
