﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ORS.ExceptionLibrary;



namespace ORS.DAL
{
   public class JobseekersOperations
   {
       SqlDataReader reader;
       int result;
  
        //SqlConnection connection;
        //SqlDataReader reader;

        //public JobseekersOperations()
        //{
        //    string connectionString = ConfigurationManager.ConnectionStrings["ORS"].ConnectionString;
        //    connection = new SqlConnection(connectionString);
        //}

         public bool AddJobSeekerPDetails(Jobseeker js)
         {
             try
             {
                 SqlCommand cmdAdd = DataConfiguration.CreateCommand();

                 cmdAdd.CommandText = "ORSGroup6.AddJobseekers";
                 bool jsAdded = false;
                 //SqlCommand cmdAdd = new SqlCommand("ORSGroup6.AddJobseekers", connection);
                 cmdAdd.CommandType = CommandType.StoredProcedure;
                 cmdAdd.Parameters.AddWithValue("@FirstName ", js.JFirstName);
                 cmdAdd.Parameters.AddWithValue("@MiddleName", js.JMiddleName);
                 cmdAdd.Parameters.AddWithValue("@LastName", js.JLastName);
                 cmdAdd.Parameters.AddWithValue("@EmailAddress", js.JEmailAddress);
                 cmdAdd.Parameters.AddWithValue("@JobSeekersAddress", js.JAddress);
                 cmdAdd.Parameters.AddWithValue("@Password", js.JPassword);
              //   cmdAdd.Parameters.AddWithValue("@", jobj.JCnfPassword);
                 cmdAdd.Parameters.AddWithValue("@DOB", js.JDOB);
                 cmdAdd.Parameters.AddWithValue("@ContactNo", js.JPhoneNo);
                 cmdAdd.Parameters.AddWithValue("@Gender", js.JGender);
                 cmdAdd.Parameters.AddWithValue("@MarraigeStatus", js.JMaritalStatus);
               
                 //if (connection.State == ConnectionState.Closed)
                 //    connection.Open();
                 //int result = cmdAdd.ExecuteNonQuery();
                 cmdAdd.Connection.Open();
                 result = cmdAdd.ExecuteNonQuery();
                 cmdAdd.Connection.Close();
                

                 if (result > 0)
                     jsAdded = true;
                 return jsAdded;
             }
             catch (JobseekersException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             //finally
             //{
             //    connection.Close();
             //}
         }

         public bool UpdatePersonalDetails(Jobseeker jsObj)
         {
             try
             {
                 SqlCommand cmdupdate = DataConfiguration.CreateCommand();

                 cmdupdate.CommandText = "ORSGroup6.UpdatePersonalDetails";
                 bool pedUpdated = false;
                // SqlCommand cmdupdate = new SqlCommand("UpdatePersonalDetails", connection);
                 cmdupdate.CommandType = CommandType.StoredProcedure;
                 cmdupdate.Parameters.AddWithValue("@JobSeekerId", jsObj.JobSeekerID);
                 cmdupdate.Parameters.AddWithValue("@FirstName", jsObj.JFirstName);
                 cmdupdate.Parameters.AddWithValue("@LastName", jsObj.JLastName);
                 cmdupdate.Parameters.AddWithValue("@MiddleName", jsObj.JMiddleName);
                 cmdupdate.Parameters.AddWithValue("@ContactNo", jsObj.JPhoneNo);
                 cmdupdate.Parameters.AddWithValue("@Gender", jsObj.JGender);
                 cmdupdate.Parameters.AddWithValue("@MarraigeStatus", jsObj.JMaritalStatus);
                 cmdupdate.Parameters.AddWithValue("@JobSeekersAddress", jsObj.JAddress);
                 cmdupdate.Parameters.AddWithValue("@DOB", jsObj.JDOB);
                 //if (connection.State == ConnectionState.Closed)
                 //    connection.Open();
                 //int result = cmdupdate.ExecuteNonQuery();
                 cmdupdate.Connection.Open();
                 result = cmdupdate.ExecuteNonQuery();
                 cmdupdate.Connection.Close();

                 if (result > 0)
                     pedUpdated = true;
                 return pedUpdated;
             }
             catch (JobseekersException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             //finally
             //{
             //    connection.Close();
             //}

         }

         public bool UpdateProfessionalDetails(Jobseeker jsObj)
         {
             try
             {
                 SqlCommand cmdupdate = DataConfiguration.CreateCommand();

                 cmdupdate.CommandText = "ORSGroup6.UpdateProfesionalDetails";
                 bool profUpdated = false;
                // SqlCommand cmdupdate = new SqlCommand("UpdateProfesionalDetails", connection);
                 cmdupdate.CommandType = CommandType.StoredProcedure;
                 cmdupdate.Parameters.AddWithValue("@jobseekerId", jsObj.JobSeekerID);
                 cmdupdate.Parameters.AddWithValue("@CurrentDesignation", jsObj.JCurrentDesig);
                 cmdupdate.Parameters.AddWithValue("@PrimarySkills", jsObj.JPrimarySkills);
                 cmdupdate.Parameters.AddWithValue("@SecondarySkills", jsObj.JSecondarySkills);
                 cmdupdate.Parameters.AddWithValue("@TrainingAttended", jsObj.JTrainingAttd);
                 cmdupdate.Parameters.AddWithValue("@Designation", jsObj.JDesignation);
                 cmdupdate.Parameters.AddWithValue("@Location", jsObj.DJobLocation);
                 cmdupdate.Parameters.AddWithValue("@Experience", jsObj.JExperience);

                 //if (connection.State == ConnectionState.Closed)
                 //    connection.Open();
                 //int result = cmdupdate.ExecuteNonQuery();
                 cmdupdate.Connection.Open();
                 result = cmdupdate.ExecuteNonQuery();
                 cmdupdate.Connection.Close();

                 if (result > 0)
                     profUpdated = true;
                 return profUpdated;
             }
             catch (JobseekersException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             //finally
             //{
             //    connection.Close();
             //}

         }

         public DataTable SearchByLocation(string jobloc)
         {
             SqlCommand cmdsrchloc = DataConfiguration.CreateCommand();
      
             cmdsrchloc.CommandText = "ORSGroup6.SearchbyLocation";
            // SqlCommand cmdsrchloc = new SqlCommand("ORSGroup6.SearchbyLocation", connection);
             cmdsrchloc.CommandType = CommandType.StoredProcedure;
             cmdsrchloc.Parameters.AddWithValue("@JobLocation", jobloc);
             //if (connection.State == ConnectionState.Closed)
             //    connection.Open();

             cmdsrchloc.Connection.Open();
             result = cmdsrchloc.ExecuteNonQuery();
             cmdsrchloc.Connection.Close();

             reader = cmdsrchloc.ExecuteReader();
             DataTable jsTable = new DataTable();
             jsTable.Load(reader);
             return jsTable;

         }

         public DataTable SearchByDesignation(string jobdesig)
         {
             SqlCommand cmdsrchdesig = DataConfiguration.CreateCommand();

             cmdsrchdesig.CommandText = "ORSGroup6.SearchbyDesignation";
             //SqlCommand cmdsrchloc = new SqlCommand("ORSGroup6.SearchbyDesignation", connection);
             cmdsrchdesig.CommandType = CommandType.StoredProcedure;
             cmdsrchdesig.Parameters.AddWithValue("@Designation", jobdesig);
             //if (connection.State == ConnectionState.Closed)
             //    connection.Open();

             cmdsrchdesig.Connection.Open();
             result = cmdsrchdesig.ExecuteNonQuery();
             cmdsrchdesig.Connection.Close();
             reader = cmdsrchdesig.ExecuteReader();
             DataTable jsTable = new DataTable();
             jsTable.Load(reader);
             return jsTable;

         }

         public DataTable SearchByExperience(string jobexp)
         {
             SqlCommand cmdsrcexp = DataConfiguration.CreateCommand();

             cmdsrcexp.CommandText = "ORSGroup6.SearchbyExperience";
            // SqlCommand cmdsrchloc = new SqlCommand("ORSGroup6.SearchbyExperience", connection);
             cmdsrcexp.CommandType = CommandType.StoredProcedure;
             cmdsrcexp.Parameters.AddWithValue("@Experience", jobexp);
             //if (connection.State == ConnectionState.Closed)
             //    connection.Open();

             cmdsrcexp.Connection.Open();
             result = cmdsrcexp.ExecuteNonQuery();
             cmdsrcexp.Connection.Close();

             reader = cmdsrcexp.ExecuteReader();
             DataTable jsTable = new DataTable();
             jsTable.Load(reader);
             return jsTable;

         }

         public bool AddJobSeekerQDetails(Jobseeker js)
         {
             try
             {
                 SqlCommand cmdAdd = DataConfiguration.CreateCommand();

                 cmdAdd.CommandText = "ORSGroup6.JobseekersQualificationDetail";
                 bool jsAdded = false;
                // SqlCommand cmdAdd = new SqlCommand("ORSGroup6.JobseekersQualificationDetail", connection);
                 cmdAdd.CommandType = CommandType.StoredProcedure;
                 cmdAdd.Parameters.AddWithValue("@Degree", js.Degree);
                 cmdAdd.Parameters.AddWithValue("@Branch", js.Branch);
                 cmdAdd.Parameters.AddWithValue("@Passingyear", js.PassingYr);
                 cmdAdd.Parameters.AddWithValue("@Percentage", js.Percentage);
                 cmdAdd.Parameters.AddWithValue("@UniversityName", js.UniversityName);
                 cmdAdd.Parameters.AddWithValue("@JobSeekerID", js.JobSeekerID);


                 cmdAdd.Connection.Open();
                 result = cmdAdd.ExecuteNonQuery();
                 cmdAdd.Connection.Close();
              
                 //if (connection.State == ConnectionState.Closed)
                 //    connection.Open();
                 //int result = cmdAdd.ExecuteNonQuery();

                 if (result > 0)
                     jsAdded = true;
                 return jsAdded;
             }
             catch (JobseekersException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             //finally
             //{
             //    connection.Close();
             //}
         }

         public bool ApplyJobs(Jobseeker jobj)
         {
            

             try
             {
                 SqlCommand cmdAdd = DataConfiguration.CreateCommand();

                 cmdAdd.CommandText = "ORSGroup6.ApplyJobs";
                 bool jobsApplied = false;
                // SqlCommand cmdAdd = new SqlCommand("ORSGroup6.ApplyJobs", connection);
                 cmdAdd.CommandType = CommandType.StoredProcedure;
                 cmdAdd.Parameters.AddWithValue("@JobId", jobj.JobID);
                 cmdAdd.Parameters.AddWithValue("@JobSeekerId", jobj.JobSeekerID);

                 //if (connection.State == ConnectionState.Closed)
                 //    connection.Open();
                 cmdAdd.Connection.Open();
                 int result = cmdAdd.ExecuteNonQuery();
                 cmdAdd.Connection.Close();
           

                 if (result > 0)
                     jobsApplied = true;
                 return jobsApplied;
             }
             catch (JobseekersException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             //finally
             //{
             //    connection.Close();
             //}
         }  
       
         public DataTable GetJSID(string email, string password)
         {
             SqlCommand cmdGetJSID = DataConfiguration.CreateCommand();

             cmdGetJSID.CommandText = "ORSGroup6.VerificationJobseekers";
            // SqlCommand cmdGetJSID = new SqlCommand("ORSGroup6.VerificationJobseekers", connection);
             cmdGetJSID.CommandType = CommandType.StoredProcedure;
             cmdGetJSID.Parameters.AddWithValue("@EmailAddress", email);
             cmdGetJSID.Parameters.AddWithValue("@Password", password);

             //if (connection.State == ConnectionState.Closed)
             //    connection.Open();


             cmdGetJSID.Connection.Open();
             result = cmdGetJSID.ExecuteNonQuery();
             cmdGetJSID.Connection.Close();

             reader = cmdGetJSID.ExecuteReader();
             DataTable jsTable = new DataTable();
             jsTable.Load(reader);
             return jsTable;

         }
         public DataTable GetPDetails(int jsid)
         {
             SqlCommand cmdjsdetails = DataConfiguration.CreateCommand();

             cmdjsdetails.CommandText = "ORSGroup6.VerificationJobseekers";
             Jobseeker pdObj = new Jobseeker();
             //SqlCommand cmdjsdetails = new SqlCommand("ORSGroup6.RetieveJobseekersPersonalDetails", connection);
             cmdjsdetails.CommandType = CommandType.StoredProcedure;
             cmdjsdetails.Parameters.AddWithValue("@jobseekerID", jsid);

             //if (connection.State == ConnectionState.Closed)
             //    connection.Open();

             reader = cmdjsdetails.ExecuteReader();
             DataTable jdetailsTable = new DataTable();
             jdetailsTable.Load(reader);
             return jdetailsTable;
         }

         public DataTable GetProfDetails(int jsid)
         {
             SqlCommand cmdjsdetails = DataConfiguration.CreateCommand();

             cmdjsdetails.CommandText = "ORSGroup6.VerificationJobseekers";
             Jobseeker profObj = new Jobseeker();
             //SqlCommand cmdjsdetails = new SqlCommand("ORSGroup6.RetrieveProfessionaldetails", connection);
             cmdjsdetails.CommandType = CommandType.StoredProcedure;
             cmdjsdetails.Parameters.AddWithValue("@JobSeekerID", jsid);

             //if (connection.State == ConnectionState.Closed)
             //    connection.Open();
             cmdjsdetails.Connection.Open();
             result = cmdjsdetails.ExecuteNonQuery();
             cmdjsdetails.Connection.Close();

             reader = cmdjsdetails.ExecuteReader();
             DataTable jdetailsTable = new DataTable();
             jdetailsTable.Load(reader);
             return jdetailsTable;

         }
         public DataTable GetAppliedDetails(int empid,int jobid )
         {
             SqlCommand cmdgetjapldetails = DataConfiguration.CreateCommand();

             cmdgetjapldetails.CommandText = "ORSGroup6.ViewsJobAppliedDetails";

             //SqlCommand cmdgetjapldetails = new SqlCommand("ORSGroup6.ViewsJobAppliedDetails", connection);
             cmdgetjapldetails.CommandType = CommandType.StoredProcedure;
             cmdgetjapldetails.Parameters.AddWithValue("@EmployeeId", empid);
             cmdgetjapldetails.Parameters.AddWithValue("@JobId", jobid);
             //if (connection.State == ConnectionState.Closed)
             //    connection.Open();
             cmdgetjapldetails.Connection.Open();
             result = cmdgetjapldetails.ExecuteNonQuery();
             cmdgetjapldetails.Connection.Close();
             reader = cmdgetjapldetails.ExecuteReader();
             DataTable jobTable = new DataTable();
             jobTable.Load(reader);
             return jobTable;

         }


         public DataTable GetQualificationDetails()
         {

             SqlCommand cmdGetqdetails = DataConfiguration.CreateCommand();

             cmdGetqdetails.CommandText = "ORSGroup6.JobseekersQualificationDetails";
             //SqlCommand cmdGetqdetails = new SqlCommand("Select * from ORSGroup6.JobseekersQualificationDetails", connection);

             //if (connection.State == ConnectionState.Closed)
             //    connection.Open();
             cmdGetqdetails.Connection.Open();
             result = cmdGetqdetails.ExecuteNonQuery();
             cmdGetqdetails.Connection.Close();
             reader = cmdGetqdetails.ExecuteReader();
             DataTable jsTable = new DataTable();
             jsTable.Load(reader);

             return jsTable;

         }
         public bool AddJobSeekerPrDetails(Jobseeker js)
         {
             try
             {

                 SqlCommand cmdAdd = DataConfiguration.CreateCommand();

                 cmdAdd.CommandText = "ORSGroup6.AddProfessionaDetails";
                 bool jsAdded = false;
                 //SqlCommand cmdAdd = new SqlCommand("ORSGroup6.AddProfessionaDetails", connection);
                 cmdAdd.CommandType = CommandType.StoredProcedure;
                 cmdAdd.Parameters.AddWithValue("@JobSeekerID", js.JobSeekerID);
                 cmdAdd.Parameters.AddWithValue("@CurrentDesignation", js.JCurrentDesig);
                 cmdAdd.Parameters.AddWithValue("@PrimarySkills", js.JPrimarySkills);
                 cmdAdd.Parameters.AddWithValue("@SecondarySkills", js.JSecondarySkills);
                 cmdAdd.Parameters.AddWithValue("@TrainingAttended", js.JTrainingAttd);
                 cmdAdd.Parameters.AddWithValue("@Designation", js.JDesignation);
                 cmdAdd.Parameters.AddWithValue("@Location", js.DJobLocation);
                 cmdAdd.Parameters.AddWithValue("@Experience", js.JExperience);


                 //if (connection.State == ConnectionState.Closed)
                 //    Connection.Open();
                 //int result = cmdAdd.ExecuteNonQuery();
                 cmdAdd.Connection.Open();
                 result = cmdAdd.ExecuteNonQuery();
                 cmdAdd.Connection.Close();

                 if (result > 0)
                     jsAdded = true;
                 return jsAdded;
             }
             catch (JobseekersException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             //finally
             //{
             //    connection.Close();
             //}
         }
    }
}
