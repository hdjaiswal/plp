﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ORS.ExceptionLibrary;

namespace ORS.DAL
{
    public class EmployerOperations
    {
        SqlDataReader reader;
        int result;
        public bool AddEmployeeDetails(Employer emp)
        {
       
            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "ORSGroup6.AddEmployee";
                bool jsAdded = false;
               // SqlCommand cmdAdd = new SqlCommand("ORSGroup6.AddEmployee", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@FirstName ", emp.EFirstName);
                cmd.Parameters.AddWithValue("@LastName", emp.ELastName);
                cmd.Parameters.AddWithValue("@EmailAddress", emp.EEmailAddress);
                cmd.Parameters.AddWithValue("@Companyname", emp.ECompanyName);
                cmd.Parameters.AddWithValue("@Password", emp.EPassword);
                cmd.Parameters.AddWithValue("@Designation", emp.EDesignation);
                cmd.Parameters.AddWithValue("@ContactNo", emp.EPhoneNo);
                cmd.Parameters.AddWithValue("@Location", emp.ELocation);

                cmd.Connection.Open();
                result = cmd.ExecuteNonQuery();
                cmd.Connection.Close();


                if (result > 0)
                    jsAdded = true;
                return jsAdded;
            }
            catch (EmployersException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            
        }
        



        public bool AddJobs(Employer emp)
        {
            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "ORSGroup6.AddJobs";
                bool jobsAdded = false;
               // SqlCommand cmdAdd = new SqlCommand("ORSGroup6.AddJobs", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CompanyName", emp.DCompanyName);
                cmd.Parameters.AddWithValue("@Post", emp.DPost);
                cmd.Parameters.AddWithValue("@Vacancies", emp.DVacancies);
                cmd.Parameters.AddWithValue("@PostedDate", emp.DPostedDate);
                cmd.Parameters.AddWithValue("@LastDate", emp.DLastDate);
                cmd.Parameters.AddWithValue("@CompanyDescription", emp.DDescription);
                cmd.Parameters.AddWithValue("@JobLocation", emp.PJobLocation);
                cmd.Parameters.AddWithValue("@Package", emp.DPackage);
                cmd.Parameters.AddWithValue("@Experience", emp.DExperience);
                cmd.Parameters.AddWithValue("@EmployeeID", emp.EmployeeID);

                cmd.Connection.Open();
                result = cmd.ExecuteNonQuery();
                cmd.Connection.Close();

                if (result > 0)
                    jobsAdded = true;
                return jobsAdded;
            }
            catch (EmployersException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
         
        }

        public DataTable GetEmpID(string email, string password)
        {
            SqlCommand cmdGetEmpID = DataConfiguration.CreateCommand();

            cmdGetEmpID.CommandText = "ORSGroup6.EmployeeVerification";
            //SqlCommand cmdGetEmpID = new SqlCommand("ORSGroup6.EmployeeVerification", connection);
            cmdGetEmpID.CommandType = CommandType.StoredProcedure;
            cmdGetEmpID.Parameters.AddWithValue("@EmailAddress", email);
            cmdGetEmpID.Parameters.AddWithValue("@Password", password);
            //if (connection.State == ConnectionState.Closed)
            //    connection.Open();
            cmdGetEmpID.Connection.Open();
            result = cmdGetEmpID.ExecuteNonQuery();
            cmdGetEmpID.Connection.Close();
            reader = cmdGetEmpID.ExecuteReader();
            DataTable empTable = new DataTable();
            empTable.Load(reader);
            return empTable;

        }

        public DataTable GetPostedJobs(int empid)
        {
            SqlCommand cmdPJobs = DataConfiguration.CreateCommand();

            cmdPJobs.CommandText = "ORSGroup6.ViewjobsByEmployee";
          //SqlCommand cmdPJobs = new SqlCommand("ORSGroup6.ViewjobsByEmployee", connection);
            cmdPJobs.CommandType = CommandType.StoredProcedure;
            cmdPJobs.Parameters.AddWithValue("@EmployeeID", empid);

            //if (connection.State == ConnectionState.Closed)
            //    connection.Open();
            cmdPJobs.Connection.Open();
            result = cmdPJobs.ExecuteNonQuery();
            cmdPJobs.Connection.Close();
            reader = cmdPJobs.ExecuteReader();
            DataTable jobTable = new DataTable();
            jobTable.Load(reader);
            return jobTable;

        }

    }
}
