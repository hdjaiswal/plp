﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ORS.ExceptionLibrary;

namespace ORS.DAL
{
    public class AdminOperations
    {
        

        public bool AdminLogin(Admin ad)
        {
            
            try
            {
                bool val = false;
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "ORSGroup6.usp_ValidateLogin";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Username", ad.Username);
                cmd.Parameters.AddWithValue("@Password", ad.Password);

                cmd.Connection.Open();
                int result = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
                if (result > 0)        
                    val = true;
                return val;
                
               
            }
            catch (JobseekersException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }
       




    }
}
