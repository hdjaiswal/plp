﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.ExceptionLibrary
{

    /// <summary>
    /// Class to throw Employer's exception
    /// Author: 
    /// Date Modified: 5th April 2017
    /// Version No:
    /// Change Description:
    /// </summary>
   public class EmployersException:ApplicationException
    {
       public EmployersException() :
           base()
       { }
       public EmployersException(string message) :
           base()
       { }
    }
}
